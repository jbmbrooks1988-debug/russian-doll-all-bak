
#include <GL/glut.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// For this prototype, we'll define a simple structure for UI elements
// and a hardcoded array to represent the parsed C-HTML file.

#define MAX_ELEMENTS 10

typedef struct {
    char type[20];
    int x, y, width, height;
    char label[50]; // Used for button label, text element value, and checkbox label
    char text_content[256]; // For textfield content
    int cursor_pos; // For textfield cursor position
    int is_active; // For textfield active state
    int is_checked; // For checkbox checked state
    float color[3];
    int parent;
} UIElement;

UIElement elements[MAX_ELEMENTS];
int num_elements = 0;

// Simple parser for our C-HTML format
void parse_chtml(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Error opening CHTML file");
        return;
    }

    char line[256];
    num_elements = 0;
    int parent_stack[MAX_ELEMENTS];
    int stack_top = -1;

    while (fgets(line, sizeof(line), file)) {
        char* token = strtok(line, " <>/\n");
        if (!token) continue;

        if (line[1] == '/') { // Closing tag
            if (stack_top > -1) {
                stack_top--;
            }
            continue;
        }

        elements[num_elements].parent = (stack_top > -1) ? parent_stack[stack_top] : -1;
        strcpy(elements[num_elements].type, token);
        elements[num_elements].is_active = 0; // Initialize is_active to false
        elements[num_elements].cursor_pos = 0; // Initialize cursor_pos
        elements[num_elements].text_content[0] = '\0'; // Initialize text_content
        elements[num_elements].is_checked = 0; // Initialize is_checked to false

        char* attr = strtok(NULL, " \"=");
        while (attr) {
            char* value = strtok(NULL, " \"=\n");
            if (strcmp(attr, "x") == 0) elements[num_elements].x = atoi(value);
            else if (strcmp(attr, "y") == 0) elements[num_elements].y = atoi(value);
            else if (strcmp(attr, "width") == 0) elements[num_elements].width = atoi(value);
            else if (strcmp(attr, "height") == 0) elements[num_elements].height = atoi(value);
            else if (strcmp(attr, "label") == 0) strncpy(elements[num_elements].label, value, 49);
            else if (strcmp(attr, "value") == 0) {
                strncpy(elements[num_elements].text_content, value, 255);
                elements[num_elements].cursor_pos = strlen(elements[num_elements].text_content);
            }
            else if (strcmp(attr, "checked") == 0) {
                if (strcmp(value, "true") == 0) {
                    elements[num_elements].is_checked = 1;
                }
            }
            else if (strcmp(attr, "color") == 0) {
                long color = strtol(value + 1, NULL, 16);
                elements[num_elements].color[0] = ((color >> 16) & 0xFF) / 255.0f;
                elements[num_elements].color[1] = ((color >> 8) & 0xFF) / 255.0f;
                elements[num_elements].color[2] = (color & 0xFF) / 255.0f;
            }
            attr = strtok(NULL, " \"=");
        }

        if (strcmp(token, "panel") == 0) {
            stack_top++;
            parent_stack[stack_top] = num_elements;
        }

        num_elements++;
    }

    fclose(file);
}

void init_view() {
    parse_chtml("demo.chtml");
}

void draw_element(UIElement* el) {
    int parent_x = 0;
    int parent_y = 0;

    if (el->parent != -1) {
        parent_x = elements[el->parent].x;
        parent_y = elements[el->parent].y;
    }

    int abs_x = parent_x + el->x;
    int abs_y = parent_y + el->y;

    if (strcmp(el->type, "header") == 0 || strcmp(el->type, "button") == 0 || strcmp(el->type, "panel") == 0 || strcmp(el->type, "textfield") == 0 || strcmp(el->type, "checkbox") == 0) {
        if (strcmp(el->type, "textfield") == 0) {
            glColor3f(0.1f, 0.1f, 0.1f); // Dark background for textfield
        } else if (strcmp(el->type, "checkbox") == 0) {
            glColor3f(0.8f, 0.8f, 0.8f); // Light background for checkbox square
        } else {
            glColor3fv(el->color);
        }
        glBegin(GL_QUADS);
        glVertex2i(abs_x, abs_y);
        glVertex2i(abs_x + el->width, abs_y);
        glVertex2i(abs_x + el->width, abs_y + el->height);
        glVertex2i(abs_x, abs_y + el->height);
        glEnd();

        if (strcmp(el->type, "checkbox") == 0 && el->is_checked) {
            // Draw a simple checkmark (upright V shape, adjusted for inverted Y)
            glColor3f(0.0f, 0.0f, 0.0f); // Black checkmark
            glLineWidth(2.0f);
            glBegin(GL_LINES);
            // First segment: bottom-left to top-middle
            glVertex2i(abs_x + el->width * 0.2, abs_y + el->height * 0.8); // Visually lower
            glVertex2i(abs_x + el->width * 0.4, abs_y + el->height * 0.2); // Visually higher
            // Second segment: top-middle to bottom-right
            glVertex2i(abs_x + el->width * 0.4, abs_y + el->height * 0.2); // Visually higher
            glVertex2i(abs_x + el->width * 0.8, abs_y + el->height * 0.8); // Visually lower
            glEnd();
            glLineWidth(1.0f);
        }
    }

    if (strcmp(el->type, "text") == 0 || strcmp(el->type, "button") == 0 || strcmp(el->type, "checkbox") == 0) {
        glColor3f(1.0f, 1.0f, 1.0f);
        int text_offset_x = 5;
        int text_offset_y = 15;
        if (strcmp(el->type, "checkbox") == 0) {
            text_offset_x = el->width + 5; // Label next to checkbox
            text_offset_y = el->height / 2 - 5; // Center label vertically
        }
        glRasterPos2i(abs_x + text_offset_x, abs_y + text_offset_y);
        for (char* c = el->label; *c != '\0'; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }
    } else if (strcmp(el->type, "textfield") == 0) {
        glColor3f(1.0f, 1.0f, 1.0f);
        glRasterPos2i(abs_x + 5, abs_y + 15);
        for (char* c = el->text_content; *c != '\0'; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }

        // Draw cursor if active
        if (el->is_active) {
            // Simple blinking cursor (toggle every 500ms)
            if ((glutGet(GLUT_ELAPSED_TIME) / 500) % 2) {
                int text_width = 0;
                for (int i = 0; i < el->cursor_pos; i++) {
                    text_width += glutBitmapWidth(GLUT_BITMAP_HELVETICA_18, el->text_content[i]);
                }
                glColor3f(1.0f, 1.0f, 1.0f);
                glBegin(GL_QUADS);
                glVertex2i(abs_x + 5 + text_width, abs_y + 10);
                glVertex2i(abs_x + 5 + text_width + 2, abs_y + 10);
                glVertex2i(abs_x + 5 + text_width + 2, abs_y + 20);
                glVertex2i(abs_x + 5 + text_width, abs_y + 20);
                glEnd();
            }
        }
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    for (int i = 0; i < num_elements; i++) {
        draw_element(&elements[i]);
    }

    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, 0, h);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
