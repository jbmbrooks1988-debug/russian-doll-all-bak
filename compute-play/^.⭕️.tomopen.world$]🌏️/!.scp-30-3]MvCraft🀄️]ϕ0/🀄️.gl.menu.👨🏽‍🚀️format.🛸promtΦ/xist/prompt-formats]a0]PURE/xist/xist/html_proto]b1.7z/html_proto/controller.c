#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// We need the UIElement definition and the elements array from view.c
// In a real C application, you'd have a .h file for this.
typedef struct {
    char type[20];
    int x, y, width, height;
    char label[50]; // Used for button label, text element value, and checkbox label
    char text_content[256]; // For textfield content
    int cursor_pos; // For textfield cursor position
    int is_active; // For textfield active state
    int is_checked; // For checkbox checked state
    float color[3];
    int parent;
} UIElement;

extern UIElement elements[];
extern int num_elements;

void init_controller() {
    // Nothing to initialize for now
}

void mouse(int button, int state, int x, int y) {
    if (button == 0 && state == 1) { // Left mouse button up
        int ry = 600 - y; // 600 is the window height

        int clicked_textfield_index = -1;

        for (int i = 0; i < num_elements; i++) {
            int parent_x = 0;
            int parent_y = 0;
            int current_parent = elements[i].parent;
            while (current_parent != -1) {
                parent_x += elements[current_parent].x;
                parent_y += elements[current_parent].y;
                current_parent = elements[current_parent].parent;
            }

            int abs_x = parent_x + elements[i].x;
            int abs_y = parent_y + elements[i].y;

            if (x >= abs_x && x <= abs_x + elements[i].width &&
                ry >= abs_y && ry <= abs_y + elements[i].height) {
                if (strcmp(elements[i].type, "button") == 0) {
                    printf("Button '%s' clicked!\n", elements[i].label);
                } else if (strcmp(elements[i].type, "textfield") == 0) {
                    clicked_textfield_index = i;
                } else if (strcmp(elements[i].type, "checkbox") == 0) {
                    elements[i].is_checked = !elements[i].is_checked;
                    printf("Checkbox '%s' toggled to %s!\n", elements[i].label, elements[i].is_checked ? "true" : "false");
                }
            }
        }

        // Deactivate all textfields first
        for (int i = 0; i < num_elements; i++) {
            if (strcmp(elements[i].type, "textfield") == 0) {
                elements[i].is_active = 0;
            }
        }

        // Activate the clicked textfield
        if (clicked_textfield_index != -1) {
            elements[clicked_textfield_index].is_active = 1;
        }
        glutPostRedisplay(); // Redraw to show active textfield/cursor or checkbox state
    }
}

void keyboard(unsigned char key, int x, int y) {
    // Check for active textfield
    for (int i = 0; i < num_elements; i++) {
        if (strcmp(elements[i].type, "textfield") == 0 && elements[i].is_active) {
            if (key == 8) { // Backspace
                if (elements[i].cursor_pos > 0) {
                    elements[i].cursor_pos--;
                    elements[i].text_content[elements[i].cursor_pos] = '\0';
                }
            } else if (key == 13) { // Enter
                printf("Textfield content: %s\n", elements[i].text_content);
            } else if (key >= 32 && key <= 126) { // Printable characters
                if (elements[i].cursor_pos < sizeof(elements[i].text_content) - 1) {
                    elements[i].text_content[elements[i].cursor_pos] = key;
                    elements[i].cursor_pos++;
                    elements[i].text_content[elements[i].cursor_pos] = '\0';
                }
            }
            glutPostRedisplay();
            return;
        }
    }

    // If no textfield is active or key is not handled by textfield, check for global keys
    if (key == 27) { // ESC
        exit(0);
    }
}
