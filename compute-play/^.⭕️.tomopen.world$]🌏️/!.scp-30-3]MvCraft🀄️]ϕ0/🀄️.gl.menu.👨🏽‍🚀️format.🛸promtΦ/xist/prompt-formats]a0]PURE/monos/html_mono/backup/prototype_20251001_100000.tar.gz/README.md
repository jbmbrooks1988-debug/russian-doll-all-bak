# HTML Canvas Framework for OpenGL/GLUT Applications

This framework allows you to create 2D/3D games and applications using HTML-like markup with OpenGL/GLUT rendering.

## Features

- HTML-like UI elements (div, button, canvas)
- Mouse interaction (click, hover)
- Basic 2D rendering in canvas
- Simple 3D rendering example
- Relative positioning system
- External module integration
- CSV data sharing between modules

## Building and Running

### Prerequisites

- OpenGL development libraries
- GLUT development libraries
- GCC compiler

On Ubuntu/Debian:
```bash
sudo apt-get install libgl1-mesa-dev libglu1-mesa-dev freeglut3-dev
```

On CentOS/RHEL:
```bash
sudo yum install mesa-libGL-devel mesa-libGLU-devel freeglut-devel
```

### Compile

```bash
gcc -o main_prototype_0 main_prototype_0.c -lGL -lGLU -lglut
```

### Run

To run with the default UI structure:
```bash
./main_prototype_0
```

To run with a custom markup file:
```bash
./main_prototype_0 demo_ui.html
```

## Markup Format

The framework uses a simplified HTML-like syntax:

```html
<div id="element_id" pos="x,y,width,height" bg="#RRGGBB" fg="#RRGGBB" text="content" onclick="handler_function" />
```

- `pos`: Position and size in format "x,y,width,height"
- `bg`: Background color in hex format
- `fg`: Foreground (text) color in hex format
- `text`: Text content for elements that display text
- `onclick`: Name of function to call when element is clicked

## Architecture

- MVC + Modules design pattern
- Event-driven system
- Look-up tables (LUT) for element properties
- Finite State Machines (FSM) for component behavior
- No new header files (all in single .c file for simplicity)

## Demo Features

The demo project shows:
- A game interface with menu, sidebar, game canvas, and status bar
- Interactive buttons with hover effects
- 2D and 3D rendering in the canvas area
- External module integration
- Data sharing via CSV files