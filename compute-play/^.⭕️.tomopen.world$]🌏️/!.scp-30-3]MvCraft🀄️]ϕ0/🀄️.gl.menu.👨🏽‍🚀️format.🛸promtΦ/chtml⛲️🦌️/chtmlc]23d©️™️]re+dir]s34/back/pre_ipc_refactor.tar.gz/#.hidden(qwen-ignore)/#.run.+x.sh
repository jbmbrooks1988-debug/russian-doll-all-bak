#!/bin/bash
sh xh.compile.dir.link.+x.sh
cd module/
sh xsh.compile-all.+x.sh
cd .. 
./chtmlc]k17-gem.+x chtml/demo.chtml]b3]PURE.txt module/+x/game.+x

