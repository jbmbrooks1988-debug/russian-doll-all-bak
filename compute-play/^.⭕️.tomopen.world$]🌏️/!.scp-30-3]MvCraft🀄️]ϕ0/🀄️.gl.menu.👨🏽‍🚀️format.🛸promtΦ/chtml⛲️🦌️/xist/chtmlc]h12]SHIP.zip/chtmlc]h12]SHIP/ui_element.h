#ifndef UI_ELEMENT_H
#define UI_ELEMENT_H

#define MAX_ELEMENTS 50
#define MAX_TEXT_LINES 1000
#define MAX_LINE_LENGTH 512
#define CLIPBOARD_SIZE 10000

typedef struct {
    char type[20];
    int x, y, width, height;
    char id[50]; // Unique identifier for UI elements
    char label[50]; // Used for button label, text element value, and checkbox label
    // Multi-line text support - replace simple text_content with array of lines
    char text_content[MAX_TEXT_LINES][MAX_LINE_LENGTH];
    int num_lines; // Number of lines in the text
    int cursor_x; // X position of cursor (column)
    int cursor_y; // Y position of cursor (line number)
    int is_active; // For textfield active state
    int is_checked; // For checkbox checked state
    int slider_value; // For slider current value
    int slider_min; // For slider minimum value
    int slider_max; // For slider maximum value
    int slider_step; // For slider step increment
    float color[3];
    int parent;
    // Canvas-specific properties
    int canvas_initialized; // Flag to track if canvas has been initialized
    void (*canvas_render_func)(int x, int y, int width, int height); // Render function for canvas
    // Event handling
    char onClick[50]; // Store the onClick handler function name
    // Menu-specific properties
    int menu_items_count; // Number of submenu items
    int is_open; // For menus - whether they are currently open
    // Text selection properties
    int selection_start_x; // X position of selection start
    int selection_start_y; // Y position of selection start
    int selection_end_x;   // X position of selection end
    int selection_end_y;   // Y position of selection end
    int has_selection;     // Whether there is an active selection
    // Clipboard for this element
    char clipboard[CLIPBOARD_SIZE];
} UIElement;

// Global variables
extern UIElement elements[];
extern int num_elements;

// Function declarations for controller
void init_controller();
void mouse(int button, int state, int x, int y);
void keyboard(unsigned char key, int x, int y);
void special_keys(int key, int x, int y);
void run_module_handler();
void handle_ctrl_keys(unsigned char key, int element_index);
void copy_text(int element_index);
void cut_text(int element_index);
void paste_text(int element_index);
void delete_selection(int element_index);

// Function declarations for view
void init_view();
void display();
void reshape(int w, int h);
void draw_element(UIElement* el);

// Function declarations for model
void init_model();

#endif // UI_ELEMENT_H