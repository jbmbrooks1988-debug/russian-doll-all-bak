#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// We need the UIElement definition and the elements array from view.c
// In a real C application, you'd have a .h file for this.
typedef struct {
    char type[20];
    int x, y, width, height;
    char label[50];
    float color[3];
} UIElement;

extern UIElement elements[];
extern int num_elements;

void init_controller() {
    // Nothing to initialize for now
}

void mouse(int button, int state, int x, int y) {
    if (button == 0 && state == 1) { // Left mouse button up
        // GLUT's y is inverted from our coordinate system
        int ry = 600 - y; // 600 is the window height

        for (int i = 0; i < num_elements; i++) {
            if (strcmp(elements[i].type, "button") == 0) {
                if (x >= elements[i].x && x <= elements[i].x + elements[i].width &&
                    ry >= elements[i].y && ry <= elements[i].y + elements[i].height) {
                    printf("Button '%s' clicked!\n", elements[i].label);
                }
            }
        }
    }
}

void keyboard(unsigned char key, int x, int y) {
    // For now, we'll just have a simple exit key
    if (key == 27) { // ESC
        exit(0);
    }
}
