
# C-HTML Legend

This document describes the available elements and attributes in the C-HTML framework.

## Elements

### `<window>`

The root element of a C-HTML document.

**Attributes:**

*   `title` (string): The title of the application window.
*   `width` (int): The width of the window in pixels.
*   `height` (int): The height of the window in pixels.

### `<header>`

A container for header content.

**Attributes:**

*   `y` (int): The y-coordinate of the header.
*   `width` (int): The width of the header.
*   `height` (int): The height of the header.
*   `color` (hex): The background color of the header (e.g., "#333333").

### `<text>`

A static text element.

**Attributes:**

*   `value` (string): The text to display.
*   `x` (int): The x-coordinate of the text.
*   `y` (int): The y-coordinate of the text.
*   `color` (hex): The color of the text (e.g., "#FFFFFF").

### `<button>`

A clickable button.

**Attributes:**

*   `id` (string): A unique identifier for the button.
*   `x` (int): The x-coordinate of the button.
*   `y` (int): The y-coordinate of the button.
*   `width` (int): The width of the button.
*   `height` (int): The height of the button.
*   `label` (string): The text displayed on the button.
*   `onClick` (string): The name of the C function to call when the button is clicked.
