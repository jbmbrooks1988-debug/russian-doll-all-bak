
#include <GL/glut.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// For this prototype, we'll define a simple structure for UI elements
// and a hardcoded array to represent the parsed C-HTML file.

#define MAX_ELEMENTS 10

typedef struct {
    char type[20];
    int x, y, width, height;
    char label[50];
    float color[3];
} UIElement;

UIElement elements[MAX_ELEMENTS];
int num_elements = 0;

// Simple parser for our C-HTML format
void parse_chtml(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Error opening CHTML file");
        return;
    }

    char line[256];
    num_elements = 0;

    while (fgets(line, sizeof(line), file)) {
        char* type = strtok(line, " <>");
        if (!type) continue;

        if (strcmp(type, "window") == 0) {
            // Window properties are handled by glutCreateWindow for now
        } else {
            strcpy(elements[num_elements].type, type);
            char* attr = strtok(NULL, " \"=");
            while (attr) {
                char* value = strtok(NULL, " \"=");
                if (strcmp(attr, "x") == 0) elements[num_elements].x = atoi(value);
                else if (strcmp(attr, "y") == 0) elements[num_elements].y = atoi(value);
                else if (strcmp(attr, "width") == 0) elements[num_elements].width = atoi(value);
                else if (strcmp(attr, "height") == 0) elements[num_elements].height = atoi(value);
                else if (strcmp(attr, "label") == 0) strncpy(elements[num_elements].label, value, 49);
                else if (strcmp(attr, "value") == 0) strncpy(elements[num_elements].label, value, 49);
                else if (strcmp(attr, "color") == 0) {
                    // Basic hex color parsing
                    long color = strtol(value + 1, NULL, 16);
                    elements[num_elements].color[0] = ((color >> 16) & 0xFF) / 255.0f;
                    elements[num_elements].color[1] = ((color >> 8) & 0xFF) / 255.0f;
                    elements[num_elements].color[2] = (color & 0xFF) / 255.0f;
                }
                attr = strtok(NULL, " \"=");
            }
            num_elements++;
        }
    }

    fclose(file);
}

void init_view() {
    parse_chtml("demo.chtml");
}

void draw_element(UIElement* el) {
    if (strcmp(el->type, "header") == 0 || strcmp(el->type, "button") == 0) {
        glColor3fv(el->color);
        glBegin(GL_QUADS);
        glVertex2i(el->x, el->y);
        glVertex2i(el->x + el->width, el->y);
        glVertex2i(el->x + el->width, el->y + el->height);
        glVertex2i(el->x, el->y + el->height);
        glEnd();
    }

    if (strcmp(el->type, "text") == 0 || strcmp(el->type, "button") == 0) {
        glColor3f(1.0f, 1.0f, 1.0f);
        glRasterPos2i(el->x + 5, el->y + 15);
        for (char* c = el->label; *c != '\0'; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    for (int i = 0; i < num_elements; i++) {
        draw_element(&elements[i]);
    }

    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, 0, h);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
