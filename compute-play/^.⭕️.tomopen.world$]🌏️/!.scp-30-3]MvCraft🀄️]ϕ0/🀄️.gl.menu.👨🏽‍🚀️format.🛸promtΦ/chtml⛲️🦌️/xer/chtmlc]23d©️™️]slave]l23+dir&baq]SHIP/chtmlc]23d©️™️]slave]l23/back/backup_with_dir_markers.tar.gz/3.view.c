
#include <GL/glut.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <dirent.h>
#include <sys/stat.h>

// For this prototype, we'll define a simple structure for UI elements
// and a hardcoded array to represent the parsed C-HTML file.

#define MAX_ELEMENTS 50
#define MAX_TEXT_LINES 1000
#define MAX_LINE_LENGTH 512

// Forward declaration for canvas render function
void canvas_render_sample(int x, int y, int width, int height);

#define CLIPBOARD_SIZE 10000

typedef struct {
    char type[20];
    int x, y, width, height;
    char id[50]; // Unique identifier for UI elements
    char label[50]; // Used for button label, text element value, and checkbox label
    // Multi-line text support - replace simple text_content with array of lines
    char text_content[MAX_TEXT_LINES][MAX_LINE_LENGTH];
    int num_lines; // Number of lines in the text
    int cursor_x; // X position of cursor (column)
    int cursor_y; // Y position of cursor (line number)
    int is_active; // For textfield active state
    int is_checked; // For checkbox checked state
    int slider_value; // For slider current value
    int slider_min; // For slider minimum value
    int slider_max; // For slider maximum value
    int slider_step; // For slider step increment
    float color[3];
    int parent;
    // Canvas-specific properties
    int canvas_initialized; // Flag to track if canvas has been initialized
    void (*canvas_render_func)(int x, int y, int width, int height); // Render function for canvas
    char view_mode[10]; // View mode: "2d" or "3d"
    // Camera properties for 3D view
    float camera_pos[3]; // Camera position (x, y, z)
    float camera_target[3]; // Camera target (x, y, z)
    float camera_up[3]; // Camera up vector (x, y, z)
    float fov; // Field of view for 3D perspective
    // Event handling
    char onClick[50]; // Store the onClick handler function name
    // Menu-specific properties
    int menu_items_count; // Number of submenu items
    int is_open; // For menus - whether they are currently open
    // Text selection properties
    int selection_start_x; // X position of selection start
    int selection_start_y; // Y position of selection start
    int selection_end_x;   // X position of selection end
    int selection_end_y;   // Y position of selection end
    int has_selection;     // Whether there is an active selection
    // Clipboard for this element
    char clipboard[CLIPBOARD_SIZE];
    // Directory listing properties
    char dir_path[512]; // Directory path for directory listing elements
    char dir_entries[100][256]; // Store up to 100 directory entries
    int dir_entry_count; // Number of directory entries
    int dir_entry_selected; // Index of selected entry
} UIElement;

// Forward declaration for directory listing function after UIElement struct is defined
void load_directory_contents(UIElement* el);

UIElement elements[MAX_ELEMENTS];
int num_elements = 0;

// Global variables to store window dimensions
int window_width = 800;
int window_height = 600;

// FreeType variables for emoji rendering
FT_Library ft;
FT_Face emoji_face;
float emoji_scale = 1.0f;

// FreeType initialization for emoji rendering
void init_freetype() {
    if (FT_Init_FreeType(&ft)) {
        fprintf(stderr, "Could not init FreeType Library\n");
        // Don't exit since emoji support is optional
        return;
    }

    const char *emoji_font_path = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf";
    FT_Error err = FT_New_Face(ft, emoji_font_path, 0, &emoji_face);
    if (err) {
        fprintf(stderr, "Warning: Could not load emoji font at %s, emoji rendering will be disabled\n", emoji_font_path);
        FT_Done_FreeType(ft);
        return;
    }
    
    if (FT_IS_SCALABLE(emoji_face)) {
        err = FT_Set_Pixel_Sizes(emoji_face, 0, 32);  // Smaller size for UI elements
        if (err) {
            fprintf(stderr, "Warning: Could not set pixel size for emoji font\n");
            FT_Done_Face(emoji_face);
            FT_Done_FreeType(ft);
            return;
        }
    } else if (emoji_face->num_fixed_sizes > 0) {
        err = FT_Select_Size(emoji_face, 0);
        if (err) {
            fprintf(stderr, "Warning: Could not select size for emoji font\n");
            FT_Done_Face(emoji_face);
            FT_Done_FreeType(ft);
            return;
        }
    } else {
        fprintf(stderr, "Warning: No fixed sizes available in emoji font\n");
        FT_Done_Face(emoji_face);
        FT_Done_FreeType(ft);
        return;
    }
    
    int loaded_emoji_size = emoji_face->size->metrics.y_ppem;
    emoji_scale = 32.0f / (float)loaded_emoji_size;
    printf("Emoji font loaded, size: %d, scale: %f\n", loaded_emoji_size, emoji_scale);
}

// Function to decode UTF-8 character to Unicode codepoint
int decode_utf8(const unsigned char* str, unsigned int* codepoint) {
    if (str[0] < 0x80) {
        *codepoint = str[0];
        return 1;
    }
    if ((str[0] & 0xE0) == 0xC0) {
        if ((str[1] & 0xC0) == 0x80) {
            *codepoint = ((str[0] & 0x1F) << 6) | (str[1] & 0x3F);
            return 2;
        }
    }
    if ((str[0] & 0xF0) == 0xE0) {
        if ((str[1] & 0xC0) == 0x80 && (str[2] & 0xC0) == 0x80) {
            *codepoint = ((str[0] & 0x0F) << 12) | ((str[1] & 0x3F) << 6) | (str[2] & 0x3F);
            return 3;
        }
    }
    if ((str[0] & 0xF8) == 0xF0) {
        if ((str[1] & 0xC0) == 0x80 && (str[2] & 0xC0) == 0x80 && (str[3] & 0xC0) == 0x80) {
            *codepoint = ((str[0] & 0x07) << 18) | ((str[1] & 0x3F) << 12) | ((str[2] & 0x3F) << 6) | (str[3] & 0x3F);
            return 4;
        }
    }
    *codepoint = '?';
    return 1;
}

// Function to render a single emoji character at given position
void render_emoji(unsigned int codepoint, float x, float y) {
    if (!emoji_face) return; // Skip if emoji font not loaded
    
    FT_Error err = FT_Load_Char(emoji_face, codepoint, FT_LOAD_RENDER | FT_LOAD_COLOR);
    if (err) {
        fprintf(stderr, "Warning: Could not load glyph for codepoint U+%04X\n", codepoint);
        return;
    }

    FT_GlyphSlot slot = emoji_face->glyph;
    if (!slot->bitmap.buffer) {
        fprintf(stderr, "Warning: No bitmap for glyph U+%04X\n", codepoint);
        return;
    }

    // Handle different pixel modes
    GLint format = GL_RGBA;
    if (slot->bitmap.pixel_mode == FT_PIXEL_MODE_BGRA) {
        format = GL_BGRA;
    } else if (slot->bitmap.pixel_mode == FT_PIXEL_MODE_GRAY) {
        format = GL_LUMINANCE_ALPHA;
    }

    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, slot->bitmap.width, slot->bitmap.rows, 0, 
                 format, GL_UNSIGNED_BYTE, slot->bitmap.buffer);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    float scale_factor = emoji_scale;
    float w = slot->bitmap.width * scale_factor;
    float h = slot->bitmap.rows * scale_factor;
    
    // Calculate position so that emoji aligns with text baseline
    float x2 = x;
    float y2 = y;  // Position the emoji at the same baseline as regular text

    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 1.0); glVertex2f(x2, y2);
    glTexCoord2f(1.0, 1.0); glVertex2f(x2 + w, y2);
    glTexCoord2f(1.0, 0.0); glVertex2f(x2 + w, y2 + h);
    glTexCoord2f(0.0, 0.0); glVertex2f(x2, y2 + h);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, 0);
    glDeleteTextures(1, &texture);
    glColor3f(1.0f, 1.0f, 1.0f);
}

// Function to check if a string contains emoji characters
int contains_emoji(const char* str) {
    const unsigned char* s = (const unsigned char*)str;
    while (*s) {
        // Check for high Unicode values that are likely emojis
        unsigned int codepoint;
        int bytes = decode_utf8(s, &codepoint);
        if (codepoint >= 0x1F000) {  // Emoji range typically starts around U+1F000
            return 1;
        }
        // Also check for other emoji ranges
        if ((codepoint >= 0x2600 && codepoint <= 0x26FF) ||  // Misc symbols
            (codepoint >= 0x2700 && codepoint <= 0x27BF) ||  // Dingbats
            (codepoint >= 0x1F100 && codepoint <= 0x1F64F) ||  // Emoticons, etc.
            (codepoint >= 0x1F680 && codepoint <= 0x1F6FF) ||  // Transport & map symbols
            (codepoint >= 0x1F700 && codepoint <= 0x1F77F)) {  // Alchemical symbols
            return 1;
        }
        s += bytes;
    }
    return 0;
}

// Function to render text with emoji support
void render_text_with_emojis(const char* str, float x, float y, float color[3]) {
    glColor3fv(color);
    
    const unsigned char* s = (const unsigned char*)str;
    float current_x = x;
    float current_y = y;
    
    // Process the string character by character
    while (*s) {
        unsigned int codepoint;
        int bytes = decode_utf8(s, &codepoint);
        
        // Check if this character is an emoji
        int is_emoji = 0;
        if (codepoint >= 0x1F000 || 
            (codepoint >= 0x2600 && codepoint <= 0x26FF) ||  
            (codepoint >= 0x2700 && codepoint <= 0x27BF) ||  
            (codepoint >= 0x1F100 && codepoint <= 0x1F64F) ||  
            (codepoint >= 0x1F680 && codepoint <= 0x1F6FF) ||  
            (codepoint >= 0x1F700 && codepoint <= 0x1F77F)) {
            is_emoji = 1;
        }
        
        if (is_emoji) {
            // Render emoji using FreeType
            // Adjust the y position to align with text baseline - emojis might need vertical adjustment
            render_emoji(codepoint, current_x, current_y);  // Using same y as text baseline
            
            // Move position forward based on emoji advance width
            if (emoji_face && FT_Load_Char(emoji_face, codepoint, FT_LOAD_RENDER | FT_LOAD_COLOR) == 0) {
                current_x += emoji_face->glyph->advance.x >> 6; // advance is in 1/64th pixels
            } else {
                current_x += 32; // fallback width
            }
        } else {
            // For regular ASCII characters, we need to render with GLUT but properly spaced
            // Find the next emoji or end of string
            const unsigned char* next_ptr = s + bytes;
            while (*next_ptr) {
                unsigned int next_codepoint;
                int next_bytes = decode_utf8(next_ptr, &next_codepoint);
                
                if (next_codepoint >= 0x1F000 || 
                    (next_codepoint >= 0x2600 && next_codepoint <= 0x26FF) ||  
                    (next_codepoint >= 0x2700 && next_codepoint <= 0x27BF) ||  
                    (next_codepoint >= 0x1F100 && next_codepoint <= 0x1F64F) ||  
                    (next_codepoint >= 0x1F680 && next_codepoint <= 0x1F6FF) ||  
                    (next_codepoint >= 0x1F700 && next_codepoint <= 0x1F77F)) {
                    break; // Found next emoji
                }
                next_ptr += next_bytes;
            }
            
            // Create substring from s to next_ptr
            int segment_len = next_ptr - s;
            char* segment = malloc(segment_len + 1);
            strncpy(segment, (const char*)s, segment_len);
            segment[segment_len] = '\0';
            
            // Render this ASCII segment with GLUT at current position
            glRasterPos2f(current_x, current_y);
            for (char* c = segment; *c != '\0'; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
            }
            
            // Calculate the width of the rendered segment
            float segment_width = 0;
            for (char* c = segment; *c != '\0'; c++) {
                segment_width += glutBitmapWidth(GLUT_BITMAP_HELVETICA_18, *c);
            }
            current_x += segment_width;
            
            free(segment);
            
            // Update s to continue after the ASCII segment
            s = next_ptr;
            continue; // Continue the main loop without incrementing s again
        }
        
        s += bytes;
    }
    
    glColor3f(1.0f, 1.0f, 1.0f);
}

// Simple parser for our C-HTML format
void parse_chtml(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Error opening CHTML file");
        return;
    }

    char line[512]; // Increased buffer size for longer lines
    num_elements = 0;
    int parent_stack[MAX_ELEMENTS];
    int stack_top = -1;

    while (fgets(line, sizeof(line), file)) {
        // Trim leading/trailing whitespace
        char* trimmed_line = line;
        while (*trimmed_line == ' ' || *trimmed_line == '\t') trimmed_line++;
        size_t len = strlen(trimmed_line);
        while (len > 0 && (trimmed_line[len-1] == '\n' || trimmed_line[len-1] == '\r' || trimmed_line[len-1] == ' ' || trimmed_line[len-1] == '\t')) {
            trimmed_line[--len] = '\0';
        }

        if (len == 0) continue; // Skip empty lines

        // Check for closing tag
        if (trimmed_line[0] == '<' && trimmed_line[1] == '/') {
            if (stack_top > -1) {
                stack_top--;
            }
            continue;
        }

        // Check for opening tag
        if (trimmed_line[0] != '<') continue;

        // Extract tag name
        char* tag_start = trimmed_line + 1;
        char* tag_end = strchr(tag_start, ' ');
        if (!tag_end) tag_end = strchr(tag_start, '>');
        if (!tag_end) continue; // Malformed tag

        char tag_name[50];
        strncpy(tag_name, tag_start, tag_end - tag_start);
        tag_name[tag_end - tag_start] = '\0';

        if (num_elements >= MAX_ELEMENTS) {
            fprintf(stderr, "Error: Max elements reached!\n");
            break;
        }

        elements[num_elements].parent = (stack_top > -1) ? parent_stack[stack_top] : -1;
        strcpy(elements[num_elements].type, tag_name);
        elements[num_elements].id[0] = '\0'; // Initialize ID to empty string
        elements[num_elements].is_active = 0;
        elements[num_elements].cursor_x = 0;
        elements[num_elements].cursor_y = 0;
        elements[num_elements].num_lines = 1;
        // Initialize all lines to empty
        for (int line_idx = 0; line_idx < MAX_TEXT_LINES; line_idx++) {
            elements[num_elements].text_content[line_idx][0] = '\0';
        }
        // For textfield and textarea, set first line to the value attribute
        if (strcmp(tag_name, "textfield") == 0 || strcmp(tag_name, "textarea") == 0) {
            // Find the value attribute and set the first line
            char* attr_start = tag_end;
            while (attr_start && (attr_start = strstr(attr_start, " ")) != NULL) {
                attr_start++; // Move past space
                char* eq_sign = strchr(attr_start, '=');
                if (!eq_sign) break; // No more attributes

                char attr_name[50];
                strncpy(attr_name, attr_start, eq_sign - attr_start);
                attr_name[eq_sign - attr_start] = '\0';

                char* value_start = eq_sign + 1;
                if (*value_start != '"') break; // Value not quoted
                value_start++; // Move past opening quote

                char* value_end = strchr(value_start, '"');
                if (!value_end) break; // No closing quote

                char attr_value[256];
                strncpy(attr_value, value_start, value_end - value_start);
                attr_value[value_end - value_start] = '\0';

                if (strcmp(attr_name, "value") == 0) {
                    // Handle multi-line value by splitting on &#10; (HTML newline entity)
                    int line_idx = 0;
                    char* token = strtok(attr_value, "&#10;");
                    while (token != NULL && line_idx < MAX_TEXT_LINES) {
                        strncpy(elements[num_elements].text_content[line_idx], token, MAX_LINE_LENGTH - 1);
                        elements[num_elements].text_content[line_idx][MAX_LINE_LENGTH - 1] = '\0';
                        token = strtok(NULL, "&#10;");
                        line_idx++;
                    }
                    elements[num_elements].num_lines = line_idx > 0 ? line_idx : 1;
                    break;
                }
                attr_start = value_end + 1;
            }
        }
        elements[num_elements].selection_start_x = 0;
        elements[num_elements].selection_start_y = 0;
        elements[num_elements].selection_end_x = 0;
        elements[num_elements].selection_end_y = 0;
        elements[num_elements].has_selection = 0;
        elements[num_elements].clipboard[0] = '\0'; // Initialize clipboard to empty
        elements[num_elements].is_checked = 0;
        elements[num_elements].slider_value = 0;
        elements[num_elements].slider_min = 0;
        elements[num_elements].slider_max = 100;
        elements[num_elements].slider_step = 1;
        elements[num_elements].canvas_initialized = 0;
        elements[num_elements].canvas_render_func = NULL;
        strcpy(elements[num_elements].view_mode, "2d"); // Default to 2D view
        // Initialize camera properties for 3D
        elements[num_elements].camera_pos[0] = 0.0f;
        elements[num_elements].camera_pos[1] = 0.0f;
        elements[num_elements].camera_pos[2] = 5.0f; // Position camera in front of scene
        elements[num_elements].camera_target[0] = 0.0f;
        elements[num_elements].camera_target[1] = 0.0f;
        elements[num_elements].camera_target[2] = 0.0f; // Look at origin
        elements[num_elements].camera_up[0] = 0.0f;
        elements[num_elements].camera_up[1] = 1.0f;
        elements[num_elements].camera_up[2] = 0.0f; // Y is up
        elements[num_elements].fov = 45.0f; // Default field of view
        elements[num_elements].onClick[0] = '\0'; // Initialize onClick to empty string
        elements[num_elements].menu_items_count = 0;
        elements[num_elements].is_open = 0;
        strcpy(elements[num_elements].dir_path, ".");
        elements[num_elements].dir_entry_count = 0;
        elements[num_elements].dir_entry_selected = -1;

        // Parse attributes
        char* attr_start = tag_end;
        while (attr_start && (attr_start = strstr(attr_start, " ")) != NULL) {
            attr_start++; // Move past space
            char* eq_sign = strchr(attr_start, '=');
            if (!eq_sign) break; // No more attributes

            char attr_name[50];
            strncpy(attr_name, attr_start, eq_sign - attr_start);
            attr_name[eq_sign - attr_start] = '\0';

            char* value_start = eq_sign + 1;
            if (*value_start != '\"') break; // Value not quoted
            value_start++; // Move past opening quote

            char* value_end = strchr(value_start, '\"');
            if (!value_end) break; // No closing quote

            char attr_value[256];
            strncpy(attr_value, value_start, value_end - value_start);
            attr_value[value_end - value_start] = '\0';

            if (strcmp(attr_name, "x") == 0) elements[num_elements].x = atoi(attr_value);
            else if (strcmp(attr_name, "y") == 0) elements[num_elements].y = atoi(attr_value);
            else if (strcmp(attr_name, "width") == 0) elements[num_elements].width = atoi(attr_value);
            else if (strcmp(attr_name, "height") == 0) elements[num_elements].height = atoi(attr_value);
            else if (strcmp(attr_name, "id") == 0) strncpy(elements[num_elements].id, attr_value, 49);
            else if (strcmp(attr_name, "label") == 0) strncpy(elements[num_elements].label, attr_value, 49);
            else if (strcmp(attr_name, "value") == 0) {
                if (strcmp(elements[num_elements].type, "textfield") == 0 || strcmp(elements[num_elements].type, "textarea") == 0) {
                    // For textfield and textarea, set first line to the value attribute
                    // Handle multi-line value by splitting on &#10; (HTML newline entity)
                    int line_idx = 0;
                    char* temp_value = malloc(strlen(attr_value) + 1);
                    strcpy(temp_value, attr_value);
                    char* token = strtok(temp_value, "&#10;");
                    while (token != NULL && line_idx < MAX_TEXT_LINES) {
                        strncpy(elements[num_elements].text_content[line_idx], token, MAX_LINE_LENGTH - 1);
                        elements[num_elements].text_content[line_idx][MAX_LINE_LENGTH - 1] = '\0';
                        token = strtok(NULL, "&#10;");
                        line_idx++;
                    }
                    elements[num_elements].num_lines = line_idx > 0 ? line_idx : 1;
                    // Set cursor to end of first line
                    elements[num_elements].cursor_x = (line_idx > 0) ? strlen(elements[num_elements].text_content[0]) : 0;
                    elements[num_elements].cursor_y = 0;
                    free(temp_value);
                } else if (strcmp(elements[num_elements].type, "slider") == 0) {
                    elements[num_elements].slider_value = atoi(attr_value);
                } else if (strcmp(elements[num_elements].type, "text") == 0) {
                    // For text elements, store the value in the label field
                    strncpy(elements[num_elements].label, attr_value, 49);
                }
            }
            else if (strcmp(attr_name, "checked") == 0) {
                if (strcmp(attr_value, "true") == 0) {
                    elements[num_elements].is_checked = 1;
                }
            }
            else if (strcmp(attr_name, "min") == 0) elements[num_elements].slider_min = atoi(attr_value);
            else if (strcmp(attr_name, "max") == 0) elements[num_elements].slider_max = atoi(attr_value);
            else if (strcmp(attr_name, "step") == 0) elements[num_elements].slider_step = atoi(attr_value);
            else if (strcmp(attr_name, "color") == 0) {
                long color = strtol(attr_value + 1, NULL, 16);
                elements[num_elements].color[0] = ((color >> 16) & 0xFF) / 255.0f;
                elements[num_elements].color[1] = ((color >> 8) & 0xFF) / 255.0f;
                elements[num_elements].color[2] = (color & 0xFF) / 255.0f;
            }
            else if (strcmp(attr_name, "onClick") == 0) {
                strncpy(elements[num_elements].onClick, attr_value, 49);
                elements[num_elements].onClick[49] = '\0'; // Ensure null termination
            }
            else if (strcmp(attr_name, "view_mode") == 0 || strcmp(attr_name, "viewMode") == 0) {
                // Support both view_mode and viewMode for consistency
                strncpy(elements[num_elements].view_mode, attr_value, 9);
                elements[num_elements].view_mode[9] = '\0'; // Ensure null termination
            }
            attr_start = value_end + 1;
        }

        // Ensure slider_value is within min/max bounds after parsing all attributes
        if (strcmp(elements[num_elements].type, "slider") == 0) {
            if (elements[num_elements].slider_value < elements[num_elements].slider_min) {
                elements[num_elements].slider_value = elements[num_elements].slider_min;
            }
            if (elements[num_elements].slider_value > elements[num_elements].slider_max) {
                elements[num_elements].slider_value = elements[num_elements].slider_max;
            }
        }

        if (strcmp(tag_name, "panel") == 0) {
            stack_top++;
            parent_stack[stack_top] = num_elements;
        }
        else if (strcmp(tag_name, "canvas") == 0) {
            // Assign a default render function to canvas elements
            elements[num_elements].canvas_render_func = canvas_render_sample;
            stack_top++;
            parent_stack[stack_top] = num_elements;
        }
        else if (strcmp(tag_name, "menu") == 0) {
            elements[num_elements].menu_items_count = 0; // Initialize to 0, will be updated during parsing
            stack_top++;
            parent_stack[stack_top] = num_elements;
        }
        else if (strcmp(tag_name, "menuitem") == 0) {
            // menuitem elements don't change the stack (they don't contain other elements)
            // but need to increment the parent's menu_items_count
            if (stack_top >= 0) {
                int parent_index = parent_stack[stack_top];
                if (strcmp(elements[parent_index].type, "menu") == 0) {
                    elements[parent_index].menu_items_count++;
                }
            }
        }

        num_elements++;
    }

    fclose(file);
}

void init_view(const char* filename) {
    init_freetype();  // Initialize FreeType for emoji rendering
    parse_chtml(filename);
}

void draw_element(UIElement* el) {
    int parent_x = 0;
    int parent_y = 0;

    if (el->parent != -1) {
        parent_x = elements[el->parent].x;
        parent_y = elements[el->parent].y;
    }

    int abs_x = parent_x + el->x;
    int abs_y = parent_y + el->y;

    if (strcmp(el->type, "canvas") == 0) {
        // Draw a border for the canvas
        glColor3f(0.5f, 0.5f, 0.5f); // Gray border
        glBegin(GL_LINE_LOOP);
        glVertex2i(abs_x, abs_y);
        glVertex2i(abs_x + el->width, abs_y);
        glVertex2i(abs_x + el->width, abs_y + el->height);
        glVertex2i(abs_x, abs_y + el->height);
        glEnd();
        
        // Draw canvas content without changing global OpenGL state
        if (el->canvas_render_func != NULL) {
            // Save the current modelview matrix
            glPushMatrix();
            
            // Check view mode and set up appropriate projection
            if (strcmp(el->view_mode, "3d") == 0) {
                // Switch to projection matrix to set up 3D view
                glMatrixMode(GL_PROJECTION);
                glPushMatrix(); // Save current projection matrix
                glLoadIdentity();
                
                // Set up perspective projection for 3D
                gluPerspective(el->fov, (double)el->width/(double)el->height, 0.1, 100.0);
                
                // Switch back to modelview matrix for drawing
                glMatrixMode(GL_MODELVIEW);
                
                // Set up camera view
                gluLookAt(
                    el->camera_pos[0], el->camera_pos[1], el->camera_pos[2],  // Camera position
                    el->camera_target[0], el->camera_target[1], el->camera_target[2],  // Look at point
                    el->camera_up[0], el->camera_up[1], el->camera_up[2]  // Up vector
                );
            }
            
            // Apply transformation to move to canvas position (only in 2D mode)
            if (strcmp(el->view_mode, "3d") == 0) {
                // In 3D mode, we've already set up the camera, so no translation needed
                // The canvas position will be handled in the render function if needed
            } else {
                // In 2D mode, apply translation to canvas position
                glTranslatef(abs_x, abs_y, 0.0f);
            }
            
            // Call the canvas render function, adjusting the coordinates it receives
            // The function will draw in the local coordinate system
            el->canvas_render_func(0, 0, el->width, el->height);
            
            // Restore projection matrix if we were in 3D mode
            if (strcmp(el->view_mode, "3d") == 0) {
                glMatrixMode(GL_PROJECTION);
                glPopMatrix(); // Restore previous projection matrix
                glMatrixMode(GL_MODELVIEW);
            }
            
            // Restore the modelview matrix
            glPopMatrix();
        }
    } else if (strcmp(el->type, "menu") == 0) {
        // Draw menu bar background
        glColor3fv(el->color);
        glBegin(GL_QUADS);
        glVertex2i(abs_x, abs_y);
        glVertex2i(abs_x + el->width, abs_y);
        glVertex2i(abs_x + el->width, abs_y + el->height);
        glVertex2i(abs_x, abs_y + el->height);
        glEnd();
        
        // Draw menu text - center it vertically in the menu bar
        glColor3f(1.0f, 1.0f, 1.0f);
        int text_offset_x = 5;
        // Center the text vertically: start from the bottom of the menu and add centered offset
        int text_offset_y = (el->height / 2) - 6;  // Adjusted to position text properly in menu
        glRasterPos2i(abs_x + text_offset_x, abs_y + text_offset_y);
        for (char* c = el->label; *c != '\0'; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }
        
        // If menu is open, draw submenu items
        if (el->is_open) {
            // Calculate submenu position - need to check if it would go outside window bounds
            int submenu_start_y = abs_y + el->height;
            int submenu_end_y = abs_y + el->height + 20 * el->menu_items_count;
            
            // If submenu would go outside window bounds, draw it above the menu instead
            if (submenu_end_y > window_height) {
                submenu_start_y = abs_y - 20 * el->menu_items_count;
                if (submenu_start_y < 0) {
                    submenu_start_y = 0; // Ensure it doesn't go above the window
                }
            }
            
            glColor3f(1.0f, 1.0f, 0.0f); // Bright yellow for submenu background to make it visible
            glBegin(GL_QUADS);
            glVertex2i(abs_x, submenu_start_y); // Position submenu appropriately
            glVertex2i(abs_x + el->width, submenu_start_y);
            glVertex2i(abs_x + el->width, submenu_start_y + 20 * el->menu_items_count); // Each item is ~20px high
            glVertex2i(abs_x, submenu_start_y + 20 * el->menu_items_count);
            glEnd();
            
            // Draw submenu items explicitly here
            for (int i = 0; i < num_elements; i++) {
                if (elements[i].parent == (el - elements) && strcmp(elements[i].type, "menuitem") == 0) {
                    // Calculate position of this item in the submenu
                    int item_position = 0;
                    for (int j = 0; j < num_elements; j++) {
                        if (elements[j].parent == (el - elements) && 
                            strcmp(elements[j].type, "menuitem") == 0) {
                            if (j == i) { // If this is our element
                                break;
                            }
                            item_position++;
                        }
                    }
                    
                    // Calculate the y position for this specific menu item
                    int item_y = submenu_start_y + item_position * 20;
                    
                    // Draw the submenu item
                    glColor3f(0.7f, 0.7f, 0.9f); // Light blue for menu items
                    glBegin(GL_QUADS);
                    glVertex2i(abs_x, item_y);
                    glVertex2i(abs_x + elements[i].width, item_y);
                    glVertex2i(abs_x + elements[i].width, item_y + 20);
                    glVertex2i(abs_x, item_y + 20);
                    glEnd();
                    
                    // Draw menu item text
                    glColor3f(0.0f, 0.0f, 0.0f); // Black text for menu items
                    glRasterPos2i(abs_x + 5, item_y + 15);
                    for (char* c = elements[i].label; *c != '\0'; c++) {
                        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
                    }
                }
            }
        }
    } else if (strcmp(el->type, "menuitem") == 0) {
        // Draw menu item - only if it's not part of an open menu (since those are drawn in the menu section)
        int parent_menu_index = el->parent;
        
        if (!(parent_menu_index != -1 && 
              strcmp(elements[parent_menu_index].type, "menu") == 0 && 
              elements[parent_menu_index].is_open)) {
            // Draw menu item in its original position only if its parent menu is not open
            // Draw menu item
            glColor3fv(el->color);
            glBegin(GL_QUADS);
            glVertex2i(abs_x, abs_y);
            glVertex2i(abs_x + el->width, abs_y);
            glVertex2i(abs_x + el->width, abs_y + el->height);
            glVertex2i(abs_x, abs_y + el->height);
            glEnd();
            
            // Draw menu item text
            glColor3f(0.0f, 0.0f, 0.0f); // Black text for menu items
            glRasterPos2i(abs_x + 5, abs_y + 15);
            for (char* c = el->label; *c != '\0'; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
        }
        // If the parent menu IS open, menuitems are drawn in the menu section instead
    } else if (strcmp(el->type, "dirlist") == 0) {
        // Draw directory listing background
        glColor3f(0.2f, 0.2f, 0.2f); // Dark gray background
        glBegin(GL_QUADS);
        glVertex2i(abs_x, abs_y);
        glVertex2i(abs_x + el->width, abs_y);
        glVertex2i(abs_x + el->width, abs_y + el->height);
        glVertex2i(abs_x, abs_y + el->height);
        glEnd();

        // Load directory contents if not already loaded
        if (el->dir_entry_count == 0) {
            load_directory_contents(el);
        }

        // Draw "dir element list:" header
        glColor3f(1.0f, 1.0f, 0.0f); // Yellow text for header
        glRasterPos2i(abs_x + 5, abs_y + 15);
        const char* header_text = "dir element list:";
        for (const char* c = header_text; *c != '\0'; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }

        // Draw directory entries
        glColor3f(1.0f, 1.0f, 1.0f); // White text for entries
        int line_height = 20;
        for (int i = 0; i < el->dir_entry_count && i < 20; i++) { // Limit to 20 entries for now
            int text_y = abs_y + 40 + (i * line_height); // Start below header
            if (text_y + line_height < abs_y + el->height) { // Make sure we don't draw outside bounds
                // Highlight selected entry
                if (i == el->dir_entry_selected) {
                    glColor3f(0.5f, 0.5f, 1.0f); // Light blue for selected
                    glBegin(GL_QUADS);
                    glVertex2i(abs_x + 5, text_y - 15);
                    glVertex2i(abs_x + el->width - 5, text_y - 15);
                    glVertex2i(abs_x + el->width - 5, text_y + 5);
                    glVertex2i(abs_x + 5, text_y + 5);
                    glEnd();
                    glColor3f(1.0f, 1.0f, 1.0f); // Reset to white for text
                }
                
                glRasterPos2i(abs_x + 10, text_y);
                for (const char* c = el->dir_entries[i]; *c != '\0'; c++) {
                    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
                }
            }
        }
    } else if (strcmp(el->type, "header") == 0 || strcmp(el->type, "button") == 0 || strcmp(el->type, "panel") == 0 || strcmp(el->type, "textfield") == 0 || strcmp(el->type, "checkbox") == 0 || strcmp(el->type, "slider") == 0) {
    } else if (strcmp(el->type, "header") == 0 || strcmp(el->type, "button") == 0 || strcmp(el->type, "panel") == 0 || strcmp(el->type, "textfield") == 0 || strcmp(el->type, "checkbox") == 0 || strcmp(el->type, "slider") == 0) {
        if (strcmp(el->type, "textfield") == 0) {
            glColor3f(0.1f, 0.1f, 0.1f); // Dark background for textfield
        } else if (strcmp(el->type, "checkbox") == 0) {
            glColor3f(0.8f, 0.8f, 0.8f); // Light background for checkbox square
        } else if (strcmp(el->type, "slider") == 0) {
            glColor3f(0.3f, 0.3f, 0.3f); // Dark background for slider track
        } else {
            glColor3fv(el->color);
        }
        glBegin(GL_QUADS);
        glVertex2i(abs_x, abs_y);
        glVertex2i(abs_x + el->width, abs_y);
        glVertex2i(abs_x + el->width, abs_y + el->height);
        glVertex2i(abs_x, abs_y + el->height);
        glEnd();

        if (strcmp(el->type, "checkbox") == 0 && el->is_checked) {
            // Draw a simple checkmark (upright V shape, adjusted for inverted Y)
            glColor3f(0.0f, 0.0f, 0.0f); // Black checkmark
            glLineWidth(2.0f);
            glBegin(GL_LINES);
            // First segment: bottom-left to top-middle
            glVertex2i(abs_x + el->width * 0.2, abs_y + el->height * 0.8); // Visually lower
            glVertex2i(abs_x + el->width * 0.4, abs_y + el->height * 0.2); // Visually higher
            // Second segment: top-middle to bottom-right
            glVertex2i(abs_x + el->width * 0.4, abs_y + el->height * 0.2); // Visually higher
            glVertex2i(abs_x + el->width * 0.8, abs_y + el->height * 0.8); // Visually lower
            glEnd();
            glLineWidth(1.0f);
        } else if (strcmp(el->type, "slider") == 0) {
            // Draw slider thumb
            float thumb_pos_x = abs_x + (float)(el->slider_value - el->slider_min) / (el->slider_max - el->slider_min) * (el->width - 10); // 10 is thumb width
            glColor3f(0.8f, 0.8f, 0.8f); // Light grey for thumb
            glBegin(GL_QUADS);
            glVertex2i(thumb_pos_x, abs_y);
            glVertex2i(thumb_pos_x + 10, abs_y);
            glVertex2i(thumb_pos_x + 10, abs_y + el->height);
            glVertex2i(thumb_pos_x, abs_y + el->height);
            glEnd();

            // Draw slider value as text
            char value_str[10];
            sprintf(value_str, "%d", el->slider_value);
            glColor3f(1.0f, 1.0f, 1.0f);
            glRasterPos2i(abs_x + el->width + 5, abs_y + el->height / 2 - 5);
            for (char* c = value_str; *c != '\0'; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
        }
    }

    if (strcmp(el->type, "text") == 0 || strcmp(el->type, "button") == 0 || strcmp(el->type, "checkbox") == 0) {
        // Check if the text contains emojis
        if (contains_emoji(el->label)) {
            // Use emoji-aware text rendering
            int text_offset_x = 5;
            int text_offset_y = 15;
            if (strcmp(el->type, "checkbox") == 0) {
                text_offset_x = el->width + 5; // Label next to checkbox
                text_offset_y = el->height / 2 - 5; // Center label vertically
            }
            
            float text_color[3] = {1.0f, 1.0f, 1.0f}; // Default white
            float text_pos_x = abs_x + text_offset_x;
            float text_pos_y = abs_y + text_offset_y + 15; // Use slightly adjusted Y to align with text baseline
            
            render_text_with_emojis(el->label, text_pos_x, text_pos_y, text_color); // Use original approach
        } else {
            // Use original GLUT rendering for non-emoji text
            glColor3f(1.0f, 1.0f, 1.0f);
            int text_offset_x = 5;
            int text_offset_y = 15;
            if (strcmp(el->type, "checkbox") == 0) {
                text_offset_x = el->width + 5; // Label next to checkbox
                text_offset_y = el->height / 2 - 5; // Center label vertically
            }
            glRasterPos2i(abs_x + text_offset_x, abs_y + text_offset_y);
            for (char* c = el->label; *c != '\0'; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
            }
        }
    } else if (strcmp(el->type, "textfield") == 0) {
        // Draw multi-line text, with emoji support when needed
        int line_height = 20; // Approximate height for each line
        int start_y = abs_y + 15; // Starting y position for first line
        
        for (int line = 0; line < el->num_lines; line++) {
            if (start_y + (line * line_height) >= abs_y + el->height) break; // Don't draw outside bounds
            
            if (contains_emoji(el->text_content[line])) {
                // Use emoji-aware text rendering
                float text_color[3] = {1.0f, 1.0f, 1.0f}; // White color for textfield
                float text_pos_x = abs_x + 5;
                float text_pos_y = start_y + (line * line_height) + 15; // Use slightly adjusted Y to align with text baseline
                
                render_text_with_emojis(el->text_content[line], text_pos_x, text_pos_y, text_color); // Use original approach
            } else {
                // Use original GLUT rendering for non-emoji text
                glRasterPos2i(abs_x + 5, start_y + (line * line_height));
                for (char* c = el->text_content[line]; *c != '\0'; c++) {
                    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
                }
            }
        }

        // Draw cursor if active
        if (el->is_active) {
            // Simple blinking cursor (toggle every 500ms)
            if ((glutGet(GLUT_ELAPSED_TIME) / 500) % 2) {
                int text_width = 0;
                for (int i = 0; i < el->cursor_x && i < (int)strlen(el->text_content[el->cursor_y]); i++) {
                    text_width += glutBitmapWidth(GLUT_BITMAP_HELVETICA_18, el->text_content[el->cursor_y][i]);
                }
                glColor3f(1.0f, 1.0f, 1.0f);
                glBegin(GL_QUADS);
                glVertex2i(abs_x + 5 + text_width, start_y + (el->cursor_y * line_height) - 15);
                glVertex2i(abs_x + 5 + text_width + 2, start_y + (el->cursor_y * line_height) - 15);
                glVertex2i(abs_x + 5 + text_width + 2, start_y + (el->cursor_y * line_height) + 5);
                glVertex2i(abs_x + 5 + text_width, start_y + (el->cursor_y * line_height) + 5);
                glEnd();
            }
        }
    }
}

// Function to cleanup FreeType resources
// Function to load directory contents
void load_directory_contents(UIElement* el) {
    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char full_path[1024];
    
    // Clear previous entries
    el->dir_entry_count = 0;
    
    dir = opendir(el->dir_path);
    if (dir == NULL) {
        perror("Error opening directory");
        return;
    }
    
    // Read directory entries
    while ((entry = readdir(dir)) != NULL && el->dir_entry_count < 100) {
        // Create full path for stat
        snprintf(full_path, sizeof(full_path), "%s/%s", el->dir_path, entry->d_name);
        
        // Get file stats
        if (stat(full_path, &file_stat) == 0) {
            // Check if it's a directory
            if (S_ISDIR(file_stat.st_mode)) {
                // Append "/" to directory names
                char dir_name[260];  // Slightly larger than 255 to accommodate "/"
                snprintf(dir_name, sizeof(dir_name), "%s/", entry->d_name);
                strncpy(el->dir_entries[el->dir_entry_count], dir_name, 255);
                el->dir_entries[el->dir_entry_count][255] = '\0';
            } else {
                // Store regular file name without modification
                strncpy(el->dir_entries[el->dir_entry_count], entry->d_name, 255);
                el->dir_entries[el->dir_entry_count][255] = '\0';
            }
            el->dir_entry_count++;
        }
    }
    
    closedir(dir);
    printf("Loaded %d directory entries from %s\n", el->dir_entry_count, el->dir_path);
}

void cleanup_freetype() {
    if (emoji_face) {
        FT_Done_Face(emoji_face);
        emoji_face = NULL;
    }
    if (ft) {
        FT_Done_FreeType(ft);
        ft = 0;
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw all regular elements first
    for (int i = 0; i < num_elements; i++) {
        // Draw the element but don't draw submenu items here
        // (they'll be drawn separately to ensure they appear on top)
        if (strcmp(elements[i].type, "menuitem") == 0 && 
            elements[i].parent != -1 && 
            strcmp(elements[elements[i].parent].type, "menu") == 0 &&
            elements[elements[i].parent].is_open) {
            // Skip drawing menuitems that are part of an open menu here
            // They will be drawn with the menu in the next step
        } else {
            draw_element(&elements[i]);
        }
    }

    // Draw submenu items separately to ensure they appear on top of everything else
    for (int i = 0; i < num_elements; i++) {
        if (strcmp(elements[i].type, "menu") == 0 && elements[i].is_open) {
            // Draw this open menu's submenu items
            // Calculate absolute position of menu
            int parent_x = 0;
            int parent_y = 0;
            int current_parent = elements[i].parent;
            while (current_parent != -1) {
                parent_x += elements[current_parent].x;
                parent_y += elements[current_parent].y;
                current_parent = elements[current_parent].parent;
            }

            int abs_x = parent_x + elements[i].x;
            int abs_y = parent_y + elements[i].y;
            
            // Calculate submenu position - need to check if it would go outside window bounds
            int submenu_start_y = abs_y + elements[i].height;
            int submenu_end_y = abs_y + elements[i].height + 20 * elements[i].menu_items_count;
            
            // If submenu would go outside window bounds, draw it above the menu instead
            if (submenu_end_y > window_height) {
                submenu_start_y = abs_y - 20 * elements[i].menu_items_count;
                if (submenu_start_y < 0) {
                    submenu_start_y = 0; // Ensure it doesn't go above the window
                }
            }
            
            // Draw submenu background
            glColor3f(1.0f, 1.0f, 0.0f); // Bright yellow for submenu background to make it visible
            glBegin(GL_QUADS);
            glVertex2i(abs_x, submenu_start_y); // Position submenu appropriately
            glVertex2i(abs_x + elements[i].width, submenu_start_y);
            glVertex2i(abs_x + elements[i].width, submenu_start_y + 20 * elements[i].menu_items_count); // Each item is ~20px high
            glVertex2i(abs_x, submenu_start_y + 20 * elements[i].menu_items_count);
            glEnd();
            
            // Draw submenu items
            for (int j = 0; j < num_elements; j++) {
                if (elements[j].parent == i && strcmp(elements[j].type, "menuitem") == 0) {
                    // Calculate position of this item in the submenu
                    int item_position = 0;
                    for (int k = 0; k < num_elements; k++) {
                        if (elements[k].parent == i && 
                            strcmp(elements[k].type, "menuitem") == 0) {
                            if (k == j) { // If this is our element
                                break;
                            }
                            item_position++;
                        }
                    }
                    
                    // Calculate the y position for this specific menu item
                    int item_y = submenu_start_y + item_position * 20;
                    
                    // Draw the submenu item
                    glColor3f(0.7f, 0.7f, 0.9f); // Light blue for menu items
                    glBegin(GL_QUADS);
                    glVertex2i(abs_x, item_y);
                    glVertex2i(abs_x + elements[j].width, item_y);
                    glVertex2i(abs_x + elements[j].width, item_y + 20);
                    glVertex2i(abs_x, item_y + 20);
                    glEnd();
                    
                    // Draw menu item text
                    glColor3f(0.0f, 0.0f, 0.0f); // Black text for menu items
                    glRasterPos2i(abs_x + 5, item_y + 15);
                    for (char* c = elements[j].label; *c != '\0'; c++) {
                        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
                    }
                }
            }
        }
    }

    glutSwapBuffers();
}

// Sample canvas rendering function
void canvas_render_sample(int x, int y, int width, int height) {
    // Find which canvas element is being rendered by matching dimensions
    // We'll use a simple approach by checking the global elements array
    UIElement* current_canvas = NULL;
    for (int i = 0; i < num_elements; i++) {
        if (strcmp(elements[i].type, "canvas") == 0 && 
            elements[i].width == width && 
            elements[i].height == height) {
            // We found our canvas - this is a basic approach that assumes unique dimensions
            // In a more robust implementation, we might pass the index differently
            current_canvas = &elements[i];
            break;
        }
    }
    
    // If we found the canvas or if we default to 2D rendering
    int is_3d = (current_canvas && strcmp(current_canvas->view_mode, "3d") == 0);
    
    if (is_3d) {
        // 3D Rendering Mode
        // Set up lighting and materials for 3D objects
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
        
        // Set up light
        GLfloat light_pos[] = {5.0f, 5.0f, 5.0f, 1.0f};
        glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
        
        // Draw a simple floor/grid for 3D scene
        glColor3f(0.7f, 0.7f, 0.7f); // Light gray for floor
        glBegin(GL_QUADS);
        glNormal3f(0.0f, 1.0f, 0.0f); // Normal pointing up
        glVertex3f(-10.0f, 0.0f, -10.0f);
        glVertex3f(10.0f, 0.0f, -10.0f);
        glVertex3f(10.0f, 0.0f, 10.0f);
        glVertex3f(-10.0f, 0.0f, 10.0f);
        glEnd();
        
        // Load player position from output.csv and draw 3D cube
        FILE* out_fp = fopen("output.csv", "r");
        if (out_fp) {
            int player_x, player_y;
            if (fscanf(out_fp, "%d,%d", &player_x, &player_y) == 2) {
                // Convert 2D coordinates to 3D space
                float x_3d = (float)player_x / (float)width * 10.0f - 5.0f; // Map to -5 to 5 range
                float z_3d = (float)player_y / (float)height * 10.0f - 5.0f; // Map to -5 to 5 range
                
                // Draw blue cube for player using manual cube rendering
                glPushMatrix();
                glTranslatef(x_3d, 1.0f, z_3d); // Position cube at player location
                
                glColor3f(0.0f, 0.0f, 1.0f); // Blue color for player
                
                // Manual rendering of a simple cube
                glBegin(GL_QUADS);
                // Front face
                glNormal3f(0.0f, 0.0f, 1.0f);
                glVertex3f(-0.5f, -0.5f, 0.5f);
                glVertex3f(0.5f, -0.5f, 0.5f);
                glVertex3f(0.5f, 0.5f, 0.5f);
                glVertex3f(-0.5f, 0.5f, 0.5f);
                
                // Back face
                glNormal3f(0.0f, 0.0f, -1.0f);
                glVertex3f(-0.5f, -0.5f, -0.5f);
                glVertex3f(-0.5f, 0.5f, -0.5f);
                glVertex3f(0.5f, 0.5f, -0.5f);
                glVertex3f(0.5f, -0.5f, -0.5f);
                
                // Top face
                glNormal3f(0.0f, 1.0f, 0.0f);
                glVertex3f(-0.5f, 0.5f, -0.5f);
                glVertex3f(-0.5f, 0.5f, 0.5f);
                glVertex3f(0.5f, 0.5f, 0.5f);
                glVertex3f(0.5f, 0.5f, -0.5f);
                
                // Bottom face
                glNormal3f(0.0f, -1.0f, 0.0f);
                glVertex3f(-0.5f, -0.5f, -0.5f);
                glVertex3f(0.5f, -0.5f, -0.5f);
                glVertex3f(0.5f, -0.5f, 0.5f);
                glVertex3f(-0.5f, -0.5f, 0.5f);
                
                // Right face
                glNormal3f(1.0f, 0.0f, 0.0f);
                glVertex3f(0.5f, -0.5f, -0.5f);
                glVertex3f(0.5f, -0.5f, 0.5f);
                glVertex3f(0.5f, 0.5f, 0.5f);
                glVertex3f(0.5f, 0.5f, -0.5f);
                
                // Left face
                glNormal3f(-1.0f, 0.0f, 0.0f);
                glVertex3f(-0.5f, -0.5f, -0.5f);
                glVertex3f(-0.5f, 0.5f, -0.5f);
                glVertex3f(-0.5f, 0.5f, 0.5f);
                glVertex3f(-0.5f, -0.5f, 0.5f);
                glEnd();
                
                glPopMatrix();
            }
            fclose(out_fp);
        }
        
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
    } else {
        // 2D Rendering Mode (original behavior)
        // Draw a simple rectangle (do not clear the color buffer as that would affect the whole screen)
        glColor3f(0.8f, 0.9f, 1.0f); // Light blue background for canvas content
        glBegin(GL_QUADS);
        glVertex2i(0, 0);  // Start at local origin (0,0) which is translated to canvas position
        glVertex2i(width, 0);
        glVertex2i(width, height);
        glVertex2i(0, height);
        glEnd();
        
        // Load player position from output.csv and draw blue square
        FILE* out_fp = fopen("output.csv", "r");
        if (out_fp) {
            int player_x, player_y;
            if (fscanf(out_fp, "%d,%d", &player_x, &player_y) == 2) {
                // Draw blue player square at the loaded position
                // Normalize the position to canvas coordinates (the position from the module is in canvas space)
                glColor3f(0.0f, 0.0f, 1.0f); // Blue color for player
                int square_size = 20;  // Size of the player square
                
                // Make sure the player is within canvas bounds
                if (player_x < 0) player_x = 0;
                if (player_y < 0) player_y = 0;
                if (player_x >= width) player_x = width - square_size;
                if (player_y >= height) player_y = height - square_size;
                
                glBegin(GL_QUADS);
                glVertex2i(player_x, player_y);
                glVertex2i(player_x + square_size, player_y);
                glVertex2i(player_x + square_size, player_y + square_size);
                glVertex2i(player_x, player_y + square_size);
                glEnd();
            }
            fclose(out_fp);
        }
    }
}

void reshape(int w, int h) {
    window_width = w;
    window_height = h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, 0, h);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
