#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#define MAX_THREADS 10
#define MAX_LINE 256

// Thread function that executes the system command
void* thread_func(void* data) {
    char* command = (char*)data;
    system(command);
    free(command);  // Free the duplicated string
    pthread_exit(NULL);
}

// Signal handler to kill child processes
void signal_handler(int sig) {
    // Sending SIGTERM to process group (includes children)
    kill(0, SIGTERM);
    exit(0);
}

int main() {
    printf("test1\n");

    // Set up signal handler for SIGINT and SIGTERM
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // Open and read locations.txt
    FILE* file = fopen("locations.txt", "r");
    if (!file) {
        perror("Failed to open locations.txt");
        return 1;
    }

    char line[MAX_LINE];
    char* commands[MAX_THREADS];
    int num_threads = 0;

    // Read commands from file
    while (fgets(line, MAX_LINE, file) && num_threads < MAX_THREADS) {
        // Remove newline
        line[strcspn(line, "\n")] = 0;
        if (strlen(line) > 0) {
            commands[num_threads] = strdup(line);
            if (!commands[num_threads]) {
                perror("Failed to duplicate command string");
                fclose(file);
                return 1;
            }
            num_threads++;
        }
    }
    fclose(file);

    if (num_threads == 0) {
        printf("No valid commands found in locations.txt\n");
        return 1;
    }

    // Array to store thread IDs
    pthread_t threads[MAX_THREADS];

    // Create threads
    for (int i = 0; i < num_threads; i++) {
        // Create thread
        if (pthread_create(&threads[i], NULL, thread_func, commands[i])) {
            perror("Failed to create thread");
            free(commands[i]);
            return 1;
        }
    }

    // Wait for all threads to complete
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}
