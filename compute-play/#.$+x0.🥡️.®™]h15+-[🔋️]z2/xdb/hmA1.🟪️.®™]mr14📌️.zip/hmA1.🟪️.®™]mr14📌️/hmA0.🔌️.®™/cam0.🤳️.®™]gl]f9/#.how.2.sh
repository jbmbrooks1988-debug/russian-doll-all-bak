
./+x/0.platform.orb.args]🪄️🔮️2gl📲️]e6.+x ./+x/^.move.1_gl]🗃️🟨️]g7.+x ./+x/18.th_person_cam_gl]🎥️🗺️💲️🔴️]p58.+x ./+x/0.mgnt_uni-cycl♿️gl_i10🚸️\!\]HOLY.+x 

#./+x/0.platform.orb.args]🪄️🔮️2gl📲️]e6.+x ./+x/^.move.0_pipe]🗃️🟨️]i7.+x ./+x/18.th_person_cam_gl]🎥️🗺️💲️🔴️]i48.+x 

#./+x/0.platform.orb.args]🪄️🔮️2gl📲]e6.+x ./+x/^.move.1_gl]🗃️🟨️]e4.+x ./+x/18.th_person_cam_gl]🎥️🗺️💲️🔴️]i48.+x ./+x/0.mgnt_uni-cycl♿️gl_i10🚸️\!\]HOLY.+x 

