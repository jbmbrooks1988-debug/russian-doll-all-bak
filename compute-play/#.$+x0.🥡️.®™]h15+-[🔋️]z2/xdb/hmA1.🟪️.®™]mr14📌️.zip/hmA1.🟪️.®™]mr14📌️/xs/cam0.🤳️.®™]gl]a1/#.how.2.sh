./+x/0.platform.orb.args]🪄️🔮️2gl📲]e6.+x ./+x/^.move.1_gl]🗃️🟨️]e4.+x ./+x/18.th_person_cam_gl]🎥️🗺️💲️🔴️]i48.+x


#./+x/0.platform.orb.args]🪄️🔮️2gl📲️]e6.+x ./+x/^.move.0_pipe]🗃️🟨️]i7.+x ./+x/18.th_person_cam_gl]🎥️🗺️💲️🔴️]i48.+x 

