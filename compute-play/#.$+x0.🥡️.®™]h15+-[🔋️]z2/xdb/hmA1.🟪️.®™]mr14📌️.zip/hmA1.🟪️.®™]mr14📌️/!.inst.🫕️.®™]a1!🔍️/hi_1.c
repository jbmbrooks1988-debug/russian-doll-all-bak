#include <stdio.h>

int main() {
    printf("hi, World!\n");
    return 0;
}
