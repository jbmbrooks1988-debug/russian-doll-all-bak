export PATH="$HOME/+x/+x:$PATH"
echo "✨ xshrc.sh loaded! PATH=$PATH ✨"
export PATH="/media/no/b7ced73c-5231-4462-b98d-64e38fe2df9e/home/jbez/Desktop/!.📶️.SHARE]/!.🦾️].fullsharezip/💪🏾️].no-desk.sharezip/📲️📵️.GTFO.flxbx.📦️arcbit♏️/#.⛷️LOOSE-TANGENT]2wild]🎄️⛷️/🪆️.a0/📟️.a0/🎓️/🧼️/🥌️🗡️🛡️🧷️/🛡️.ARMOR.OF.WAR.NOW!]a1/🌐️🗺️🧫️.voxel_sphere_lab]a0/2.Mid.urf.PLAY]loglev]🪓️🤓️🪄️🪵️a0/🧪️]jul8.🏚️.®™]d10/jl69.🥡️.®™]🟦🟥️🟨️]a0/!.🚦️🏎️🏎️🏎️]a3]GOIN!/Fas7.🥡️.®™]🔳️⏹️]E6/earf.🌎️.®™/Lnd1.🏝️.®™/crsr.🗡️.®™]g10📌️/env0🥡️.®™]a0📌️/home.🥡️.®™]a0📌️/!.inst.🫕️.®™/+x/:$PATH"
