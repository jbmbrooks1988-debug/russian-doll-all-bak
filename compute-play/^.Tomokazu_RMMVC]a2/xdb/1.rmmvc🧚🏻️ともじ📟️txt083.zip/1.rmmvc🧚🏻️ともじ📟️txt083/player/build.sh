#!/bin/bash
# Build script for the player program

echo "Building player program..."

# Use the existing compilation script
../xh.compile.dir.link.+x📿]c3.sh

echo "Player program built successfully!"