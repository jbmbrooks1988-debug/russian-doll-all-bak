#!/bin/bash\ngcc -o emoji_paint main.c view_gl.c model_gl.c controller_gl.c -lGL -lglut -lGLX -lX11 -lfreetype -lm
