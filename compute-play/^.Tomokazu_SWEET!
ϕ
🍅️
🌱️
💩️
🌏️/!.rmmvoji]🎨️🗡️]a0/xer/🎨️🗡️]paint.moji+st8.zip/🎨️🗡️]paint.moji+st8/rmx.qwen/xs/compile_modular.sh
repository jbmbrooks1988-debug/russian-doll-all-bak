#!/bin/bash

# Compile and link the modular OpenGL application

# Set executable name
EXE_NAME="emoji_paint"
LIBRARIES="-lGL -lglut -lX11 -lfreetype"
CFLAGS="-c -I/usr/include/freetype2"
LDFLAGS=""
OBJECTS=""

# Remove any existing object files
rm -f *.o

# List of source files to compile (excluding the original monolithic file)
SOURCES=("main.c" "view_gl.c" "model_gl.c" "controller_gl.c")

# Check if source files exist
for source in "${SOURCES[@]}"; do
    if [ ! -f "$source" ]; then
        echo "Error: Source file $source not found"
        exit 1
    fi
done

# Compile each source file to an object file
echo "Compiling source files..."
for source in "${SOURCES[@]}"; do
    object="${source%.c}.o"
    OBJECTS="$OBJECTS $object"
    echo "  Compiling $source -> $object"
    gcc $CFLAGS "$source" -o "$object"
    if [ $? -ne 0 ]; then
        echo "Error: Compilation of $source failed"
        exit 1
    fi
done

# Link object files to create executable
echo "Linking object files to create $EXE_NAME..."
gcc $OBJECTS -o "$EXE_NAME" $LIBRARIES $LDFLAGS
if [ $? -ne 0 ]; then
    echo "Error: Linking failed"
    exit 1
fi

# Make the executable file executable
echo "Setting execute permissions on $EXE_NAME"
chmod +x "$EXE_NAME"
if [ $? -ne 0 ]; then
    echo "Error: Failed to set execute permissions"
    exit 1
fi

# Clean up object files
echo "Cleaning up object files..."
rm -f $OBJECTS

echo "Compilation successful! Executable created: $EXE_NAME"
