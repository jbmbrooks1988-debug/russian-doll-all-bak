#include <GL/glut.h>
#include <GL/glx.h>
#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <stdbool.h>
#include <unistd.h>
#include <sys/select.h>
#include <termios.h>

// External declarations for global variables
extern FT_Library ft;
extern FT_Face emoji_face;

extern Display *x_display;
extern Window x_window;

extern int canvas_rows;
extern int canvas_cols;
extern int tile_size;
extern int num_emojis;
extern int num_colors;
extern int max_layers;
extern int max_tabs;
extern int sidebar_width;
extern int file_tab_height;

extern const char *emojis[64];
extern const char *colors[8][3];
extern const char *color_names[8];

typedef struct { 
    int emoji_idx; 
    int fg_color; 
    int bg_color; 
} Tile;

extern Tile canvas[2][128][128]; // MAX_CANVAS_DIM is 128
extern Tile tab_bank[10];
extern int tab_count;

extern int window_width;
extern int window_height;

extern float emoji_scale;
extern float font_color[3];
extern float background_color[4];
extern char status_message[256];

extern int selected_emoji;
extern int selected_fg_color;
extern int selected_bg_color;
extern int selected_tool;
extern int start_row, start_col;
extern int selector_row, selector_col;
extern bool show_all_layers;

// Function prototypes
extern int decode_utf8(const unsigned char* str, unsigned int* codepoint);
extern void set_status_message(const char* msg);

// Rendering functions
void render_emoji(unsigned int codepoint, float x, float y, float fg[3], float bg[3]) {
    FT_Error err = FT_Load_Char(emoji_face, codepoint, FT_LOAD_RENDER | FT_LOAD_COLOR);
    if (err) {
        fprintf(stderr, "Error: Could not load glyph for codepoint U+%04X, error code: %d\n", codepoint, err);
        return;
    }

    FT_GlyphSlot slot = emoji_face->glyph;
    if (!slot->bitmap.buffer || slot->bitmap.pixel_mode != FT_PIXEL_MODE_BGRA) {
        fprintf(stderr, "Error: Invalid bitmap for glyph U+%04X\n", codepoint);
        return;
    }

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Draw background first
    draw_rect(x - tile_size/2, y - tile_size/2, tile_size, tile_size, bg);

    // Then draw emoji
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, slot->bitmap.width, slot->bitmap.rows, 0, GL_BGRA, GL_UNSIGNED_BYTE, slot->bitmap.buffer);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glEnable(GL_TEXTURE_2D);
    glColor3fv(fg);

    float scale_factor = emoji_scale;
    float w = slot->bitmap.width * scale_factor;
    float h = slot->bitmap.rows * scale_factor;
    float x2 = x - w / 2;
    float y2 = y - h / 2;

    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 1.0); glVertex2f(x2, y2);
    glTexCoord2f(1.0, 1.0); glVertex2f(x2 + w, y2);
    glTexCoord2f(1.0, 0.0); glVertex2f(x2 + w, y2 + h);
    glTexCoord2f(0.0, 0.0); glVertex2f(x2, y2 + h);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, 0);
    glDeleteTextures(1, &texture);
    glColor3f(1.0f, 1.0f, 1.0f);
}

void render_text(const char* str, float x, float y) {
    glColor3fv(font_color);
    glRasterPos2f(x, y);
    while (*str) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *str++);
    }
    glColor3f(1.0f, 1.0f, 1.0f);
}

void draw_rect(float x, float y, float w, float h, float color[3]) {
    glColor3fv(color);
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
    glColor3f(1.0f, 1.0f, 1.0f);
}

void draw_border(float x, float y, float w, float h, float color[3]) {
    glLineWidth(2.0f);
    glColor3fv(color);
    glBegin(GL_LINE_LOOP);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
    glColor3f(1.0f, 1.0f, 1.0f);
}

void display() {
    glClearColor(background_color[0], background_color[1], background_color[2], background_color[3]);
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, window_width, 0, window_height, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    float sidebar_x = 10; // Define sidebar_x here

    // Draw canvas
    float grid_color[3] = {0.4f, 0.4f, 0.4f};
    for (int r = 0; r < canvas_rows; r++) {
        for (int c = 0; c < canvas_cols; c++) {
            float x = sidebar_width + 10 + c * tile_size;
            float y = window_height - file_tab_height - 10 - (r + 1) * tile_size;
            draw_rect(x, y, tile_size, tile_size, grid_color);
        }
    }

    for (int layer = 0; layer < max_layers; layer++) {
        for (int r = 0; r < canvas_rows; r++) {
            for (int c = 0; c < canvas_cols; c++) {
                if (canvas[layer][r][c].emoji_idx == -1) continue;
                float x = sidebar_width + 10 + c * tile_size + tile_size / 2;
                float y = window_height - file_tab_height - 10 - (r + 1) * tile_size + tile_size / 2;
                const char *emoji = emojis[canvas[layer][r][c].emoji_idx];
                unsigned int codepoint;
                decode_utf8((const unsigned char*)emoji, &codepoint);
                float fg[3] = {
                    atof(colors[canvas[layer][r][c].fg_color][0]) / 255.0f,
                    atof(colors[canvas[layer][r][c].fg_color][1]) / 255.0f,
                    atof(colors[canvas[layer][r][c].fg_color][2]) / 255.0f
                };
                float bg[3] = {
                    atof(colors[canvas[layer][r][c].bg_color][0]) / 255.0f,
                    atof(colors[canvas[layer][r][c].bg_color][1]) / 255.0f,
                    atof(colors[canvas[layer][r][c].bg_color][2]) / 255.0f
                };
                render_emoji(codepoint, x, y, fg, bg);
            }
        }
    }

    // Draw tile selector
    float sel_color[3] = {1.0f, 1.0f, 0.0f}; // Yellow
    if (selected_tool == 2 && start_row != -1) {
        // Highlight rectangle region
        int r_min = start_row < selector_row ? start_row : selector_row;
        int r_max = start_row > selector_row ? start_row : selector_row;
        int c_min = start_col < selector_col ? start_col : selector_col;
        int c_max = start_col > selector_col ? start_col : selector_col;
        float x = sidebar_width + 10 + c_min * tile_size;
        float y = window_height - file_tab_height - 10 - (r_max + 1) * tile_size;
        float w = (c_max - c_min + 1) * tile_size;
        float h = (r_max - r_min + 1) * tile_size;
        draw_border(x, y, w, h, sel_color);
    } else {
        // Highlight single tile
        float x = sidebar_width + 10 + selector_col * tile_size;
        float y = window_height - file_tab_height - 10 - (selector_row + 1) * tile_size;
        draw_border(x, y, tile_size, tile_size, sel_color);
    }

    // Draw file tab with additional buttons
    float tab_color[3] = {0.5f, 0.5f, 0.5f};
    draw_rect(sidebar_x, window_height - file_tab_height - 10, 60, file_tab_height, tab_color);
    draw_rect(sidebar_x + 70, window_height - file_tab_height - 10, 60, file_tab_height, tab_color);
    draw_rect(sidebar_x + 140, window_height - file_tab_height - 10, 60, file_tab_height, tab_color);
    draw_rect(sidebar_x + 210, window_height - file_tab_height - 10, 60, file_tab_height, tab_color);
    draw_rect(sidebar_x + 280, window_height - file_tab_height - 10, 60, file_tab_height, tab_color);
    draw_rect(sidebar_x + 350, window_height - file_tab_height - 10, 60, file_tab_height, tab_color);
    render_text("Save", sidebar_x + 10, window_height - file_tab_height + 5);
    render_text("Load", sidebar_x + 80, window_height - file_tab_height + 5);
    render_text("Text", sidebar_x + 150, window_height - file_tab_height + 5);
    render_text("Tile", sidebar_x + 220, window_height - file_tab_height + 5);
    render_text("2D", sidebar_x + 290, window_height - file_tab_height + 5);
    render_text("3D", sidebar_x + 360, window_height - file_tab_height + 5);

    // Draw sidebar (left side, below file tab)
    float sidebar_y_offset = file_tab_height + 50; // Increased offset to avoid overlap
    float base_y = window_height - sidebar_y_offset - 20;

    // Emoji grid (8x8)
    int emoji_cols = 8;
    int emoji_rows = (num_emojis + emoji_cols - 1) / emoji_cols;
    for (int i = 0; i < num_emojis; i++) {
        int row = i / emoji_cols;
        int col = i % emoji_cols;
        float x = sidebar_x + 10 + col * 40;
        float y = base_y - row * 40;
        unsigned int codepoint;
        decode_utf8((const unsigned char*)emojis[i], &codepoint);
        float fg[3] = {1.0f, 1.0f, 1.0f};
        float bg[3] = {0.0f, 0.0f, 0.0f};
        render_emoji(codepoint, x + 20, y + 20, fg, bg);
        if (i == selected_emoji) {
            draw_border(x, y, 40, 40, sel_color);
        }
    }

    // Colors (horizontal row below emojis)
    float colors_y_start = base_y - (emoji_rows * 40) - 20;
    int colors_cols = 8;
    int colors_rows = 1;
    for (int i = 0; i < num_colors; i++) {
        int row = i / colors_cols;
        int col = i % colors_cols;
        float x = sidebar_x + 10 + col * 40;
        float y = colors_y_start - row * 40;
        float color[3] = {
            atof(colors[i][0]) / 255.0f,
            atof(colors[i][1]) / 255.0f,
            atof(colors[i][2]) / 255.0f
        };
        draw_rect(x, y, 40, 40, color);
        if (i == selected_fg_color) {
            draw_border(x, y, 40, 40, sel_color);
        }
    }

    // Tab bank (vertical below colors)
    float tabs_y_start = colors_y_start - (colors_rows * 40) - 20;
    for (int i = 0; i < tab_count; i++) {
        float x = sidebar_x + 10;
        float y = tabs_y_start - i * 40;
        unsigned int codepoint;
        decode_utf8((const unsigned char*)emojis[tab_bank[i].emoji_idx], &codepoint);
        float fg[3] = {
            atof(colors[tab_bank[i].fg_color][0]) / 255.0f,
            atof(colors[tab_bank[i].fg_color][1]) / 255.0f,
            atof(colors[tab_bank[i].fg_color][2]) / 255.0f
        };
        float bg[3] = {
            atof(colors[tab_bank[i].bg_color][0]) / 255.0f,
            atof(colors[tab_bank[i].bg_color][1]) / 255.0f,
            atof(colors[tab_bank[i].bg_color][2]) / 255.0f
        };
        render_emoji(codepoint, x + 20, y + 20, fg, bg);
    }

    // Tools (horizontal below tabs)
    float tabs_section_height = tab_count * 40;
    float tools_y_start = tabs_y_start - tabs_section_height - 20;
    const char *tools[] = {"Paint", "Fill", "Rect"};
    for (int i = 0; i < 3; i++) {
        float x = sidebar_x + 10 + i * 70;
        float y = tools_y_start;
        draw_rect(x, y, 60, 30, tab_color);
        render_text(tools[i], x + 10, y + 10);
        if (i == selected_tool) {
            draw_border(x, y, 60, 30, sel_color);
        }
    }

    render_text(status_message, sidebar_width + 10, 10);
    glutSwapBuffers();
}

void reshape(int w, int h) {
    window_width = w;
    window_height = h;
    glViewport(0, 0, w, h);
    glutPostRedisplay();
}