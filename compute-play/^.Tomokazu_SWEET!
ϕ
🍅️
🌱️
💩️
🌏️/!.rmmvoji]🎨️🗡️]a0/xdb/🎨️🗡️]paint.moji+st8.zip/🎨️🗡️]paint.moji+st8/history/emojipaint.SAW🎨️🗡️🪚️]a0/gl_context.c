#include <GL/glut.h>
#include <GL/glx.h>
#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>

// --- External globals from emoji_paint.c ---
extern int window_width;
extern int window_height;
extern int canvas_rows;
extern int canvas_cols;
extern int tile_size;
extern int sidebar_width;
extern int file_tab_height;
extern Display *x_display;
extern Window x_window;

// --- External function prototypes from emoji_paint.c ---
void init();
void display();
void reshape(int w, int h);
void mouse(int button, int state, int x, int y);
void keyboard(unsigned char key, int x, int y);
void special(int key, int x, int y);
void idle();

// --- Main ---

int main(int argc, char** argv) {
    // Get screen size for near full-screen window
    Display *disp = XOpenDisplay(NULL);
    if (disp) {
        int scr = DefaultScreen(disp);
        int sw = DisplayWidth(disp, scr);
        int sh = DisplayHeight(disp, scr);
        XCloseDisplay(disp);
        window_width = sw - 100;
        window_height = sh - 100;
    } else {
        // Fallback
        window_width = 682;
        window_height = 562;
    }

    // Set sidebar width for emoji grid and buttons
    sidebar_width = 420;

    // Compute canvas size
    canvas_cols = (window_width - sidebar_width - 20) / tile_size;
    canvas_rows = (window_height - file_tab_height - 20) / tile_size;
    if (canvas_cols > 128) canvas_cols = 128;
    if (canvas_rows > 128) canvas_rows = 128;

    // Adjust window size to fit exactly
    window_width = canvas_cols * tile_size + sidebar_width + 20;
    window_height = canvas_rows * tile_size + file_tab_height + 20;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(window_width, window_height);
    glutCreateWindow("Emoji Paint");

    glutReshapeFunc(reshape);
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutIdleFunc(idle);

    init();

    glutMainLoop();

    return 0;
}
