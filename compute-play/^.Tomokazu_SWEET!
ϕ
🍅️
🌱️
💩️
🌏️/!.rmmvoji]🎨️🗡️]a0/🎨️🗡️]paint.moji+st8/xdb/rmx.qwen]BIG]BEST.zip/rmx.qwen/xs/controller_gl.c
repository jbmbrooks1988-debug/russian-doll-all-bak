#include <GL/glut.h>
#include <GL/glx.h>
#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <stdbool.h>
#include <unistd.h>
#include <sys/select.h>
#include <termios.h>

// External declarations for global variables
extern FT_Library ft;
extern FT_Face emoji_face;

extern Display *x_display;
extern Window x_window;

extern int canvas_rows;
extern int canvas_cols;
extern int tile_size;
extern int num_emojis;
extern int num_colors;
extern int max_layers;
extern int max_tabs;
extern int sidebar_width;
extern int file_tab_height;

extern const char *emojis[64];
extern const char *colors[8][3];
extern const char *color_names[8];

typedef struct { 
    int emoji_idx; 
    int fg_color; 
    int bg_color; 
} Tile;

extern Tile canvas[2][128][128]; // MAX_CANVAS_DIM is 128
extern Tile tab_bank[10];
extern int tab_count;

extern int window_width;
extern int window_height;

extern float emoji_scale;
extern float font_color[3];
extern float background_color[4];
extern char status_message[256];

extern int selected_emoji;
extern int selected_fg_color;
extern int selected_bg_color;
extern int selected_tool;
extern int start_row, start_col;
extern int selector_row, selector_col;
extern bool show_all_layers;

// Function prototypes
extern void render_emoji(unsigned int codepoint, float x, float y, float fg[3], float bg[3]);
extern void render_text(const char* str, float x, float y);
extern void draw_rect(float x, float y, float w, float h, float color[3]);
extern void draw_border(float x, float y, float w, float h, float color[3]);
extern void flood_fill(int layer, int r, int c, int old_emoji, int old_fg, int old_bg);
extern void draw_rectangle(int layer, int r1, int c1, int r2, int c2);
extern void save_canvas();
extern void load_canvas();
extern void print_ascii_grid();
extern int check_terminal_input();
extern int decode_utf8(const unsigned char* str, unsigned int* codepoint);
extern void set_status_message(const char* msg);

// GLUT Callbacks
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        float gl_y = window_height - y;
        float sidebar_x = 10; // Define sidebar_x here
        // Canvas click
        int col = (x - sidebar_width - 10) / tile_size;
        int row = canvas_rows - 1 - ((gl_y - file_tab_height - 10) / tile_size); // Flip row
        if (col >= 0 && col < canvas_cols && row >= 0 && row < canvas_rows) {
            selector_row = row;
            selector_col = col;
            if (selected_tool == 0) { // Paint
                canvas[max_layers-1][row][col].emoji_idx = selected_emoji;
                canvas[max_layers-1][row][col].fg_color = selected_fg_color;
                canvas[max_layers-1][row][col].bg_color = selected_bg_color;
            } else if (selected_tool == 1) { // Fill
                flood_fill(max_layers-1, row, col,
                           canvas[max_layers-1][row][col].emoji_idx,
                           canvas[max_layers-1][row][col].fg_color,
                           canvas[max_layers-1][row][col].bg_color);
            } else if (selected_tool == 2) { // Rectangle
                if (start_row == -1) {
                    start_row = row;
                    start_col = col;
                    set_status_message("Select second corner for rectangle");
                } else {
                    draw_rectangle(max_layers-1, start_row, start_col, row, col);
                    start_row = -1;
                    start_col = -1;
                    set_status_message("Rectangle drawn");
                }
            }
        }
        // File tab click
        else if (x >= sidebar_x && x < sidebar_x + 60 && gl_y >= window_height - file_tab_height - 10 && gl_y < window_height - 10) {
            save_canvas();
        } else if (x >= sidebar_x + 70 && x < sidebar_x + 130 && gl_y >= window_height - file_tab_height - 10 && gl_y < window_height - 10) {
            load_canvas();
        } else if (x >= sidebar_x + 140 && x < sidebar_x + 200 && gl_y >= window_height - file_tab_height - 10 && gl_y < window_height - 10) {
            set_status_message("Text button clicked (no functionality)");
        } else if (x >= sidebar_x + 210 && x < sidebar_x + 270 && gl_y >= window_height - file_tab_height - 10 && gl_y < window_height - 10) {
            set_status_message("Tile button clicked (no functionality)");
        } else if (x >= sidebar_x + 280 && x < sidebar_x + 340 && gl_y >= window_height - file_tab_height - 10 && gl_y < window_height - 10) {
            set_status_message("2D button clicked (no functionality)");
        } else if (x >= sidebar_x + 350 && x < sidebar_x + 410 && gl_y >= window_height - file_tab_height - 10 && gl_y < window_height - 10) {
            set_status_message("3D button clicked (no functionality)");
        }
        // Sidebar click - Emojis
        float sidebar_y_offset = file_tab_height + 50; // Match display offset
        float base_y = window_height - sidebar_y_offset - 20;
        int emoji_cols = 8;
        int emoji_rows = (num_emojis + emoji_cols - 1) / emoji_cols;
        float emoji_section_top = base_y + 40;
        float emoji_section_bottom = base_y - (emoji_rows - 1) * 40;
        if (x >= sidebar_x + 10 && x < sidebar_x + 10 + emoji_cols * 40 &&
            gl_y >= emoji_section_bottom && gl_y <= emoji_section_top) {
            float local_y_from_top = emoji_section_top - gl_y;
            int row = (int)(local_y_from_top / 40);
            int col = (int)((x - (sidebar_x + 10)) / 40);
            if (row >= 0 && row < emoji_rows && col >= 0 && col < emoji_cols) {
                int idx = row * emoji_cols + col;
                if (idx < num_emojis) {
                    selected_emoji = idx;
                    set_status_message("Emoji selected");
                }
            }
        }
        // Colors
        float colors_y_start = base_y - (emoji_rows * 40) - 20;
        int colors_cols = 8;
        int colors_rows = 1;
        float colors_section_top = colors_y_start + 40;
        float colors_section_bottom = colors_y_start - (colors_rows - 1) * 40;
        if (x >= sidebar_x + 10 && x < sidebar_x + 10 + colors_cols * 40 &&
            gl_y >= colors_section_bottom && gl_y <= colors_section_top) {
            float local_y_from_top = colors_section_top - gl_y;
            int row = (int)(local_y_from_top / 40);
            int col = (int)((x - (sidebar_x + 10)) / 40);
            if (row >= 0 && row < colors_rows && col >= 0 && col < colors_cols) {
                int idx = row * colors_cols + col;
                if (idx < num_colors) {
                    selected_fg_color = idx;
                    set_status_message("Color selected");
                }
            }
        }
        // Tabs
        float tabs_y_start = colors_y_start - (colors_rows * 40) - 20;
        float tabs_section_top = tabs_y_start + 40;
        float tabs_section_bottom = tabs_y_start - (tab_count - 1) * 40;
        if (x >= sidebar_x + 10 && x < sidebar_x + 50 &&
            gl_y >= tabs_section_bottom && gl_y <= tabs_section_top) {
            float local_y_from_top = tabs_section_top - gl_y;
            int idx = (int)(local_y_from_top / 40);
            if (idx >= 0 && idx < tab_count) {
                selected_emoji = tab_bank[idx].emoji_idx;
                selected_fg_color = tab_bank[idx].fg_color;
                selected_bg_color = tab_bank[idx].bg_color;
                set_status_message("Tab selected");
            }
        }
        // Tools
        float tabs_section_height = tab_count * 40;
        float tools_y_start = tabs_y_start - tabs_section_height - 20;
        float tools_section_top = tools_y_start + 30;
        float tools_section_bottom = tools_y_start;
        if (x >= sidebar_x + 10 && x < sidebar_x + 10 + 3 * 70 &&
            gl_y >= tools_section_bottom && gl_y <= tools_section_top) {
            int idx = (int)((x - (sidebar_x + 10)) / 70);
            if (idx >= 0 && idx < 3) {
                selected_tool = idx;
                start_row = -1;
                start_col = -1;
                set_status_message("Tool selected");
            }
        }
        print_ascii_grid();
        glutPostRedisplay();
    }
}

void keyboard(unsigned char key, int x, int y) {
    if (key == ' ') {
        // Mouse-driven paint, but allow space as alternative to Enter
        if (selected_tool == 0) {
            canvas[max_layers-1][selector_row][selector_col].emoji_idx = selected_emoji;
            canvas[max_layers-1][selector_row][selector_col].fg_color = selected_fg_color;
            canvas[max_layers-1][selector_row][selector_col].bg_color = selected_bg_color;
            set_status_message("Tile painted");
        } else if (selected_tool == 1) {
            flood_fill(max_layers-1, selector_row, selector_col,
                       canvas[max_layers-1][selector_row][selector_col].emoji_idx,
                       canvas[max_layers-1][selector_row][selector_col].fg_color,
                       canvas[max_layers-1][selector_row][selector_col].bg_color);
            set_status_message("Area filled");
        } else if (selected_tool == 2) {
            if (start_row == -1) {
                start_row = selector_row;
                start_col = selector_col;
                set_status_message("Select second corner for rectangle");
            } else {
                draw_rectangle(max_layers-1, start_row, start_col, selector_row, selector_col);
                start_row = -1;
                start_col = -1;
                set_status_message("Rectangle drawn");
            }
        }
    } else if (key == '\r') { // Enter key
        if (selected_tool == 0) {
            canvas[max_layers-1][selector_row][selector_col].emoji_idx = selected_emoji;
            canvas[max_layers-1][selector_row][selector_col].fg_color = selected_fg_color;
            canvas[max_layers-1][selector_row][selector_col].bg_color = selected_bg_color;
            set_status_message("Tile painted");
        } else if (selected_tool == 1) {
            flood_fill(max_layers-1, selector_row, selector_col,
                       canvas[max_layers-1][selector_row][selector_col].emoji_idx,
                       canvas[max_layers-1][selector_row][selector_col].fg_color,
                       canvas[max_layers-1][selector_row][selector_col].bg_color);
            set_status_message("Area filled");
        } else if (selected_tool == 2) {
            if (start_row == -1) {
                start_row = selector_row;
                start_col = selector_col;
                set_status_message("Select second corner for rectangle");
            } else {
                draw_rectangle(max_layers-1, start_row, start_col, selector_row, selector_col);
                start_row = -1;
                start_col = -1;
                set_status_message("Rectangle drawn");
            }
        }
    } else if (key == 'f') {
        selected_tool = 1;
        start_row = -1;
        start_col = -1;
        set_status_message("Fill tool selected");
    } else if (key == 'r') {
        selected_tool = 2;
        start_row = -1;
        start_col = -1;
        set_status_message("Rectangle tool selected");
    } else if (key == '1') {
        selected_emoji = (selected_emoji + 1) % num_emojis;
        set_status_message("Emoji selected");
    } else if (key == 'c') {
        selected_fg_color = (selected_fg_color + 1) % num_colors;
        set_status_message("Color selected");
    } else if (key == '2') {
        show_all_layers = !show_all_layers;
        set_status_message(show_all_layers ? "Showing all layers" : "Showing top layer");
    } else if (key == 's') {
        save_canvas();
    } else if (key == 'l') {
        load_canvas();
    } else if (key == 't' && tab_count < max_tabs) {
        tab_bank[tab_count].emoji_idx = selected_emoji;
        tab_bank[tab_count].fg_color = selected_fg_color;
        tab_bank[tab_count].bg_color = selected_bg_color;
        tab_count++;
        set_status_message("Tab created");
    } else if (key == 'q' || key == 'Q') {
        if (emoji_face) FT_Done_Face(emoji_face);
        FT_Done_FreeType(ft);
        exit(0);
    }
    print_ascii_grid();
    glutPostRedisplay();
}

void special(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP:
            if (selector_row > 0) selector_row--;
            break;
        case GLUT_KEY_DOWN:
            if (selector_row < canvas_rows - 1) selector_row++;
            break;
        case GLUT_KEY_LEFT:
            if (selector_col > 0) selector_col--;
            break;
        case GLUT_KEY_RIGHT:
            if (selector_col < canvas_cols - 1) selector_col++;
            break;
    }
    set_status_message("Selector moved");
    print_ascii_grid();
    glutPostRedisplay();
}

void idle() {
    int ch = check_terminal_input();
    if (ch == ' ') {
        if (selected_tool == 0) {
            canvas[max_layers-1][selector_row][selector_col].emoji_idx = selected_emoji;
            canvas[max_layers-1][selector_row][selector_col].fg_color = selected_fg_color;
            canvas[max_layers-1][selector_row][selector_col].bg_color = selected_bg_color;
            set_status_message("Tile painted");
        } else if (selected_tool == 1) {
            flood_fill(max_layers-1, selector_row, selector_col,
                       canvas[max_layers-1][selector_row][selector_col].emoji_idx,
                       canvas[max_layers-1][selector_row][selector_col].fg_color,
                       canvas[max_layers-1][selector_row][selector_col].bg_color);
            set_status_message("Area filled");
        } else if (selected_tool == 2) {
            if (start_row == -1) {
                start_row = selector_row;
                start_col = selector_col;
                set_status_message("Select second corner for rectangle");
            } else {
                draw_rectangle(max_layers-1, start_row, start_col, selector_row, selector_col);
                start_row = -1;
                start_col = -1;
                set_status_message("Rectangle drawn");
            }
        }
    } else if (ch == '\r') { // Enter key
        if (selected_tool == 0) {
            canvas[max_layers-1][selector_row][selector_col].emoji_idx = selected_emoji;
            canvas[max_layers-1][selector_row][selector_col].fg_color = selected_fg_color;
            canvas[max_layers-1][selector_row][selector_col].bg_color = selected_bg_color;
            set_status_message("Tile painted");
        } else if (selected_tool == 1) {
            flood_fill(max_layers-1, selector_row, selector_col,
                       canvas[max_layers-1][selector_row][selector_col].emoji_idx,
                       canvas[max_layers-1][selector_row][selector_col].fg_color,
                       canvas[max_layers-1][selector_row][selector_col].bg_color);
            set_status_message("Area filled");
        } else if (selected_tool == 2) {
            if (start_row == -1) {
                start_row = selector_row;
                start_col = selector_col;
                set_status_message("Select second corner for rectangle");
            } else {
                draw_rectangle(max_layers-1, start_row, start_col, selector_row, selector_col);
                start_row = -1;
                start_col = -1;
                set_status_message("Rectangle drawn");
            }
        }
    } else if (ch == 'f') {
        selected_tool = 1;
        start_row = -1;
        start_col = -1;
        set_status_message("Fill tool selected");
    } else if (ch == 'r') {
        selected_tool = 2;
        start_row = -1;
        start_col = -1;
        set_status_message("Rectangle tool selected");
    } else if (ch == '1') {
        selected_emoji = (selected_emoji + 1) % num_emojis;
        set_status_message("Emoji selected");
    } else if (ch == 'c') {
        selected_fg_color = (selected_fg_color + 1) % num_colors;
        set_status_message("Color selected");
    } else if (ch == '2') {
        show_all_layers = !show_all_layers;
        set_status_message(show_all_layers ? "Showing all layers" : "Showing top layer");
    } else if (ch == 's') {
        save_canvas();
    } else if (ch == 'l') {
        load_canvas();
    } else if (ch == 't' && tab_count < max_tabs) {
        tab_bank[tab_count].emoji_idx = selected_emoji;
        tab_bank[tab_count].fg_color = selected_fg_color;
        tab_bank[tab_count].bg_color = selected_bg_color;
        tab_count++;
        set_status_message("Tab created");
    } else if (ch == 'q' || ch == 'Q') {
        if (emoji_face) FT_Done_Face(emoji_face);
        FT_Done_FreeType(ft);
        exit(0);
    }
    if (ch != -1) {
        print_ascii_grid();
        glutPostRedisplay();
    }
}