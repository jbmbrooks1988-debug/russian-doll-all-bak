#!/bin/bash

# compilink.sh - Compile and link the modular OpenGL application

# Check if required libraries are installed
echo "Checking for required libraries..."

# Check for OpenGL libraries
if ! pkg-config --exists gl glu glut freetype2; then
    echo "Error: Required libraries not found. Please install:"
    echo "  - OpenGL development libraries"
    echo "  - GLUT development libraries" 
    echo "  - FreeType development libraries"
    echo "On Ubuntu/Debian: sudo apt-get install libgl1-mesa-dev libglu1-mesa-dev freeglut3-dev libfreetype6-dev"
    exit 1
fi

echo "Found required libraries. Compiling..."

# Compile each source file
echo "Compiling main.c..."
gcc -c main.c -o main.o `pkg-config --cflags gl glu glut freetype2` || { echo "Compilation failed for main.c"; exit 1; }

echo "Compiling view_gl.c..."
gcc -c view_gl.c -o view_gl.o `pkg-config --cflags gl glu glut freetype2` || { echo "Compilation failed for view_gl.c"; exit 1; }

echo "Compiling model_gl.c..."
gcc -c model_gl.c -o model_gl.o `pkg-config --cflags gl glu glut freetype2` || { echo "Compilation failed for model_gl.c"; exit 1; }

echo "Compiling controller_gl.c..."
gcc -c controller_gl.c -o controller_gl.o `pkg-config --cflags gl glu glut freetype2` || { echo "Compilation failed for controller_gl.c"; exit 1; }

# Link all object files
echo "Linking..."
gcc main.o view_gl.o model_gl.o controller_gl.o -o emoji_paint `pkg-config --libs gl glu glut freetype2` -lX11 || { echo "Linking failed"; exit 1; }

# Clean up object files
echo "Cleaning up..."
rm -f *.o

echo "Compilation successful! Run with: ./emoji_paint"