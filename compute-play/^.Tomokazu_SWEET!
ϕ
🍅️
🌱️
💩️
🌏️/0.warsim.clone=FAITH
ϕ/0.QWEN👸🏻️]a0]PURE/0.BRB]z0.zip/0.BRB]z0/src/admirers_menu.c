#include <stdio.h>
#include <stdlib.h>

void display_menu() {
    system("clear");
    printf("              ,_");
    printf("         ()  /(.\");
    printf("        /\__/_/\,)");
    printf("    _,-((-'` /\");
    printf("   /(   d    )");
    printf("   ` \ /`'--\\ ");
    printf("      ))     ))");
    printf("     //      ^");
    printf("     ^");
    printf("----------------------------------------------------------------------------");
    printf("These are your admirers");
    printf("1) Aslona Admirer Slot One");
    printf("2) Aslona Admirer Slot Two");
    printf("3) Aslona Admirer Slot Three");
    printf("4) Aslona Admirer Slot Four");
    printf("5) Aslona Admirer Slot Five");
    printf("0) Exit");
    printf("______________________________________________________📄️");
    printf("Enter your choice: ");
}

int main() {
    display_menu();
    // Input handling logic would go here
    return 0;
}
