#include <stdio.h>
#include <stdlib.h>

void display_menu() {
    system("clear");
    printf("              /\n");
    printf("       ,~~   /\n");
    printf("   _  <=)  _/_
");
    printf("  /I\.=\"==.{> \n");
    printf("  \I-/\T/-\'\n");
    printf("      /_\ \n");
    printf("     // \_ \n");
    printf("    _I    /\n");
    printf("------------IMAGE TEAMS------------------------------------------------\n");
    printf("1) Purple-Bannered Soul Stylists (cost 3681 glitz/month)\n");
    printf("2) Blue Granite Glam Crew (cost 10233 glitz/month)\n");
    printf("3) Golden Dawn Rangers (cost 5918 glitz/month)\n");
    printf("4) Ultimate Pose Coaches (cost 4911 glitz/month)\n");
    printf("5) Great Wind Makeup Artists (cost 6683 glitz/month)\n");
    printf("0) Exit\n");
    printf("______________________________________________________📄️\n");
    printf("Enter your choice: ");
}

int main() {
    display_menu();
    // Input handling logic would go here
    return 0;
}
