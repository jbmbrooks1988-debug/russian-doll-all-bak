#include <GL/glut.h>
#include <stdbool.h>

int get_grid_rows(void);
int get_grid_cols(void);
int get_tile_size(void);
int get_window_height(void);
bool get_is_animating(void);
void set_car_angle(float delta);
void set_car_speed(float speed);
void update_car_position(void);
void set_status_message(const char* msg);
int get_window_width(void);

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 13: // Enter key
            set_car_speed(2.0f); // Accelerate to a moderate speed
            set_status_message("Accelerating!");
            break;
        case ' ': // Space key
            set_car_speed(0.0f);
            set_status_message("Stopped");
            break;
    }
    glutPostRedisplay();
}

void special(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_LEFT:
            set_car_angle(-5.0f); // Turn left
            set_status_message("Turning left");
            break;
        case GLUT_KEY_RIGHT:
            set_car_angle(5.0f); // Turn right
            set_status_message("Turning right");
            break;
    }
    glutPostRedisplay();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glutPostRedisplay();
}

void idle(void) {
    if (get_is_animating()) {
        update_car_position();
        glutPostRedisplay();
    }
}
