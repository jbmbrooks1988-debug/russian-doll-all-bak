#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

#define WINDOW_WIDTH 512
#define WINDOW_HEIGHT 552
#define FIELD_WIDTH 480
#define FIELD_HEIGHT 480
#define OBJECT_SIZE 64
#define MAX_SPEED 2.0f
#define ENEMY_SPEED 1.0f
#define BULLET_SPEED 5.0f
#define ANGLE_STEP 5.0f
#define MAX_ENEMIES 3
#define MAX_BULLETS 5
#define COLLISION_DISTANCE 64.0f

static float object_x[MAX_ENEMIES + MAX_BULLETS + 1]; // Player + enemies + bullets
static float object_y[MAX_ENEMIES + MAX_BULLETS + 1];
static float object_angle[MAX_ENEMIES + MAX_BULLETS + 1];
static float object_speed[MAX_ENEMIES + MAX_BULLETS + 1];
static bool object_active[MAX_ENEMIES + MAX_BULLETS + 1];
static int object_type[MAX_ENEMIES + MAX_BULLETS + 1]; // 0: player, 1: enemy, 2: bullet
static int score = 0;
static char status_message[256] = "";
static const char *emojis[3] = {"🚀", "👾", "🟡"};
static int num_objects = 1; // Start with player only

int get_window_width(void) { return WINDOW_WIDTH; }
int get_window_height(void) { return WINDOW_HEIGHT; }
int get_field_width(void) { return FIELD_WIDTH; }
int get_field_height(void) { return FIELD_HEIGHT; }
int get_grid_rows(void) { return num_objects; }
int get_grid_cols(void) { return 1; }
int get_tile_size(void) { return OBJECT_SIZE; }
int get_grid_value(int r, int c) { return object_type[r]; }
int get_selected_row(void) { return -1; }
int get_selected_col(void) { return -1; }
int get_score(void) { return score; }
const char* get_candy_emoji(int type) { return emojis[type]; }
const char* get_status_message(void) { return status_message; }
float get_car_x(int index) { return object_x[index]; }
float get_car_y(int index) { return object_y[index]; }
float get_car_angle(int index) { return object_angle[index]; }
float* get_waypoints(void) { return NULL; } // No road
int get_num_waypoints(void) { return 0; }
int* get_checkpoint_indices(void) { return NULL; }
int get_num_checkpoints(void) { return 0; }

void set_status_message(const char* msg) {
    strncpy(status_message, msg, sizeof(status_message) - 1);
    status_message[sizeof(status_message) - 1] = '\0';
}

void init(void) {
    srand(time(NULL));
    // Initialize player
    object_x[0] = FIELD_WIDTH / 2.0f;
    object_y[0] = 50.0f; // Bottom of screen
    object_angle[0] = 90.0f; // Face up
    object_speed[0] = 0.0f;
    object_active[0] = true;
    object_type[0] = 0; // Player
    num_objects = 1;
    // Initialize enemies and bullets
    for (int i = 1; i < MAX_ENEMIES + MAX_BULLETS + 1; i++) {
        object_active[i] = false;
        object_type[i] = (i <= MAX_ENEMIES) ? 1 : 2; // Enemies or bullets
    }
    score = 0;
    set_status_message("Use arrows to rotate, Enter to shoot, Space to thrust");
}

bool get_is_animating(void) {
    for (int i = 0; i < num_objects; i++) {
        if (object_active[i] && object_speed[i] > 0.0f) return true;
    }
    return false;
}
void set_is_animating(bool value) { /* No-op, animation driven by speed */ }

void set_car_angle(float delta) {
    object_angle[0] += delta; // Player only
    while (object_angle[0] >= 360.0f) object_angle[0] -= 360.0f;
    while (object_angle[0] < 0.0f) object_angle[0] += 360.0f;
}

void set_car_speed(float speed) {
    object_speed[0] = speed; // Player only
    if (object_speed[0] > MAX_SPEED) object_speed[0] = MAX_SPEED;
    if (object_speed[0] < 0.0f) object_speed[0] = 0.0f;
}

float distance(float x1, float y1, float x2, float y2) {
    return sqrtf((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

void spawn_enemy(void) {
    if (num_objects >= MAX_ENEMIES + MAX_BULLETS + 1) return;
    for (int i = 1; i <= MAX_ENEMIES; i++) {
        if (!object_active[i]) {
            object_x[i] = 10.0f + (rand() % (FIELD_WIDTH - 20));
            object_y[i] = 50.0f + (rand() % (FIELD_HEIGHT - 20));
            object_angle[i] = 0.0f;
            object_speed[i] = ENEMY_SPEED;
            object_active[i] = true;
            object_type[i] = 1; // Enemy
            num_objects++;
            break;
        }
    }
}

void shoot_bullet(void) {
    if (num_objects >= MAX_ENEMIES + MAX_BULLETS + 1) return;
    for (int i = MAX_ENEMIES + 1; i < MAX_ENEMIES + MAX_BULLETS + 1; i++) {
        if (!object_active[i]) {
            object_x[i] = object_x[0]; // Start at player
            object_y[i] = object_y[0];
            object_angle[i] = object_angle[0];
            object_speed[i] = BULLET_SPEED;
            object_active[i] = true;
            object_type[i] = 2; // Bullet
            num_objects++;
            set_status_message("Shot fired!");
            break;
        }
    }
}

void update_car_position(void) {
    // Spawn enemies periodically
    if (rand() % 100 < 5 && num_objects < MAX_ENEMIES + 1) { // 5% chance per frame
        spawn_enemy();
    }
    // Update all objects
    for (int i = 0; i < num_objects; i++) {
        if (!object_active[i]) continue;
        if (object_speed[i] > 0.0f) {
            float rad = object_angle[i] * M_PI / 180.0f;
            object_x[i] += object_speed[i] * cosf(rad);
            object_y[i] += object_speed[i] * sinf(rad);
            // Boundary checking
            if (object_x[i] < 10.0f) object_x[i] = 10.0f;
            if (object_x[i] > FIELD_WIDTH + 10.0f - OBJECT_SIZE) object_x[i] = FIELD_WIDTH + 10.0f - OBJECT_SIZE;
            if (object_y[i] < 50.0f) object_y[i] = 50.0f;
            if (object_y[i] > FIELD_HEIGHT + 50.0f - OBJECT_SIZE) object_y[i] = FIELD_HEIGHT + 50.0f - OBJECT_SIZE;
            // Bullets deactivate when out of bounds
            if (object_type[i] == 2 && (object_x[i] <= 10.0f || object_x[i] >= FIELD_WIDTH + 10.0f - OBJECT_SIZE ||
                                        object_y[i] <= 50.0f || object_y[i] >= FIELD_HEIGHT + 50.0f - OBJECT_SIZE)) {
                object_active[i] = false;
                num_objects--;
            }
        }
        // Enemies chase player
        if (object_type[i] == 1 && object_active[i]) {
            float dx = object_x[0] - object_x[i];
            float dy = object_y[0] - object_y[i];
            float angle_rad = atan2f(dy, dx);
            object_angle[i] = angle_rad * 180.0f / M_PI;
        }
    }
    // Check collisions
    for (int i = 1; i <= MAX_ENEMIES; i++) {
        if (!object_active[i] || object_type[i] != 1) continue;
        // Enemy-player collision
        if (distance(object_x[0], object_y[0], object_x[i], object_y[i]) < COLLISION_DISTANCE) {
            set_status_message("Hit by enemy! Game over!");
            object_speed[0] = 0.0f; // Stop player
            for (int j = 0; j < num_objects; j++) {
                object_speed[j] = 0.0f; // Stop all
            }
        }
        // Bullet-enemy collision
        for (int j = MAX_ENEMIES + 1; j < MAX_ENEMIES + MAX_BULLETS + 1; j++) {
            if (!object_active[j] || object_type[j] != 2) continue;
            if (distance(object_x[i], object_y[i], object_x[j], object_y[j]) < COLLISION_DISTANCE) {
                object_active[i] = false; // Deactivate enemy
                object_active[j] = false; // Deactivate bullet
                num_objects -= 2;
                score += 100;
                set_status_message("Enemy destroyed!");
            }
        }
    }
}
