#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#define WINDOW_WIDTH 512
#define WINDOW_HEIGHT 552
#define FIELD_WIDTH 480
#define FIELD_HEIGHT 480
#define CAR_SIZE 64
#define MAX_SPEED 5.0f
#define POLICE_SPEED 1.8f
#define ANGLE_STEP 5.0f
#define ROAD_RADIUS 50.0f
#define NUM_WAYPOINTS 12
#define NUM_CHECKPOINTS 4

static float car_x[2] = {FIELD_WIDTH / 2.0f, FIELD_WIDTH / 2.0f - 50.0f}; // Player, Police at bottom
static float car_y[2] = {50.0f, 50.0f};
static float car_angle[2] = {90.0f, 90.0f}; // Start facing up
static float car_speed[2] = {0.0f, 0.0f};
static int score = 0;
static int lap_count = 0;
static char status_message[256] = "";
static const char *car_emojis[2] = {"🚘️", "🚔️"};
static float waypoints[NUM_WAYPOINTS][2] = {
    {100, 50}, {150, 70}, {200, 50},   // Bottom left curve
    {300, 50}, {350, 70}, {400, 50},   // Bottom right curve
    {400, 400}, {350, 420}, {300, 400}, // Top right curve
    {200, 400}, {150, 420}, {100, 400}  // Top left curve
};
static int checkpoint_indices[NUM_CHECKPOINTS] = {0, 3, 6, 9}; // Checkpoints at corners

int get_window_width(void) { return WINDOW_WIDTH; }
int get_window_height(void) { return WINDOW_HEIGHT; }
int get_field_width(void) { return FIELD_WIDTH; }
int get_field_height(void) { return FIELD_HEIGHT; }
int get_grid_rows(void) { return 2; } // Player and police cars
int get_grid_cols(void) { return 1; }
int get_tile_size(void) { return CAR_SIZE; }
int get_grid_value(int r, int c) { return r; } // 0 for player, 1 for police
int get_selected_row(void) { return -1; }
int get_selected_col(void) { return -1; }
int get_score(void) { return score; }
const char* get_candy_emoji(int type) { return car_emojis[type]; }
const char* get_status_message(void) { return status_message; }
float get_car_x(int index) { return car_x[index]; }
float get_car_y(int index) { return car_y[index]; }
float get_car_angle(int index) { return car_angle[index]; }
float* get_waypoints(void) { return &waypoints[0][0]; }
int get_num_waypoints(void) { return NUM_WAYPOINTS; }
int* get_checkpoint_indices(void) { return checkpoint_indices; }
int get_num_checkpoints(void) { return NUM_CHECKPOINTS; }

void set_status_message(const char* msg) {
    strncpy(status_message, msg, sizeof(status_message) - 1);
    status_message[sizeof(status_message) - 1] = '\0';
}

void init(void) {
    car_x[0] = FIELD_WIDTH / 2.0f; car_y[0] = 50.0f; // Player at bottom
    car_x[1] = FIELD_WIDTH / 2.0f - 50.0f; car_y[1] = 50.0f; // Police nearby
    car_angle[0] = 90.0f; car_angle[1] = 90.0f; // Face up
    car_speed[0] = 0.0f; car_speed[1] = 0.0f;
    score = 0;
    lap_count = 0;
    set_status_message("Use arrows to steer, Enter to accelerate, Space to stop");
}

bool get_is_animating(void) { return car_speed[0] > 0.0f || car_speed[1] > 0.0f; }
void set_is_animating(bool value) { /* No-op, animation driven by speed */ }

void set_car_angle(float delta) {
    car_angle[0] += delta; // Player car only
    while (car_angle[0] >= 360.0f) car_angle[0] -= 360.0f;
    while (car_angle[0] < 0.0f) car_angle[0] += 360.0f;
}

void set_car_speed(float speed) {
    car_speed[0] = speed; // Player car only
    if (car_speed[0] > MAX_SPEED) car_speed[0] = MAX_SPEED;
    if (car_speed[0] < 0.0f) car_speed[0] = 0.0f;
}

float distance(float x1, float y1, float x2, float y2) {
    return sqrtf((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

void update_car_position(void) {
    // Player car movement
    if (car_speed[0] > 0.0f) {
        float rad = car_angle[0] * M_PI / 180.0f;
        car_x[0] += car_speed[0] * cosf(rad);
        car_y[0] += car_speed[0] * sinf(rad);
        // Boundary checking
        if (car_x[0] < 10.0f) car_x[0] = 10.0f;
        if (car_x[0] > FIELD_WIDTH + 10.0f - CAR_SIZE) car_x[0] = FIELD_WIDTH + 10.0f - CAR_SIZE;
        if (car_y[0] < 50.0f) car_y[0] = 50.0f;
        if (car_y[0] > FIELD_HEIGHT + 50.0f - CAR_SIZE) car_y[0] = FIELD_HEIGHT + 50.0f - CAR_SIZE;
        score += (int)(car_speed[0] * 10);
        // Check proximity to road
        float min_dist = INFINITY;
        int closest_waypoint = 0;
        for (int i = 0; i < NUM_WAYPOINTS; i++) {
            float dist = distance(car_x[0], car_y[0], waypoints[i][0], waypoints[i][1]);
            if (dist < min_dist) {
                min_dist = dist;
                closest_waypoint = i;
            }
        }
        if (min_dist > ROAD_RADIUS) {
            score -= 50;
            set_status_message("Stay on the road!");
        }
        // Check checkpoints
        for (int i = 0; i < NUM_CHECKPOINTS; i++) {
            int wp_idx = checkpoint_indices[i];
            if (distance(car_x[0], car_y[0], waypoints[wp_idx][0], waypoints[wp_idx][1]) < ROAD_RADIUS) {
                if (closest_waypoint == wp_idx) {
                    score += 100;
                    if (wp_idx == checkpoint_indices[0] && closest_waypoint != checkpoint_indices[NUM_CHECKPOINTS - 1]) {
                        lap_count++;
                        set_status_message("Lap completed!");
                    }
                    break;
                }
            }
        }
    }
    // Police car chase
    if (distance(car_x[0], car_y[0], car_x[1], car_y[1]) < 100.0f) {
        car_speed[1] = POLICE_SPEED;
        float dx = car_x[0] - car_x[1];
        float dy = car_y[0] - car_y[1];
        float angle_rad = atan2f(dy, dx);
        car_angle[1] = angle_rad * 180.0f / M_PI;
        car_x[1] += car_speed[1] * cosf(angle_rad);
        car_y[1] += car_speed[1] * sinf(angle_rad);
        // Boundary checking
        if (car_x[1] < 10.0f) car_x[1] = 10.0f;
        if (car_x[1] > FIELD_WIDTH + 10.0f - CAR_SIZE) car_x[1] = FIELD_WIDTH + 10.0f - CAR_SIZE;
        if (car_y[1] < 50.0f) car_y[1] = 50.0f;
        if (car_y[1] > FIELD_HEIGHT + 50.0f - CAR_SIZE) car_y[1] = FIELD_HEIGHT + 50.0f - CAR_SIZE;
        if (distance(car_x[0], car_y[0], car_x[1], car_y[1]) < CAR_SIZE) {
            set_status_message("Caught by police! Game over!");
            car_speed[0] = 0.0f;
            car_speed[1] = 0.0f;
        }
    } else {
        car_speed[1] = 0.0f;
    }
}
