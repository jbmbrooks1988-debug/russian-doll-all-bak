#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAP_WIDTH 80
#define MAP_HEIGHT 24

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <direction>\n", argv[0]);
        return 1;
    }

    char *direction = argv[1];
    int player_x, player_y;
    char map[MAP_HEIGHT][MAP_WIDTH + 2]; // +2 for newline and null terminator

    // Read player position
    FILE *pos_file = fopen("c_rewrite/player_pos.txt", "r");
    if (pos_file == NULL) {
        perror("Error opening player position file");
        return 1;
    }
    fscanf(pos_file, "%d,%d", &player_x, &player_y);
    fclose(pos_file);

    // Read map data
    FILE *map_file = fopen("c_rewrite/map.txt", "r");
    if (map_file == NULL) {
        perror("Error opening map file");
        return 1;
    }
    for (int i = 0; i < MAP_HEIGHT; i++) {
        if (fgets(map[i], sizeof(map[i]), map_file) == NULL) {
            break; // End of file or error
        }
    }
    fclose(map_file);

    // Calculate new position
    int new_x = player_x;
    int new_y = player_y;

    if (strcmp(direction, "up") == 0) {
        new_y--;
    } else if (strcmp(direction, "down") == 0) {
        new_y++;
    } else if (strcmp(direction, "left") == 0) {
        new_x--;
    } else if (strcmp(direction, "right") == 0) {
        new_x++;
    }

    // Check for collision
    if (new_x >= 0 && new_x < MAP_WIDTH && new_y >= 0 && new_y < MAP_HEIGHT) {
        if (map[new_y][new_x] != '#') {
            // Update player position
            pos_file = fopen("c_rewrite/player_pos.txt", "w");
            if (pos_file == NULL) {
                perror("Error opening player position file for writing");
                return 1;
            }
            fprintf(pos_file, "%d,%d\n", new_x, new_y);
            fclose(pos_file);
        }
    }

    return 0;
}
