#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>

#define MAP_WIDTH 80
#define MAP_HEIGHT 24
#define TILE_SIZE 10 // Size of a tile in pixels

char map[MAP_HEIGHT][MAP_WIDTH];
int player_x, player_y;

void load_map() {
    FILE *file = fopen("c_rewrite/map.txt", "r");
    if (file == NULL) {
        perror("Error opening map file");
        exit(1);
    }
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            int c = fgetc(file);
            if (c == EOF) break;
            if (c == '\n') {
                x--; // stay on the same x to re-read
                continue;
            }
            map[y][x] = c;
        }
        int c = fgetc(file);
        if (c != '\n' && c != EOF) {
            ungetc(c, file);
        }
    }
    fclose(file);
}

void load_player_pos() {
    FILE *file = fopen("c_rewrite/player_pos.txt", "r");
    if (file == NULL) {
        perror("Error opening player position file");
        exit(1);
    }
    fscanf(file, "%d,%d", &player_x, &player_y);
    fclose(file);
}

void render_map() {
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            if (map[y][x] == '#') {
                glColor3f(0.5f, 0.5f, 0.5f); // Grey for walls
            } else {
                glColor3f(0.2f, 0.2f, 0.2f); // Dark grey for floor
            }
            glBegin(GL_QUADS);
            glVertex2i(x * TILE_SIZE, y * TILE_SIZE);
            glVertex2i((x + 1) * TILE_SIZE, y * TILE_SIZE);
            glVertex2i((x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE);
            glVertex2i(x * TILE_SIZE, (y + 1) * TILE_SIZE);
            glEnd();
        }
    }
}

void render_player() {
    glColor3f(1.0f, 1.0f, 0.0f); // Yellow for player
    glRasterPos2i(player_x * TILE_SIZE + TILE_SIZE / 4, player_y * TILE_SIZE + TILE_SIZE - TILE_SIZE / 4);
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, '@');
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    render_map();
    render_player();
    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, MAP_WIDTH * TILE_SIZE, MAP_HEIGHT * TILE_SIZE, 0);
    glMatrixMode(GL_MODELVIEW);
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 27) { // ESC key
        exit(0);
    }
}

void special_keyboard(int key, int x, int y) {
    char command[256];
    char *direction = NULL;

    if (key == GLUT_KEY_UP) {
        direction = "up";
    } else if (key == GLUT_KEY_DOWN) {
        direction = "down";
    } else if (key == GLUT_KEY_LEFT) {
        direction = "left";
    } else if (key == GLUT_KEY_RIGHT) {
        direction = "right";
    }

    if (direction) {
        snprintf(command, sizeof(command), "./c_rewrite/player_control %s", direction);
        system(command);
        load_player_pos();
        glutPostRedisplay();
    }
}

int main(int argc, char** argv) {
    system("./c_rewrite/generate_map");

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(MAP_WIDTH * TILE_SIZE, MAP_HEIGHT * TILE_SIZE);
    glutCreateWindow("Angband Remake");

    glClearColor(0.0, 0.0, 0.0, 1.0); // Black background

    load_map();
    load_player_pos();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special_keyboard); // Register special key function

    glutMainLoop();

    return 0;
}
