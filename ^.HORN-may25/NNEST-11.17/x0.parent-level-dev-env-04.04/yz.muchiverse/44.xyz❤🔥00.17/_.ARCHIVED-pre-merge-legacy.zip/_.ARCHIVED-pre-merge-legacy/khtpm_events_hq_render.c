/* khtpm_events_hq_render.c — events-hq, real (not throwaway) event
 * editor. Reads/writes the SAME event_pkg/pages/page_N/event.ir.pdl
 * event-ez itself uses (studied live before writing this - see
 * 2do-rgb-hq.md's "Backend format" section), so both editors stay
 * compatible on the same data.
 *
 * Reuses every proven pattern from tonight's khtpm_hq_render.c (db-hq)
 * and khtpm_rgb_test.c (Phase 0): managed window + _MOTIF_WM_HINTS
 * decorations=0 (NOT override_redirect - see aug-12-END.txt's
 * "RESOLVED" focus section for why that distinction is load-bearing),
 * wraith-alpha-standard index nav, chrome-bar drag, real focus
 * diagnostics ("^" + status line). Layout is hand-computed x/y/w/h
 * (khtpm_css_parser.c has no flex/grid yet - see 2do-rgb-hq.md's own
 * "mockup reality check" for what was deliberately left out of the
 * port).
 *
 * Usage: khtpm_events_hq_render.+x <house_root> <event_pkg_dir> <entity_label>
 */
#include "khtpm_css_parser.h"
#include "khtpm_render_core.c" /* real .c, not a header - see that file's own comment */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/Xft/Xft.h>
#include <sys/select.h>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "lib/stb_image_write.h"

#define PATH_BUF 4096
#define MAX_ELEMS 128
#define MAX_CMDS 64
#define MAX_PAGES 16
/* Elem struct + MAX_CHILDREN now come from khtpm_render_core.h (Stage 2a
 * of the khtpm merge, 2026-08-16 - see that header's own comment). This
 * app's own Elem never used onclick/parent (the fuller shared struct
 * has both) or needed more than 32 children (shared MAX_CHILDREN is
 * 64) - neither is a behavior change here. */

static Elem g_pool[MAX_ELEMS];
static int g_n_elems = 0;
static char g_house_root[PATH_BUF];
static char g_pkg_dir[PATH_BUF];
static char g_entity_label[128];

/* REAL module launch (Stage 2d, 2026-08-16) - ported verbatim from
 * khtpm_hq_render.c's own launch_module()/cleanup_module()/
 * handle_term_signal(), itself ported from wraith_parser_alpha.c's own
 * launch_module(). Only difference from db-hq's version: this app is
 * legitimately multi-instance, so the manager needs the SAME 3 args
 * (house_root/pkg_dir/entity_label) the shell itself takes, not just
 * house_root - see khtpm_events_hq_manager.c's own header comment for
 * why pkg_dir-scoped state files give natural per-entity isolation. */
static pid_t g_module_pid = -1;

static void cleanup_module(void) {
    if (g_module_pid > 0) {
        kill(g_module_pid, SIGTERM);
        waitpid(g_module_pid, NULL, WNOHANG);
        g_module_pid = -1;
    }
}

static void handle_term_signal(int sig) {
    (void)sig;
    cleanup_module();
    _exit(0);
}

static void launch_module(const char *src) {
    if (!src || !src[0]) return;
    char full_path[PATH_BUF];
    if (src[0] == '/') snprintf(full_path, sizeof(full_path), "%s", src);
    else snprintf(full_path, sizeof(full_path), "%s/%s", g_house_root, src);

    g_module_pid = fork();
    if (g_module_pid == 0) {
        execl(full_path, full_path, g_house_root, g_pkg_dir, g_entity_label, (char *)NULL);
        _exit(1);
    } else if (g_module_pid < 0) {
        fprintf(stderr, "events-hq: launch_module: fork failed for %s\n", full_path);
        g_module_pid = -1;
    }
}

/* Real entity sprite, direct correction 2026-08-12 ("we render from a
 * real png for that character. do u see how it renders its own desktop
 * entity?"): the first attempt (Xft + Noto Color Emoji) hit a real,
 * confirmed-live X RENDER bug (BadLength on RenderAddGlyphs - color-
 * bitmap glyph fonts overflow this X server's RenderAddGlyphs request
 * size) and rendered nothing. The entity's REAL portrait is a raw RGBA
 * pixel dump, sprite.csv, sibling to event_pkg/ - exact same format and
 * parser as 01.muchi-pals-🥚️-13.01/system/egg_window.c's own
 * load_sprite() (studied before writing this, not guessed): a
 * "# resolution=N" header line, then N*N "r,g,b,a" rows in row-major
 * order. Drawn as plain XDrawPoint calls (blended against the toolbar's
 * own solid background color first, since Xlib has no alpha
 * compositing) - small enough (target ~36x36) that per-pixel drawing is
 * fine, no XImage/XPutImage needed. */
static unsigned char *g_sprite_pixels = NULL;
static int g_sprite_res = 0;

static void load_entity_sprite(void) {
    char path[PATH_BUF];
    snprintf(path, sizeof(path), "%s/../sprite.csv", g_pkg_dir);
    FILE *f = fopen(path, "r");
    if (!f) return;
    char line[256];
    int res = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "# resolution=", 13) == 0) { res = atoi(line + 13); break; }
    }
    if (res <= 0) { fclose(f); return; }
    unsigned char *pixels = malloc((size_t)res * (size_t)res * 4);
    if (!pixels) { fclose(f); return; }
    int count = 0;
    while (count < res * res && fgets(line, sizeof(line), f)) {
        int r, g, b, a;
        if (sscanf(line, "%d,%d,%d,%d", &r, &g, &b, &a) == 4) {
            pixels[count * 4 + 0] = (unsigned char)r;
            pixels[count * 4 + 1] = (unsigned char)g;
            pixels[count * 4 + 2] = (unsigned char)b;
            pixels[count * 4 + 3] = (unsigned char)a;
            count++;
        }
    }
    fclose(f);
    if (count != res * res) { free(pixels); return; }
    g_sprite_pixels = pixels;
    g_sprite_res = res;
}

static Elem *elem_new(const char *tag) {
    if (g_n_elems >= MAX_ELEMS) return NULL;
    Elem *e = &g_pool[g_n_elems++];
    memset(e, 0, sizeof(*e));
    snprintf(e->tag, sizeof(e->tag), "%s", tag);
    return e;
}

/* ---------- tiny generic tag-tree parser (same shape as khtpm_hq_render.c's) ---------- */
static void skip_ws(const char **p) { while (**p && isspace((unsigned char)**p)) (*p)++; }

static void parse_attr_value(const char **p, char *out, size_t outsz) {
    skip_ws(p);
    if (**p != '"') { out[0] = '\0'; return; }
    (*p)++;
    size_t n = 0;
    while (**p && **p != '"') { if (n + 1 < outsz) out[n++] = **p; (*p)++; }
    out[n] = '\0';
    if (**p == '"') (*p)++;
}

static void apply_attr(Elem *e, const char *name, const char *val) {
    if (strcmp(name, "id") == 0) snprintf(e->id, sizeof(e->id), "%s", val);
    else if (strcmp(name, "class") == 0) {
        char tmp[128]; snprintf(tmp, sizeof(tmp), "%s", val);
        char *tok = strtok(tmp, " ");
        while (tok && e->n_classes < CSS_MAX_CLASSES) {
            snprintf(e->classes[e->n_classes], sizeof(e->classes[0]), "%s", tok);
            e->n_classes++;
            tok = strtok(NULL, " ");
        }
    } else if (strcmp(name, "label") == 0) snprintf(e->label, sizeof(e->label), "%s", val);
    else if (strcmp(name, "src") == 0) {
        /* <module src="..."/> (Stage 2d, 2026-08-16) - reuses e->label,
         * same convention db-hq's own apply_attr() fix uses. */
        snprintf(e->label, sizeof(e->label), "%s", val);
    }
}

static const char *parse_element(const char *p, Elem *parent) {
    skip_ws(&p);
    if (*p != '<') return p;
    p++;
    if (*p == '!') { const char *end = strstr(p, "-->"); return end ? end + 3 : p + strlen(p); }
    char tag[32]; size_t tn = 0;
    while (*p && !isspace((unsigned char)*p) && *p != '>' && *p != '/') { if (tn + 1 < sizeof(tag)) tag[tn++] = *p; p++; }
    tag[tn] = '\0';
    Elem *e = elem_new(tag);
    if (parent && parent->n_children < MAX_CHILDREN) parent->children[parent->n_children++] = e;
    for (;;) {
        skip_ws(&p);
        if (*p == '/' && p[1] == '>') { p += 2; return p; }
        if (*p == '>') { p++; break; }
        if (!*p) return p;
        char attr[32]; size_t an = 0;
        while (*p && *p != '=' && !isspace((unsigned char)*p) && *p != '>' && *p != '/') { if (an + 1 < sizeof(attr)) attr[an++] = *p; p++; }
        attr[an] = '\0';
        skip_ws(&p);
        char val[256] = "";
        if (*p == '=') { p++; parse_attr_value(&p, val, sizeof(val)); }
        if (attr[0]) apply_attr(e, attr, val);
    }
    for (;;) {
        skip_ws(&p);
        if (!*p) return p;
        if (p[0] == '<' && p[1] == '/') { const char *end = strchr(p, '>'); return end ? end + 1 : p + strlen(p); }
        p = parse_element(p, e);
    }
}

static Elem *parse_chtpm(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)sz + 1);
    size_t rd = fread(buf, 1, (size_t)sz, f); buf[rd] = '\0';
    fclose(f);
    const char *p = buf;
    Elem *root = elem_new("__root__");
    for (;;) {
        skip_ws(&p);
        if (!*p) break;
        if (p[0] == '<' && p[1] == '!') { const char *end = strstr(p, "-->"); p = end ? end + 3 : p + strlen(p); continue; }
        break;
    }
    if (*p == '<') parse_element(p, root);
    if (root->n_children > 0) root = root->children[0];
    free(buf);
    return root;
}

/* find_by_id() now comes from khtpm_render_core.h (Stage 2a, 2026-08-16). */

/* ---------- real backend data: pages + commands, event_pkg/pages/page_N/ ---------- */

typedef struct {
    int id;
    char type[32];   /* change_gold / show_text / show_choices */
    char params[512]; /* raw text after "| " on the NODE row, for display */
} CmdNode;

static char g_pages[MAX_PAGES][64];
static int g_n_pages = 0;
static int g_current_page = 0; /* 0-based index into g_pages */

static CmdNode g_cmds[MAX_CMDS];
static int g_n_cmds = 0;
static char g_trigger[64] = "(unknown)";

/* REAL FIX 2026-08-16 (Stage 2d shell/manager split): page_dir()'s own
 * directory-listing, condition/IR parsing, and event.pal compilation
 * are now khtpm_events_hq_manager.c's job (a separate binary, launched
 * via dashboard.chtpm's own <module src="..."/> tag). This shell now
 * only reads what the manager publishes, and writes what the user does
 * back as a request - it never touches event_pkg's real files directly
 * anymore. State/action file paths live inside pkg_dir/.hq_manager/,
 * same per-entity scoping the manager itself uses (see that file's own
 * header comment for why). */
static char g_mgr_pages_state_path[PATH_BUF];
static char g_mgr_selected_page_path[PATH_BUF];
static char g_mgr_page_state_path[PATH_BUF];
static char g_mgr_action_path[PATH_BUF];
static time_t g_pages_state_mtime = 0;
static time_t g_page_state_mtime = 0;

static void init_manager_paths(void) {
    char mgr_dir[PATH_BUF];
    snprintf(mgr_dir, sizeof(mgr_dir), "%s/.hq_manager", g_pkg_dir);
    snprintf(g_mgr_pages_state_path, sizeof(g_mgr_pages_state_path), "%s/pages.state.txt", mgr_dir);
    snprintf(g_mgr_selected_page_path, sizeof(g_mgr_selected_page_path), "%s/selected_page.txt", mgr_dir);
    snprintf(g_mgr_page_state_path, sizeof(g_mgr_page_state_path), "%s/page.state.txt", mgr_dir);
    snprintf(g_mgr_action_path, sizeof(g_mgr_action_path), "%s/action.txt", mgr_dir);
}

/* Returns 1 if the page list actually changed (caller should refresh
 * pagetabs), 0 if unchanged - same mtime-gated pattern db-hq's own
 * load_common_events() fix uses. */
static int load_pages(void) {
    struct stat st;
    if (stat(g_mgr_pages_state_path, &st) != 0) return 0;
    if (st.st_mtime == g_pages_state_mtime) return 0;
    g_pages_state_mtime = st.st_mtime;

    g_n_pages = 0;
    FILE *f = fopen(g_mgr_pages_state_path, "r");
    if (!f) return 0;
    char line[128];
    while (g_n_pages < MAX_PAGES && fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (line[0] == '\0') continue;
        snprintf(g_pages[g_n_pages], sizeof(g_pages[0]), "%s", line);
        g_n_pages++;
    }
    fclose(f);
    if (g_current_page >= g_n_pages) g_current_page = 0;
    return 1;
}

/* Tells the manager which page is active - it publishes that page's
 * condition/commands to page.state.txt in response. */
static void write_selected_page(void) {
    if (g_current_page < 0 || g_current_page >= g_n_pages) return;
    FILE *f = fopen(g_mgr_selected_page_path, "w");
    if (!f) return;
    fprintf(f, "%s\n", g_pages[g_current_page]);
    fclose(f);
}

/* Returns 1 if trigger/commands actually changed (caller should refresh
 * the command list + trigger label), 0 if unchanged. */
static int load_page_state(void) {
    struct stat st;
    if (stat(g_mgr_page_state_path, &st) != 0) return 0;
    if (st.st_mtime == g_page_state_mtime) return 0;
    g_page_state_mtime = st.st_mtime;

    g_n_cmds = 0;
    snprintf(g_trigger, sizeof(g_trigger), "(unset)");
    FILE *f = fopen(g_mgr_page_state_path, "r");
    if (!f) return 1;
    char line[600];
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strncmp(line, "TRIGGER|", 8) == 0) {
            snprintf(g_trigger, sizeof(g_trigger), "%s", line + 8);
        } else if (strncmp(line, "CMD|", 4) == 0 && g_n_cmds < MAX_CMDS) {
            char *p = line + 4;
            char *bar1 = strchr(p, '|');
            if (!bar1) continue;
            *bar1 = '\0';
            g_cmds[g_n_cmds].id = atoi(p);
            char *type_start = bar1 + 1;
            char *bar2 = strchr(type_start, '|');
            if (!bar2) continue;
            *bar2 = '\0';
            snprintf(g_cmds[g_n_cmds].type, sizeof(g_cmds[0].type), "%s", type_start);
            snprintf(g_cmds[g_n_cmds].params, sizeof(g_cmds[0].params), "%s", bar2 + 1);
            g_n_cmds++;
        }
    }
    fclose(f);
    return 1;
}

/* Used to be append_node_and_compile() - now just writes the request,
 * the manager does the real event.ir.pdl append + event.pal recompile. */
static void request_append_node(const char *type, const char *params_line) {
    FILE *f = fopen(g_mgr_action_path, "w");
    if (!f) return;
    fprintf(f, "append:%s|%s\n", type, params_line);
    fclose(f);
}

/* ---------- X11/Xft globals, scale, layout (fixed x/y/w/h - no flex/grid) ---------- */
static Display *dpy;
static int screen;
static Window win;
static GC gc;
static Pixmap buf;
static XftDraw *xftdraw_buf;
static Colormap cmap;
static Elem *g_window;
static const CssSheet *g_sheet;
static int g_quit = 0;
static int g_has_real_focus = 0;
static char g_last_key_label[32] = "";

static int g_dragging = 0;
static int g_drag_last_x = 0, g_drag_last_y = 0;
static int g_win_x = 120, g_win_y = 120;

static int g_toolbar_y = 0, g_toolbar_h = 0; /* for draw_entity_glyph()'s own positioning */
static Elem g_close_elem_storage;
static Elem *g_close_elem = &g_close_elem_storage;
static int g_close_x, g_close_y, g_close_w, g_close_h;
#define CHROME_H 26

static Elem *g_nav[MAX_ELEMS];
static int g_n_nav = 0;
static int g_focus_nav = 1;
static int g_digit_accum = 0;

/* picker (add-command) mode state - own simple modal-like overlay,
 * drawn directly (no separate popout process - simpler state sharing
 * for a small 3-type form), matching 2do-rgb-hq.md's own scope call
 * ("command-type picker... a small real popout" - implemented here as
 * an in-window overlay instead of a second X11 window for simplicity,
 * a real, working substitution for the mockup's own position:fixed
 * modal, which the CSS engine can't do yet either). */
static int g_picker_open = 0;
static int g_picker_type = -1; /* 0=change_gold 1=show_text 2=show_choices, -1=choosing */
static int g_picker_focus = 1; /* own nav counter for the 3 type choices - separate from g_focus_nav, which belongs to the outer window */
static char g_field1[256] = "", g_field2[256] = "";
static int g_active_field = 0; /* 0 or 1 */
static const char *PICKER_TYPES[] = { "change_gold", "show_text", "show_choices" };
static const char *PICKER_LABELS[] = { "Change Gold", "Show Text", "Show Choices" };

static void apply_css(Elem *e) {
    css_compute_style(g_sheet, e->tag, e->id[0] ? e->id : NULL, e->classes, e->n_classes, 0, &e->style);
}

/* Stage 1 khtpm merge fix (khtpm-merge-how2.md §3.2), font-cache pattern
 * ported verbatim from chat_hai_hq_render.c/khtpm_hq_render.c's own
 * measure_text_px() fix - was opening+closing a font on every call. */
static int measure_text_px(const CssStyle *st, const char *text) {
    char spec[128];
    const char *fam = st->has_font_family ? st->font_family : "DejaVu Sans";
    int size = st->has_font_size ? st->font_size : 11;
    snprintf(spec, sizeof(spec), "%s:pixelsize=%d%s", fam, size, (st->has_font_weight && st->font_weight_bold) ? ":bold" : "");

    static char cached_spec[128] = "";
    static XftFont *cached_font = NULL;
    XftFont *f;
    if (cached_font && strcmp(cached_spec, spec) == 0) {
        f = cached_font;
    } else {
        if (cached_font) XftFontClose(dpy, cached_font);
        f = XftFontOpenName(dpy, screen, spec);
        if (!f) f = XftFontOpenName(dpy, screen, "DejaVu Sans:pixelsize=11");
        cached_font = f;
        snprintf(cached_spec, sizeof(cached_spec), "%s", spec);
    }
    if (!f) return (int)strlen(text) * 7;
    XGlyphInfo ext;
    XftTextExtentsUtf8(dpy, f, (const FcChar8 *)text, (int)strlen(text), &ext);
    return ext.width;
}

static void layout_pass(Elem *window) {
    apply_css(window);
    window->x = 0; window->y = 0;
    window->w = 720; window->h = 480;

    g_close_w = 56; g_close_h = CHROME_H - 6;
    g_close_x = window->w - g_close_w - 4;
    g_close_y = 3;

    Elem *toolbar = find_by_id(window, "toolbar");
    Elem *pagetabs = find_by_id(window, "pagetabs");
    Elem *left = find_by_id(window, "left");
    Elem *right = find_by_id(window, "right");
    Elem *footer = find_by_id(window, "footer");

    int toolbar_h = 46, tabs_h = 26, footer_h = 34; /* taller toolbar to fit the real entity glyph, see draw_entity_glyph() */
    int y = CHROME_H;
    if (toolbar) {
        apply_css(toolbar);
        toolbar->x = 0; toolbar->y = y; toolbar->w = window->w; toolbar->h = toolbar_h;
        g_toolbar_y = toolbar->y; g_toolbar_h = toolbar->h;
        for (int i = 0; i < toolbar->n_children; i++) {
            Elem *c = toolbar->children[i]; apply_css(c);
            /* +46 leaves room for the glyph icon drawn separately in
             * draw_entity_glyph() (chrome, not a tag-tree element - same
             * approach the close button already uses). */
            c->x = 46; c->y = toolbar->y + toolbar_h / 2 - 9; c->w = window->w - 56; c->h = 18;
        }
        y += toolbar_h;
    }
    if (pagetabs) {
        apply_css(pagetabs);
        /* REAL PORT 2026-08-16, Stage 3 (khtpm-merge-how2.md §5.3 step
         * 5, events-hq) - real §5.1b pattern #2, same shape as db-hq's
         * own tabbar port. Same real asymmetric geometry (4px left-only
         * main-axis margin, 2px/4px cross-inset, +1px per-tab gap) that
         * doesn't reduce to the engine's own uniform padding/gap - same
         * real hand-adjustment technique applied after the engine call. */
        for (int i = 0; i < pagetabs->n_children; i++) {
            Elem *tab = pagetabs->children[i]; apply_css(tab);
            tab->w = measure_text_px(&tab->style, tab->label) + 30; /* real natural width, written into e->w per the engine's own contract */
        }
        /* REAL FIX, same real bug class as db-hq's own tabbar (caught
         * there first, applied here too): give the engine the real
         * FULL container box (x=0), not the 4px-shrunk one, so
         * pagetabs's own background fill doesn't leave a real unfilled
         * sliver - add the 4px margin to children by hand instead. */
        pagetabs->style.has_display = 1; pagetabs->style.display_flex = 1;
        pagetabs->style.has_flex_direction = 1; pagetabs->style.flex_row = 1;
        css_layout_pass(pagetabs, 0, y, window->w, tabs_h);
        for (int i = 0; i < pagetabs->n_children; i++) {
            Elem *tab = pagetabs->children[i];
            tab->x += 4 + i; /* real 4px left margin + cumulative +1px-per-tab gap */
            tab->y = y + 2; tab->h = tabs_h - 4; /* real cross-axis inset */
        }
        y += tabs_h;
    }
    int content_y = y, content_h = window->h - y - footer_h;
    int left_w = 220;
    if (left) {
        apply_css(left);
        /* REAL PORT - real §5.1b patterns #1+#5 together, same shape
         * as db-hq's own panel port. Real, confirmed live (this
         * session, same day, db-hq's own panel port): the title's
         * extra top clearance the ORIGINAL code never even had here
         * (left->y+16 was for CONTENT start, title itself used its own
         * hardcoded left->x+10/left->y-8 - NOT read from style.top/
         * left at all) turns out to match dashboard.css's own real
         * `.block-title` rule (top:-8/left:10) exactly - the engine's
         * real position:absolute handling (which DOES read style.top/
         * left) produces the identical result, so the hardcoded
         * special-case is real, safely removable here too. */
        for (int i = 0; i < left->n_children; i++) {
            Elem *c = left->children[i]; apply_css(c);
            if (strcmp(c->tag, "title") == 0) {
                c->w = measure_text_px(&c->style, c->label) + 10; c->h = 14;
                continue;
            }
            c->style.has_height = 1; c->style.height = 18;
        }
        left->style.has_display = 1; left->style.display_flex = 1;
        left->style.has_flex_direction = 1; left->style.flex_row = 0;
        left->style.has_padding = 1; left->style.padding = 10;
        left->style.has_gap = 1; left->style.gap = 6;
        css_layout_pass(left, 4, content_y + 8, left_w, content_h - 12);
    }
    if (right) {
        apply_css(right);
        for (int i = 0; i < right->n_children; i++) {
            Elem *c = right->children[i]; apply_css(c);
            if (strcmp(c->tag, "title") == 0) {
                c->w = measure_text_px(&c->style, c->label) + 10; c->h = 14;
                continue;
            }
            c->style.has_height = 1; c->style.height = 18;
        }
        right->style.has_display = 1; right->style.display_flex = 1;
        right->style.has_flex_direction = 1; right->style.flex_row = 0;
        right->style.has_padding = 1; right->style.padding = 12;
        right->style.has_gap = 1; right->style.gap = 4;
        css_layout_pass(right, left_w + 8, content_y + 8, window->w - left_w - 16, content_h - 12);
    }
    if (footer) {
        apply_css(footer);
        /* REAL PORT - real §5.1b pattern #2, but UNLIKE the tabbar/
         * pagetabs above, this one's real geometry genuinely IS
         * uniform (6px cross-axis both sides, real 8px gap) except for
         * a real 10px-vs-6px main-axis-start-vs-cross mismatch - same
         * hand-adjustment technique as pagetabs for that one real
         * remaining asymmetry, but real gap now comes from the engine
         * itself (no per-index manual addition needed, unlike the
         * tabbar/pagetabs' own +1px case). */
        for (int i = 0; i < footer->n_children; i++) {
            Elem *c = footer->children[i]; apply_css(c);
            c->w = measure_text_px(&c->style, c->label) + 20;
        }
        /* REAL FIX, same real bug class as tabbar/pagetabs: real full
         * container box (x=0), 10px real left margin added to children
         * by hand instead of shrinking footer's own real background box. */
        footer->style.has_display = 1; footer->style.display_flex = 1;
        footer->style.has_flex_direction = 1; footer->style.flex_row = 1;
        footer->style.has_gap = 1; footer->style.gap = 8;
        css_layout_pass(footer, 0, window->h - footer_h, window->w, footer_h);
        for (int i = 0; i < footer->n_children; i++) {
            Elem *c = footer->children[i];
            c->x += 10; /* real left margin */
            c->y = footer->y + 6; c->h = footer_h - 12; /* real cross-axis inset */
        }
    }
}

/* rebuild the command-list panel's children from g_cmds (real data),
 * replacing the placeholder <text id="cmd-empty"> - same
 * inject-at-runtime pattern db-hq's own inject_sidebar_items() used. */
static void inject_commands(Elem *window) {
    Elem *right = find_by_id(window, "right");
    if (!right) return;
    /* keep the <title> child, drop everything else, rebuild */
    Elem *title = NULL;
    for (int i = 0; i < right->n_children; i++) if (strcmp(right->children[i]->tag, "title") == 0) title = right->children[i];
    right->n_children = 0;
    if (title) right->children[right->n_children++] = title;
    if (g_n_cmds == 0) {
        Elem *e = elem_new("text");
        snprintf(e->classes[0], sizeof(e->classes[0]), "empty-msg"); e->n_classes = 1;
        snprintf(e->label, sizeof(e->label), "(no commands yet)");
        right->children[right->n_children++] = e;
        return;
    }
    for (int i = 0; i < g_n_cmds && right->n_children < MAX_CHILDREN; i++) {
        Elem *e = elem_new("text");
        char cls[48]; snprintf(cls, sizeof(cls), "cmd-%s", g_cmds[i].type);
        snprintf(e->classes[0], sizeof(e->classes[0]), "%s", cls); e->n_classes = 1;
        snprintf(e->label, sizeof(e->label), "%d. %s  %s", g_cmds[i].id, g_cmds[i].type, g_cmds[i].params);
        right->children[right->n_children++] = e;
    }
}

static void refresh_page_data(Elem *window) {
    write_selected_page(); /* tell the manager which page is now active */
    load_page_state(); /* pick up whatever it last published - may be stale until its next poll, caught by the main loop's own periodic re-poll */
    Elem *tv = find_by_id(window, "trigger-value");
    if (tv) snprintf(tv->label, sizeof(tv->label), "%s", g_trigger);
    inject_commands(window);
    Elem *pagetabs = find_by_id(window, "pagetabs");
    if (pagetabs) {
        pagetabs->n_children = 0;
        for (int i = 0; i < g_n_pages && pagetabs->n_children < MAX_CHILDREN; i++) {
            Elem *t = elem_new("tab");
            snprintf(t->label, sizeof(t->label), "%s", g_pages[i]);
            t->active = (i == g_current_page);
            pagetabs->children[pagetabs->n_children++] = t;
        }
    }
    Elem *en = find_by_id(window, "event-name");
    if (en) snprintf(en->label, sizeof(en->label), "%s", g_entity_label);
}

static void assign_nav_indices(Elem *window) {
    g_n_nav = 0;
    Elem *pagetabs = find_by_id(window, "pagetabs");
    if (pagetabs) for (int i = 0; i < pagetabs->n_children && g_n_nav < MAX_ELEMS; i++) {
        pagetabs->children[i]->nav_index = ++g_n_nav; g_nav[g_n_nav - 1] = pagetabs->children[i];
    }
    Elem *footer = find_by_id(window, "footer");
    if (footer) for (int i = 0; i < footer->n_children && g_n_nav < MAX_ELEMS; i++) {
        footer->children[i]->nav_index = ++g_n_nav; g_nav[g_n_nav - 1] = footer->children[i];
    }
    if (g_n_nav < MAX_ELEMS) { g_close_elem->nav_index = ++g_n_nav; g_nav[g_n_nav - 1] = g_close_elem; }
    if (g_focus_nav < 1) g_focus_nav = 1;
    if (g_focus_nav > g_n_nav) g_focus_nav = g_n_nav > 0 ? g_n_nav : 1;
}

/* ---------- rendering ---------- */
static unsigned long alloc_pixel(const char *spec) {
    if (!spec || !spec[0]) return BlackPixel(dpy, screen);
    XColor c;
    if (spec[0] == '#') { if (XParseColor(dpy, cmap, spec, &c) && XAllocColor(dpy, cmap, &c)) return c.pixel; }
    else if (XAllocNamedColor(dpy, cmap, spec, &c, &c)) return c.pixel;
    return BlackPixel(dpy, screen);
}

static XftColor xft_color(const char *spec) {
    XftColor xc; XRenderColor rc = {0, 0, 0, 0xffff};
    if (spec && spec[0] == '#' && strlen(spec) >= 7) {
        unsigned int r, g, b; sscanf(spec + 1, "%02x%02x%02x", &r, &g, &b);
        rc.red = (unsigned short)(r * 257); rc.green = (unsigned short)(g * 257); rc.blue = (unsigned short)(b * 257);
    }
    XftColorAllocValue(dpy, DefaultVisual(dpy, screen), cmap, &rc, &xc); return xc;
}

/* Stage 1 khtpm merge fix (khtpm-merge-how2.md §3.2) - draw_elem() calls
 * this per-element, every frame; same cache pattern as measure_text_px()
 * above. Caller must NOT XftFontClose() the returned font anymore. */
static XftFont *font_for(const CssStyle *st) {
    char spec[128];
    const char *fam = st->has_font_family ? st->font_family : "DejaVu Sans";
    int size = st->has_font_size ? st->font_size : 11;
    snprintf(spec, sizeof(spec), "%s:pixelsize=%d%s", fam, size, (st->has_font_weight && st->font_weight_bold) ? ":bold" : "");

    static char cached_spec[128] = "";
    static XftFont *cached_font = NULL;
    if (cached_font && strcmp(cached_spec, spec) == 0) return cached_font;
    if (cached_font) XftFontClose(dpy, cached_font);
    XftFont *f = XftFontOpenName(dpy, screen, spec);
    if (!f) f = XftFontOpenName(dpy, screen, "DejaVu Sans:pixelsize=11");
    cached_font = f;
    snprintf(cached_spec, sizeof(cached_spec), "%s", spec);
    return f;
}

static void draw_elem(Elem *e) {
    if (e->style.has_bg_color) { XSetForeground(dpy, gc, alloc_pixel(e->style.bg_color)); XFillRectangle(dpy, buf, gc, e->x, e->y, e->w, e->h); }
    if (e->style.has_border_color) {
        XSetForeground(dpy, gc, alloc_pixel(e->style.border_color));
        XDrawRectangle(dpy, buf, gc, e->x, e->y, e->w - 1, e->h - 1);
    }
    if (strcmp(e->tag, "tab") == 0 && e->active && !e->style.has_bg_color) {
        XSetForeground(dpy, gc, alloc_pixel("#3a3a3a")); XFillRectangle(dpy, buf, gc, e->x, e->y, e->w, e->h);
    }
    if (e->nav_index > 0 && e->nav_index == g_focus_nav) {
        XSetForeground(dpy, gc, alloc_pixel("#ff8c00"));
        XDrawRectangle(dpy, buf, gc, e->x - 1, e->y - 1, e->w + 1, e->h + 1);
    }
    int pad = 4;
    int label_x = e->x + pad;
    if (e->nav_index > 0) {
        char badge[16];
        int focused = (e->nav_index == g_focus_nav);
        /* REAL FIX 2026-08-12 - see khtpm_hq_render.c's identical fix
         * for the full citation: real std is `[state]N.`, not `[stateN]`. */
        snprintf(badge, sizeof(badge), "[%c]%d.", focused ? '>' : ' ', e->nav_index);
        char numspec[48]; snprintf(numspec, sizeof(numspec), "DejaVu Sans Mono:pixelsize=9");
        XftFont *numfont = XftFontOpenName(dpy, screen, numspec);
        if (numfont) {
            XftColor numcol = xft_color(focused ? "#ff8c00" : "#9a9a9a");
            XGlyphInfo numext; XftTextExtentsUtf8(dpy, numfont, (const FcChar8 *)badge, (int)strlen(badge), &numext);
            int numy = e->y + (e->h + numfont->ascent - numfont->descent) / 2;
            XftDrawStringUtf8(xftdraw_buf, &numcol, numfont, label_x, numy, (const FcChar8 *)badge, (int)strlen(badge));
            XftColorFree(dpy, DefaultVisual(dpy, screen), cmap, &numcol);
            label_x += numext.width + 5;
            XftFontClose(dpy, numfont);
        }
    }
    if (e->label[0]) {
        XftFont *font = font_for(&e->style);
        if (font) {
            XftColor col = xft_color(e->style.has_fg_color ? e->style.fg_color : "#cccccc");
            int ty = e->y + (e->h + font->ascent - font->descent) / 2;
            XftDrawStringUtf8(xftdraw_buf, &col, font, label_x, ty, (const FcChar8 *)e->label, (int)strlen(e->label));
            XftColorFree(dpy, DefaultVisual(dpy, screen), cmap, &col);
            /* font_for() now returns a cached, shared handle - do not close it. */
        }
    }
}

static void render_tree(Elem *e) {
    for (int i = 0; i < e->n_children; i++) {
        Elem *c = e->children[i];
        if (strcmp(c->tag, "title") == 0) continue;
        if (strcmp(c->tag, "module") == 0) continue; /* pure config, never visual - see apply_attr()'s src= comment */
        draw_elem(c);
        render_tree(c);
    }
    for (int i = 0; i < e->n_children; i++) if (strcmp(e->children[i]->tag, "title") == 0) draw_elem(e->children[i]);
}

/* real entity portrait/glyph, drawn large in the toolbar (not a
 * tag-tree Elem - chrome, same approach the close button already
 * uses). Direct request: "make sure we get the image of the character
 * in that window early on also for user sanity" - so it's the FIRST
 * real thing visible under the title bar, confirming which entity is
 * actually being edited before touching anything. Needs Noto Color
 * Emoji specifically (confirmed installed: `fc-list | grep -i emoji`)
 * - DejaVu Sans has no emoji glyphs. */
static void draw_entity_glyph(void) {
    if (!g_sprite_pixels || g_sprite_res <= 0) return;
    int size = 36; /* target on-screen box */
    int ox = 6, oy = g_toolbar_y + (g_toolbar_h - size) / 2;
    /* toolbar's own solid bg color (#2f2f2f, dashboard.css's .toolbar) -
     * blended against manually since Xlib point-drawing has no alpha
     * compositing of its own. */
    int bg_r = 0x2f, bg_g = 0x2f, bg_b = 0x2f;
    for (int y = 0; y < size; y++) {
        int sy = y * g_sprite_res / size;
        for (int x = 0; x < size; x++) {
            int sx = x * g_sprite_res / size;
            const unsigned char *px = &g_sprite_pixels[(sy * g_sprite_res + sx) * 4];
            int a = px[3];
            if (a == 0) continue;
            int r = (px[0] * a + bg_r * (255 - a)) / 255;
            int g = (px[1] * a + bg_g * (255 - a)) / 255;
            int b = (px[2] * a + bg_b * (255 - a)) / 255;
            char spec[8]; snprintf(spec, sizeof(spec), "#%02x%02x%02x", r, g, b);
            XSetForeground(dpy, gc, alloc_pixel(spec));
            XDrawPoint(dpy, buf, gc, ox + x, oy + y);
        }
    }
}

static void draw_chrome_bar(void) {
    XSetForeground(dpy, gc, alloc_pixel("#1c1c1c"));
    XFillRectangle(dpy, buf, gc, 0, 0, g_window->w, CHROME_H);
    char tspec[48]; snprintf(tspec, sizeof(tspec), "DejaVu Sans:pixelsize=10:bold");
    XftFont *titlefont = XftFontOpenName(dpy, screen, tspec);
    if (titlefont) {
        XftColor titlecol = xft_color("#eeeeee");
        char title[48]; snprintf(title, sizeof(title), "events-hq %s", g_has_real_focus ? "^" : " ");
        int ty = (CHROME_H + titlefont->ascent - titlefont->descent) / 2;
        XftDrawStringUtf8(xftdraw_buf, &titlecol, titlefont, 8, ty, (const FcChar8 *)title, (int)strlen(title));
        XftColorFree(dpy, DefaultVisual(dpy, screen), cmap, &titlecol);
        XftFontClose(dpy, titlefont);
    }
    g_close_elem->x = g_close_x; g_close_elem->y = g_close_y; g_close_elem->w = g_close_w; g_close_elem->h = g_close_h;
    snprintf(g_close_elem->label, sizeof(g_close_elem->label), "x");
    css_style_init(&g_close_elem->style);
    g_close_elem->style.has_border_color = 1;
    snprintf(g_close_elem->style.border_color, sizeof(g_close_elem->style.border_color), "%s", g_close_elem->nav_index == g_focus_nav ? "#ff8c00" : "#888888");
    g_close_elem->style.has_fg_color = 1;
    snprintf(g_close_elem->style.fg_color, sizeof(g_close_elem->style.fg_color), "#eeeeee");
    draw_elem(g_close_elem);
}

static void draw_picker_overlay(void) {
    int pw = 360, ph = 160;
    int px = (g_window->w - pw) / 2, py = (g_window->h - ph) / 2;
    XSetForeground(dpy, gc, alloc_pixel("#2a2a2a"));
    XFillRectangle(dpy, buf, gc, px, py, pw, ph);
    XSetForeground(dpy, gc, alloc_pixel("#4a9eff"));
    XDrawRectangle(dpy, buf, gc, px, py, pw - 1, ph - 1);
    XftFont *font = XftFontOpenName(dpy, screen, "DejaVu Sans:pixelsize=11");
    XftFont *bfont = XftFontOpenName(dpy, screen, "DejaVu Sans:pixelsize=11:bold");
    if (!font || !bfont) return;
    XftColor white = xft_color("#eeeeee");
    XftColor gray = xft_color("#999999");
    int ty = py + 20;
    if (g_picker_type < 0) {
        const char *hdr = "Add Command";
        XftDrawStringUtf8(xftdraw_buf, &white, bfont, px + 14, ty, (const FcChar8 *)hdr, (int)strlen(hdr));
        ty += 26;
        /* real wraith-alpha nav in the picker too, not a bespoke "press
         * 1/2/3" scheme - direct correction 2026-08-12: "submenus should
         * use nav as well. u stopped using nav for add command? no
         * good". Same "[>N]"/"[ N]" bracket-badge convention as
         * everywhere else in the app - g_picker_focus is its own
         * counter (not g_focus_nav, which belongs to the outer window
         * and must stay untouched while this overlay is open). */
        for (int i = 0; i < 3; i++) {
            int focused = (i + 1 == g_picker_focus);
            /* REAL FIX 2026-08-12 - real std is `[state]N.`, see
             * khtpm_hq_render.c's identical fix for the full citation. */
            char badge[16]; snprintf(badge, sizeof(badge), "[%c]%d.", focused ? '>' : ' ', i + 1);
            XftColor *bc = focused ? &white : &gray;
            XftDrawStringUtf8(xftdraw_buf, bc, font, px + 20, ty, (const FcChar8 *)badge, (int)strlen(badge));
            char line[64]; snprintf(line, sizeof(line), "%s", PICKER_LABELS[i]);
            XftDrawStringUtf8(xftdraw_buf, &white, font, px + 60, ty, (const FcChar8 *)line, (int)strlen(line));
            if (focused) { XSetForeground(dpy, gc, alloc_pixel("#ff8c00")); XDrawRectangle(dpy, buf, gc, px + 16, ty - 14, pw - 32, 18); }
            ty += 22;
        }
        const char *hint = "Digits/arrows + Enter select, Escape cancels";
        XftDrawStringUtf8(xftdraw_buf, &gray, font, px + 14, py + ph - 14, (const FcChar8 *)hint, (int)strlen(hint));
    } else {
        char hdr[64]; snprintf(hdr, sizeof(hdr), "%s", PICKER_LABELS[g_picker_type]);
        XftDrawStringUtf8(xftdraw_buf, &white, bfont, px + 14, ty, (const FcChar8 *)hdr, (int)strlen(hdr));
        ty += 30;
        const char *f1_label = strcmp(PICKER_TYPES[g_picker_type], "change_gold") == 0 ? "Amount:" :
                                strcmp(PICKER_TYPES[g_picker_type], "show_text") == 0 ? "Text:" : "Choices (comma-sep):";
        char f1line[300]; snprintf(f1line, sizeof(f1line), "%s %s%s", f1_label, g_field1, g_active_field == 0 ? "_" : "");
        XftColor *c1 = g_active_field == 0 ? &white : &gray;
        XftDrawStringUtf8(xftdraw_buf, c1, font, px + 20, ty, (const FcChar8 *)f1line, (int)strlen(f1line));
        ty += 24;
        if (strcmp(PICKER_TYPES[g_picker_type], "change_gold") != 0) {
            const char *f2_label = strcmp(PICKER_TYPES[g_picker_type], "show_text") == 0 ? "Speaker (opt):" : "Default index:";
            char f2line[300]; snprintf(f2line, sizeof(f2line), "%s %s%s", f2_label, g_field2, g_active_field == 1 ? "_" : "");
            XftColor *c2 = g_active_field == 1 ? &white : &gray;
            XftDrawStringUtf8(xftdraw_buf, c2, font, px + 20, ty, (const FcChar8 *)f2line, (int)strlen(f2line));
            ty += 24;
        }
        const char *hint2 = "Enter: next/submit  Escape: cancel";
        XftDrawStringUtf8(xftdraw_buf, &gray, font, px + 14, py + ph - 14, (const FcChar8 *)hint2, (int)strlen(hint2));
    }
    XftColorFree(dpy, DefaultVisual(dpy, screen), cmap, &white);
    XftColorFree(dpy, DefaultVisual(dpy, screen), cmap, &gray);
    XftFontClose(dpy, font); XftFontClose(dpy, bfont);
}

static void redraw(void) {
    layout_pass(g_window);
    assign_nav_indices(g_window);
    XSetForeground(dpy, gc, alloc_pixel("#252525"));
    XFillRectangle(dpy, buf, gc, 0, 0, g_window->w, g_window->h);
    render_tree(g_window);
    draw_entity_glyph();
    draw_chrome_bar();
    if (g_picker_open) draw_picker_overlay();
    XCopyArea(dpy, buf, win, gc, 0, 0, (unsigned)g_window->w, (unsigned)g_window->h, 0, 0);
    XFlush(dpy);
}

/* ---------- input ---------- */
/* hit_test() now comes from khtpm_render_core.h (Stage 2a, 2026-08-16). */

static void activate_elem(Elem *hit) {
    if (!hit) return;
    if (strcmp(hit->tag, "closebtn") == 0) { g_quit = 1; return; }
    if (strcmp(hit->tag, "tab") == 0) {
        for (int i = 0; i < g_n_pages; i++) if (strcmp(hit->label, g_pages[i]) == 0) { g_current_page = i; break; }
        refresh_page_data(g_window);
        redraw();
        return;
    }
    if (strcmp(hit->id, "add-command") == 0) {
        g_picker_open = 1; g_picker_type = -1; g_picker_focus = 1; g_field1[0] = '\0'; g_field2[0] = '\0'; g_active_field = 0;
        redraw();
        return;
    }
}

static void handle_click(int px, int py) {
    if (px >= g_close_elem->x && px < g_close_elem->x + g_close_elem->w && py >= g_close_elem->y && py < g_close_elem->y + g_close_elem->h) {
        g_focus_nav = g_close_elem->nav_index; activate_elem(g_close_elem); return;
    }
    Elem *hit = hit_test(g_window, px, py);
    if (!hit) return;
    if (hit->nav_index > 0) g_focus_nav = hit->nav_index;
    activate_elem(hit);
}

static void submit_picker(void) {
    const char *type = PICKER_TYPES[g_picker_type];
    char params[512];
    if (strcmp(type, "change_gold") == 0) snprintf(params, sizeof(params), "amount=%s", g_field1[0] ? g_field1 : "0");
    else if (strcmp(type, "show_text") == 0) {
        if (g_field2[0]) snprintf(params, sizeof(params), "text=%s speaker=%s", g_field1, g_field2);
        else snprintf(params, sizeof(params), "text=%s", g_field1);
    } else snprintf(params, sizeof(params), "choices=%s default=%s", g_field1, g_field2[0] ? g_field2 : "0");
    request_append_node(type, params);
    /* real command list update is async now (the manager owns the
     * write+recompile) - main loop's periodic load_page_state() re-poll
     * picks it up and redraws once the manager actually publishes it,
     * same pattern db-hq's own action round-trip uses. */
    g_picker_open = 0;
    redraw();
}

/* REAL ADD 2026-08-16, Stage 3 (khtpm-merge-how2.md §5.3 step 5) - this
 * file's own 'p' key handler used to be a real, documented no-op ("no
 * debug dump wired for events-hq yet") - a real, pre-existing testing
 * gap this house's own §7 "Testing convention" section flags as
 * something to add before trusting live verification on an app that's
 * missing it. Ported verbatim from db-hq's own proven dump_frame_png()
 * shape (same real XGetImage->RGB-unpack->stb_image_write.h pattern
 * already used by every other khtpm app this session touched). */
static void dump_frame_png(void) {
    if (!g_window) { fprintf(stderr, "events-hq: dump_frame_png: no frame composed yet\n"); return; }
    int w = g_window->w, h = g_window->h;
    XImage *img = XGetImage(dpy, buf, 0, 0, (unsigned)w, (unsigned)h, AllPlanes, ZPixmap);
    if (!img) { fprintf(stderr, "events-hq: dump_frame_png: XGetImage failed\n"); return; }
    unsigned char *rgb = malloc((size_t)w * h * 3);
    if (!rgb) { XDestroyImage(img); return; }
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            unsigned long px = XGetPixel(img, x, y);
            size_t o = ((size_t)y * w + x) * 3;
            rgb[o] = (unsigned char)((px >> 16) & 0xff);
            rgb[o + 1] = (unsigned char)((px >> 8) & 0xff);
            rgb[o + 2] = (unsigned char)(px & 0xff);
        }
    }
    XDestroyImage(img);
    int ok = stbi_write_png("/tmp/events-hq-frame.png", w, h, 3, rgb, w * 3);
    fprintf(stderr, ok ? "events-hq: wrote /tmp/events-hq-frame.png (%dx%d)\n" : "events-hq: dump_frame_png: write failed\n", w, h);
    free(rgb);
}

/* REAL ADD 2026-08-16, Stage 3 (khtpm-merge-how2.md §5.3 step 5) - real,
 * same reasoning as dump_frame_png() just above: this file had no relay-
 * injection input at all, a real pre-existing gap this house's own
 * testing convention (§7) expects every khtpm app to have. Ported
 * verbatim from db-hq's own proven relay_path()/dispatch_relay_code()/
 * poll_agent_relay() shape - real decimal-ASCII-code-per-line protocol,
 * same "never replay backlog on first poll" real convention. */
static void handle_key(KeySym ks, char ch);
static long g_relay_cursor = -1;
static void relay_path(char *out, size_t outsz) {
    snprintf(out, outsz, "%s/#.desktop/events_hq_agent_relay.txt", g_house_root);
}
static void dispatch_relay_code(int code) {
    if (code == 13) handle_key(XK_Return, 0);
    else if (code == 27) handle_key(XK_Escape, 0);
    else if (code == 8) handle_key(XK_BackSpace, 0);
    else if (code >= 32 && code <= 126) handle_key(0, (char)code);
}
static int poll_agent_relay(void) {
    char path[PATH_BUF];
    relay_path(path, sizeof(path));
    struct stat stt;
    if (stat(path, &stt) != 0) return 0;
    if (g_relay_cursor < 0) { g_relay_cursor = stt.st_size; return 0; }
    if (stt.st_size < g_relay_cursor) { g_relay_cursor = stt.st_size; return 0; }
    if (stt.st_size == g_relay_cursor) return 0;
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    fseek(f, g_relay_cursor, SEEK_SET);
    char line[32];
    long consumed = g_relay_cursor;
    int n_dispatched = 0;
    while (fgets(line, sizeof(line), f)) {
        char *nl = strchr(line, '\n');
        if (!nl) break;
        *nl = '\0';
        long here = ftell(f);
        int code = atoi(line);
        if (code > 0) { dispatch_relay_code(code); n_dispatched++; }
        consumed = here;
    }
    fclose(f);
    g_relay_cursor = consumed;
    return n_dispatched;
}

static void handle_key(KeySym ks, char ch) {
    if (g_picker_open) {
        if (ks == XK_Escape) { g_picker_open = 0; redraw(); return; }
        if (g_picker_type < 0) {
            /* real wraith-alpha nav for the type-choice list too, not a
             * bespoke scheme - digits/arrows move g_picker_focus (own
             * counter, doesn't touch the outer window's g_focus_nav),
             * Enter activates, exactly like every other nav list in
             * this house. */
            if (ch >= '1' && ch <= '3') { g_picker_focus = ch - '0'; redraw(); }
            else if (ks == XK_Up || ks == XK_Left) { if (g_picker_focus > 1) g_picker_focus--; redraw(); }
            else if (ks == XK_Down || ks == XK_Right || ks == XK_Tab) { if (g_picker_focus < 3) g_picker_focus++; redraw(); }
            else if (ks == XK_Return || ks == XK_KP_Enter) { g_picker_type = g_picker_focus - 1; redraw(); }
            return;
        }
        int single_field = (strcmp(PICKER_TYPES[g_picker_type], "change_gold") == 0);
        char *active = g_active_field == 0 ? g_field1 : g_field2;
        size_t asz = g_active_field == 0 ? sizeof(g_field1) : sizeof(g_field2);
        if (ks == XK_Return || ks == XK_KP_Enter) {
            if (!single_field && g_active_field == 0) { g_active_field = 1; redraw(); return; }
            submit_picker();
            return;
        }
        if (ks == XK_BackSpace) { size_t l = strlen(active); if (l > 0) active[l - 1] = '\0'; redraw(); return; }
        if (ch >= 32 && ch <= 126) {
            size_t l = strlen(active);
            if (l + 1 < asz) { active[l] = ch; active[l + 1] = '\0'; }
            redraw();
            return;
        }
        return;
    }
    if (ch == 'p') { dump_frame_png(); return; }
    if (ks == XK_Return || ks == XK_KP_Enter) {
        if (g_digit_accum > 0 && g_digit_accum <= g_n_nav) g_focus_nav = g_digit_accum;
        g_digit_accum = 0;
        if (g_focus_nav >= 1 && g_focus_nav <= g_n_nav) activate_elem(g_nav[g_focus_nav - 1]);
        return;
    }
    if (ks == XK_Escape) { if (g_digit_accum > 0) { g_digit_accum = 0; return; } g_quit = 1; return; }
    if (ch >= '0' && ch <= '9') {
        int d = ch - '0';
        int new_val = g_digit_accum * 10 + d;
        if (new_val > 0 && new_val <= g_n_nav) { g_digit_accum = new_val; g_focus_nav = new_val; redraw(); }
        else if (d > 0 && d <= g_n_nav) { g_digit_accum = d; g_focus_nav = d; redraw(); }
        else g_digit_accum = 0;
        return;
    }
    if (ks == XK_Up || ks == XK_Left) { if (g_focus_nav > 1) g_focus_nav--; g_digit_accum = 0; redraw(); return; }
    if (ks == XK_Down || ks == XK_Right || ks == XK_Tab) { if (g_focus_nav < g_n_nav) g_focus_nav++; g_digit_accum = 0; redraw(); return; }
    g_digit_accum = 0;
}

/* Real X error found live: rendering the entity's color-emoji glyph
 * (Noto Color Emoji) via Xft/RENDER can hit BadLength on
 * RenderAddGlyphs (large bitmap-strike glyph data), which by default
 * calls exit() and kills the whole editor over one decorative icon.
 * Non-fatal handler so a single bad RENDER request degrades (that one
 * draw call silently fails) instead of crashing the app - the glyph is
 * a "for user sanity" nicety, not something worth losing the whole
 * editor over. */
static int nonfatal_x_error(Display *d, XErrorEvent *e) {
    char buf[128]; XGetErrorText(d, e->error_code, buf, sizeof(buf));
    fprintf(stderr, "events-hq: X error (non-fatal): %s (request %d.%d)\n", buf, e->request_code, e->minor_code);
    return 0;
}

int main(int argc, char **argv) {
    XSetErrorHandler(nonfatal_x_error);
    if (argc < 4) { fprintf(stderr, "usage: %s <house_root> <event_pkg_dir> <entity_label>\n", argv[0]); return 1; }
    snprintf(g_house_root, sizeof(g_house_root), "%s", argv[1]);
    snprintf(g_pkg_dir, sizeof(g_pkg_dir), "%s", argv[2]);
    snprintf(g_entity_label, sizeof(g_entity_label), "%s", argv[3]);

    signal(SIGTERM, handle_term_signal); /* see handle_term_signal()'s own header comment (db-hq's own fix, ported) */
    signal(SIGINT, handle_term_signal);

    memset(g_close_elem, 0, sizeof(*g_close_elem));
    snprintf(g_close_elem->tag, sizeof(g_close_elem->tag), "closebtn");

    if (access(g_pkg_dir, F_OK) != 0) mkdir(g_pkg_dir, 0755);
    init_manager_paths();
    load_pages(); /* likely a no-op the first call - manager hasn't published yet, main loop's own periodic re-poll picks it up within ~400ms */
    load_entity_sprite();

    char chtpm_path[PATH_BUF];
    snprintf(chtpm_path, sizeof(chtpm_path), "%s/&.widgits/events-hq/pieces/dashboard.chtpm", g_house_root);
    Elem *window = parse_chtpm(chtpm_path);
    if (!window) { fprintf(stderr, "events-hq: failed to parse %s\n", chtpm_path); return 1; }
    g_window = window;

    /* REAL module launch (Stage 2d, 2026-08-16) - same real mechanism
     * proven on db-hq, see khtpm_hq_render.c's own main() for the
     * identical shape. */
    Elem *module_elem = find_by_tag(window, "module");
    if (module_elem && module_elem->label[0]) launch_module(module_elem->label);
    atexit(cleanup_module);

    char css_path[PATH_BUF];
    snprintf(css_path, sizeof(css_path), "%s/&.widgits/events-hq/pieces/dashboard.css", g_house_root);
    static CssSheet sheet; memset(&sheet, 0, sizeof(sheet));
    css_load(css_path, &sheet);
    g_sheet = &sheet;

    dpy = XOpenDisplay(NULL);
    if (!dpy) { fprintf(stderr, "events-hq: cannot open display\n"); return 1; }
    screen = DefaultScreen(dpy);
    cmap = DefaultColormap(dpy, screen);

    refresh_page_data(window);
    layout_pass(window);
    int ww = window->w, wh = window->h;

    /* real managed window + _MOTIF_WM_HINTS decorations=0 - NOT
     * override_redirect, per aug-12-END.txt's own "RESOLVED" section
     * (db-hq's whole keyboard-focus struggle this session). Reused
     * verbatim, not re-derived. */
    XSetWindowAttributes swa;
    /* REAL FIX 2026-08-16 (deferred earlier this session, "white flash
     * is low priority" then "lets handle the events flash and move
     * on"): WhitePixel shown before the first real (dark) redraw()
     * paints was a real viewer-safety issue. Same real dark-default fix
     * open-hai/khtpm_entity_menu_render.c already proved this session. */
    swa.background_pixel = alloc_pixel("#141414");
    swa.event_mask = ExposureMask | ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | KeyPressMask | StructureNotifyMask | FocusChangeMask;
    win = XCreateWindow(dpy, RootWindow(dpy, screen), g_win_x, g_win_y, (unsigned)ww, (unsigned)wh, 0,
                         CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWEventMask, &swa);
    {
        Atom motif_hints = XInternAtom(dpy, "_MOTIF_WM_HINTS", False);
        long hints[5] = { 2, 0, 0, 0, 0 };
        XChangeProperty(dpy, win, motif_hints, motif_hints, 32, PropModeReplace, (unsigned char *)hints, 5);
        XWMHints *wmhints = XAllocWMHints();
        if (wmhints) { wmhints->flags = InputHint; wmhints->input = True; XSetWMHints(dpy, win, wmhints); XFree(wmhints); }
        Atom wm_delete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
        XSetWMProtocols(dpy, win, &wm_delete, 1);
        XClassHint *ch = XAllocClassHint();
        if (ch) { ch->res_name = (char *)"MuchiverseLivedesk"; ch->res_class = (char *)"MuchiverseLivedesk"; XSetClassHint(dpy, win, ch); XFree(ch); }

        /* REAL FIX 2026-08-16 (direct report: "it still seemed to open
         * at 0,0 . is that set by layout or .pdl config?"): this app
         * never had the PPosition fix db-hq/chat-hai already got on
         * 2026-08-13 for the identical bug - without PPosition, Mutter
         * treats XCreateWindow's x/y as unspecified and auto-places the
         * window (commonly landing at 0,0 or another arbitrary spot),
         * completely ignoring g_win_x/g_win_y (120,120). Ported
         * verbatim from khtpm_hq_render.c's own fix - see that file's
         * own comment for the full incident history. */
        XSizeHints *shints = XAllocSizeHints();
        if (shints) {
            shints->flags = PPosition;
            shints->x = g_win_x;
            shints->y = g_win_y;
            XSetWMNormalHints(dpy, win, shints);
            XFree(shints);
        }
    }
    XMapRaised(dpy, win);
    XSync(dpy, False);
    { XWindowAttributes wa; if (XGetWindowAttributes(dpy, win, &wa)) { g_win_x = wa.x; g_win_y = wa.y; } }

    gc = XCreateGC(dpy, win, 0, NULL);
    buf = XCreatePixmap(dpy, win, (unsigned)ww, (unsigned)wh, (unsigned)DefaultDepth(dpy, screen));
    xftdraw_buf = XftDrawCreate(dpy, buf, DefaultVisual(dpy, screen), cmap);

    redraw();

    while (!g_quit) {
        /* Stage 2d shell/manager split: pick up the manager's latest
         * publishes (both mtime-gated, cheap every tick). load_pages()
         * changing means the page list itself changed (a page added/
         * removed); load_page_state() changing means the CURRENT page's
         * trigger/commands changed (e.g. after request_append_node()'s
         * write actually gets serviced). */
        if (load_pages() || load_page_state()) {
            refresh_page_data(g_window);
            redraw();
        }

        if (poll_agent_relay() > 0) redraw(); /* real relay-injection input, see poll_agent_relay()'s own header comment */

        fd_set fds; FD_ZERO(&fds);
        int xfd = ConnectionNumber(dpy); FD_SET(xfd, &fds);
        struct timeval tv = { 0, 150000 };
        select(xfd + 1, &fds, NULL, NULL, &tv);

        while (XPending(dpy)) {
            XEvent ev; XNextEvent(dpy, &ev);
            if (ev.type == Expose) {
                redraw();
            } else if (ev.type == ButtonPress) {
                if (!g_picker_open && ev.xbutton.button == 1 && ev.xbutton.y < CHROME_H &&
                    !(ev.xbutton.x >= g_close_elem->x && ev.xbutton.x < g_close_elem->x + g_close_elem->w &&
                      ev.xbutton.y >= g_close_elem->y && ev.xbutton.y < g_close_elem->y + g_close_elem->h)) {
                    g_dragging = 1; g_drag_last_x = ev.xbutton.x_root; g_drag_last_y = ev.xbutton.y_root;
                }
                if (ev.xbutton.button != 3 && !g_picker_open) handle_click(ev.xbutton.x, ev.xbutton.y);
            } else if (ev.type == ButtonRelease && ev.xbutton.button == 1) {
                g_dragging = 0;
            } else if (ev.type == MotionNotify) {
                if (g_dragging) {
                    int dx = ev.xmotion.x_root - g_drag_last_x, dy = ev.xmotion.y_root - g_drag_last_y;
                    g_win_x += dx; g_win_y += dy;
                    XMoveWindow(dpy, win, g_win_x, g_win_y);
                    g_drag_last_x = ev.xmotion.x_root; g_drag_last_y = ev.xmotion.y_root;
                }
            } else if (ev.type == KeyPress) {
                char buf8[8]; KeySym ks;
                int n = XLookupString(&ev.xkey, buf8, sizeof(buf8) - 1, &ks, NULL);
                buf8[n > 0 ? n : 0] = '\0';
                const char *kname = XKeysymToString(ks);
                snprintf(g_last_key_label, sizeof(g_last_key_label), "%s", kname ? kname : "?");
                handle_key(ks, buf8[0]);
            } else if (ev.type == FocusIn) {
                g_has_real_focus = 1; redraw();
            } else if (ev.type == FocusOut) {
                g_has_real_focus = 0; redraw();
            } else if (ev.type == ClientMessage) {
                Atom wm_delete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
                if ((Atom)ev.xclient.data.l[0] == wm_delete) g_quit = 1;
            }
        }
    }

    XftDrawDestroy(xftdraw_buf);
    XFreePixmap(dpy, buf);
    XFreeGC(dpy, gc);
    XDestroyWindow(dpy, win);
    XCloseDisplay(dpy);
    return 0;
}
