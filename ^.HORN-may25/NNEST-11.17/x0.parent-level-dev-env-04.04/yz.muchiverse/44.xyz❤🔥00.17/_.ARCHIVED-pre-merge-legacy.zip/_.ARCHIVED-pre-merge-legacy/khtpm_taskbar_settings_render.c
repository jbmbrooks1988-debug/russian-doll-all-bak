#define _POSIX_C_SOURCE 199309L
/* khtpm_taskbar_settings_render.c — "Settings" window for the taskbar's
 * HQ menu (cell 1). Stage 2c REAL PORT (2026-08-16, direct instruction
 * "lets finish menu.chtpm work then do stage 2") onto the shared Elem/
 * CSS render model - 6th real consumer of &.widgits/_shared-lib/
 * khtpm_render_core.c (after db-hq, events-hq, chat-hai,
 * khtpm_entity_menu_render.c) and a real consumer of khtpm_css_parser.c
 * (same as db-hq/events-hq/chat-hai). First of 3 in this stage
 * (taskbar-settings -> ai-cell -> the taskbar itself, smallest/most-
 * isolated first, direct choice). Old hand-drawn version kept at
 * khtpm_taskbar_settings_render.c.bak-2026-08-16-stage2c.
 *
 * Layout/palette now live in taskbar_settings.chtpm/.css (12 swatch
 * <item>s, each its own CSS class - direct choice: named classes over
 * inline style, since the palette is fixed and never changes). All
 * REAL business logic preserved exactly from the old version:
 *   - apply_theme() read-modify-write into #.desktop/livedesk_theme.pdl,
 *     preserving unrelated COLOR rows, then the same scoped
 *     run_khtpm_strip.sh restart the HQ menu's own $.restart row uses.
 *   - 2-phase pick (primary then secondary), auto-closes after phase 2.
 *   - Real WM dance for Wayland/mutter (_MOTIF_WM_HINTS, PPosition/
 *     USPosition/PSize, _NET_WM_WINDOW_TYPE_DIALOG + explicit
 *     XMoveWindow after map) - the "opens too high" fix from 2026-08-13,
 *     unchanged, still needed regardless of render architecture.
 *   - pidfile+SIGTERM, digit-jump nav, PNG+receipt dump, relay testing -
 *     all real house conventions, all preserved.
 *
 * Usage: khtpm_taskbar_settings_render.+x <house_root>
 */
#include "khtpm_css_parser.h"
#include "khtpm_render_core.c" /* real .c, not a header - see that file's own comment */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/Xft/Xft.h>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "lib/stb_image_write.h"

#define PATH_BUF 4096
#define MAX_ELEMS 64
#define CHROME_H 28
#define SWATCH 34
#define SWATCH_GAP 8
#define SWATCH_COLS 6
#define WIN_W 420

static char g_house_root[PATH_BUF];
static char g_audit_dir[PATH_BUF];
static char g_pid_path[PATH_BUF];
static char g_chtpm_path[PATH_BUF];
static char g_css_path[PATH_BUF];

/* ---------- tiny generic tag-tree parser (same shape as
 * khtpm_entity_menu_render.c's own - not reinvented) ---------- */
static Elem g_pool[MAX_ELEMS];
static int g_n_elems = 0;
static Elem *elem_new(const char *tag) {
    if (g_n_elems >= MAX_ELEMS) return NULL;
    Elem *e = &g_pool[g_n_elems++];
    memset(e, 0, sizeof(*e));
    snprintf(e->tag, sizeof(e->tag), "%s", tag);
    return e;
}
static void skip_ws(const char **p) { while (**p && isspace((unsigned char)**p)) (*p)++; }
static void parse_attr_value(const char **p, char *out, size_t outsz) {
    skip_ws(p);
    if (**p != '"') { out[0] = '\0'; return; }
    (*p)++;
    size_t n = 0;
    while (**p && **p != '"') { if (n + 1 < outsz) out[n++] = **p; (*p)++; }
    out[n] = '\0';
    if (**p == '"') (*p)++;
}
static void apply_attr(Elem *e, const char *name, const char *val) {
    if (strcmp(name, "id") == 0 || strcmp(name, "name") == 0) {
        snprintf(e->id, sizeof(e->id), "%s", val);
    } else if (strcmp(name, "class") == 0) {
        char tmp[128]; snprintf(tmp, sizeof(tmp), "%s", val);
        char *tok = strtok(tmp, " ");
        while (tok && e->n_classes < CSS_MAX_CLASSES) {
            snprintf(e->classes[e->n_classes], sizeof(e->classes[0]), "%s", tok);
            e->n_classes++;
            tok = strtok(NULL, " ");
        }
    } else if (strcmp(name, "label") == 0) {
        snprintf(e->label, sizeof(e->label), "%s", val);
    }
}
static const char *parse_element(const char *p, Elem *parent) {
    skip_ws(&p);
    if (*p != '<') return p;
    p++;
    if (*p == '!') {
        const char *end = strstr(p, "-->");
        return end ? end + 3 : p + strlen(p);
    }
    char tag[32]; size_t tn = 0;
    while (*p && !isspace((unsigned char)*p) && *p != '>' && *p != '/') {
        if (tn + 1 < sizeof(tag)) tag[tn++] = *p;
        p++;
    }
    tag[tn] = '\0';
    Elem *e = elem_new(tag);
    e->parent = parent;
    if (parent && parent->n_children < MAX_CHILDREN) parent->children[parent->n_children++] = e;
    for (;;) {
        skip_ws(&p);
        if (*p == '/' && p[1] == '>') { p += 2; return p; }
        if (*p == '>') { p++; break; }
        if (!*p) return p;
        char attr[32]; size_t an = 0;
        while (*p && *p != '=' && !isspace((unsigned char)*p) && *p != '>' && *p != '/') {
            if (an + 1 < sizeof(attr)) attr[an++] = *p;
            p++;
        }
        attr[an] = '\0';
        skip_ws(&p);
        char val[256] = "";
        if (*p == '=') { p++; parse_attr_value(&p, val, sizeof(val)); }
        if (attr[0]) apply_attr(e, attr, val);
    }
    for (;;) {
        skip_ws(&p);
        if (!*p) return p;
        if (p[0] == '<' && p[1] == '/') {
            const char *end = strchr(p, '>');
            return end ? end + 1 : p + strlen(p);
        }
        p = parse_element(p, e);
    }
}
static Elem *parse_chtpm(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t rd = fread(buf, 1, (size_t)sz, f);
    buf[rd] = '\0';
    fclose(f);
    const char *p = buf;
    Elem *root = NULL;
    while (*p) {
        skip_ws(&p);
        if (!*p) break;
        if (*p == '<' && p[1] == '!') { p = parse_element(p, NULL); continue; }
        if (*p != '<') break;
        if (!root) { root = elem_new("__root"); p = parse_element(p, root); }
        else p = parse_element(p, root);
    }
    free(buf);
    if (root && root->n_children > 0) return root->children[0];
    return root;
}

static Elem *g_window;
static Elem *find_page(const char *name) {
    for (int i = 0; i < g_window->n_children; i++) {
        Elem *c = g_window->children[i];
        if (strcmp(c->tag, "page") == 0 && strcmp(c->id, name) == 0) return c;
    }
    return NULL;
}

static CssSheet g_sheet;

/* ---------- X11/Xft ---------- */
static Display *dpy;
static Window win;
static GC gc;
static Pixmap buf;
static Visual *vis;
static Colormap cmap;
static XftDraw *xftdraw_buf;
static XftFont *font_small, *font_med;
static XftColor col_text, col_muted, col_accent, col_danger;
static Atom wm_delete;
static int g_win_w = WIN_W, g_win_h = 280;
static int g_running = 0;
static struct timespec g_map_time;
#define PHANTOM_CLICK_GUARD_MS 150

static volatile sig_atomic_t g_want_exit = 0;
static void handle_sigterm(int sig) { (void)sig; g_want_exit = 1; }
static void write_pidfile(void) { FILE *f = fopen(g_pid_path, "w"); if (f) { fprintf(f, "%d\n", (int)getpid()); fclose(f); } }
static void unlink_pidfile(void) { remove(g_pid_path); }
static int nonfatal_x_error(Display *d, XErrorEvent *e) { (void)d; (void)e; return 0; }
/* REAL Stage 5 (2026-08-16, khtpm-merge-how2.md §5d) - renamed from
 * xft_color() to avoid colliding with the shared, generic
 * `XftColor xft_color(const char*)` (khtpm_draw_core.c, return-value
 * style, different real signature) - this out-param version stays for
 * the 4 real, legitimately-chrome-only colors below (col_text/muted/
 * accent/danger), never used by the shared draw_elem() path. */
static void xft_color_out(const char *hexname, XftColor *out) { XftColorAllocName(dpy, vis, cmap, hexname, out); }
static void load_fonts(void) {
    font_small = XftFontOpenName(dpy, DefaultScreen(dpy), "Sans-8");
    font_med = XftFontOpenName(dpy, DefaultScreen(dpy), "Sans-9");
}
static void draw_text(XftFont *f, XftColor *c, int x, int y, const char *s) {
    XftDrawStringUtf8(xftdraw_buf, c, f, x, y, (const FcChar8 *)s, (int)strlen(s));
}
static unsigned long parse_hex_pixel(const char *hex) {
    XColor c;
    if (XParseColor(dpy, cmap, hex, &c) && XAllocColor(dpy, cmap, &c)) return c.pixel;
    return BlackPixel(dpy, DefaultScreen(dpy));
}

/* nav: swatch grid (0..11, real elem pointers now, not a bare index) + close */
#define MAX_NAV 32
static Elem *g_nav[MAX_NAV];
static int g_n_nav = 0;
static int g_focus_nav = 1;
static int g_digit_accum = 0;

/* REAL Stage 5 (2026-08-16, khtpm-merge-how2.md §5d) - real `screen`
 * global (was a local in main() only) - the shared draw layer below
 * needs it visible everywhere, same as db-hq/entity-menu already have.
 * scaled() has no real DPI-scale source for this small popup window
 * yet - identity for now. Both must be declared BEFORE
 * khtpm_draw_core.c's own functions (below) reference them. */
static int screen;
static int scaled(int base_px) { return base_px; }
#include "khtpm_draw_core.c"

/* phase 0 = picking primary(bg), phase 1 = picking secondary(fg), phase 2 = done/closing */
static int g_phase = 0;
static int g_chosen_bg_idx = -1;
static int g_chosen_fg_idx = -1;
static const char *g_palette_hex[12];
static const char *g_palette_name[12];

/* REAL Stage 5 starter-app proof (2026-08-16, khtpm-merge-how2.md
 * §5d.3 step 1, direct correction re: real op binaries vs #include-
 * based text sharing) - this used to BE the business logic (read-
 * modify-write livedesk_theme.pdl, spawn a taskbar restart), living
 * directly inside the render loop. Now a real, standalone, app-local
 * op binary (apply_theme_op.c, same dir, matches TPMOS's own real
 * per-project ops/*.c convention), invoked via system() - this
 * renderer no longer contains that logic at all, only the call. */
/* REAL Stage 5 step 5 (2026-08-16, khtpm-merge-how2.md §5d.3) - real,
 * generic dispatch, matching entity-menu's own dispatch() shape
 * exactly (CLOSE/void handled here, anything else run as a real full
 * command string via system()) - the real, shared piece a future
 * literal binary merge needs both apps to agree on. entity-menu's own
 * GOTO:/BACK page-navigation forms are intentionally NOT handled here
 * - this app has no pages, and per §5d.3 step 5's own real finding,
 * unifying that part isn't needed for this merge, only the CLOSE/void/
 * external-command shape is. */
static void dispatch(const char *action) {
    if (strcmp(action, "CLOSE") == 0) { g_running = 0; return; }
    if (strcmp(action, "void") == 0) { g_running = 0; return; }
    int rc = system(action);
    (void)rc;
    g_running = 0;
}

static void apply_theme(const char *bg_hex, const char *fg_hex) {
    char cmd[PATH_BUF * 2];
    snprintf(cmd, sizeof(cmd), "'%s/*.monads/*.livedesk-taskbar/ops/+x/apply_theme_op.+x' '%s' '%s' '%s'",
             g_house_root, g_house_root, bg_hex, fg_hex);
    dispatch(cmd);
}

static void assign_nav_and_layout(void) {
    g_n_nav = 0;
    Elem *page = find_page("main");
    if (!page) return;
    int x0 = 16, y0 = CHROME_H + 44;
    int sw_i = 0;
    for (int i = 0; i < page->n_children; i++) {
        Elem *item = page->children[i];
        if (strcmp(item->tag, "item") != 0) continue;
        if (strcmp(item->id, "close") == 0) {
            item->x = g_win_w - 60; item->y = 0; item->w = 60; item->h = CHROME_H;
        } else {
            int col = sw_i % SWATCH_COLS, row = sw_i / SWATCH_COLS;
            item->x = x0 + col * (SWATCH + SWATCH_GAP);
            item->y = y0 + row * (SWATCH + SWATCH_GAP);
            item->w = SWATCH; item->h = SWATCH;
            /* REAL Stage 5 bug fix (2026-08-16, found live) - each
             * swatch's real label="black"/"white"/etc attribute in
             * taskbar_settings.chtpm was always unused metadata (real
             * palette names come from the separate g_palette_name[]
             * array) - the OLD hand-drawn redraw() never referenced
             * item->label for swatches at all, but the new SHARED,
             * generic draw_elem() draws e->label unconditionally,
             * which put color-name text overlapping every swatch.
             * Real fix: clear it here, before the shared draw path
             * ever sees it - the .chtpm's own label= stays as real,
             * harmless documentation data. */
            item->label[0] = '\0';
            sw_i++;
        }
        item->nav_index = ++g_n_nav;
        g_nav[g_n_nav - 1] = item;
        css_compute_style(&g_sheet, item->tag, item->id, item->classes, item->n_classes, 0, &item->style);
    }
    if (g_focus_nav > g_n_nav) g_focus_nav = g_n_nav > 0 ? g_n_nav : 1;
    if (g_focus_nav < 1) g_focus_nav = 1;
}

static void redraw(void) {
    assign_nav_and_layout();
    XSetForeground(dpy, gc, 0x141414);
    XFillRectangle(dpy, buf, gc, 0, 0, (unsigned)g_win_w, (unsigned)g_win_h);

    XSetForeground(dpy, gc, 0x1a1a1a);
    XFillRectangle(dpy, buf, gc, 0, 0, (unsigned)g_win_w, CHROME_H);
    /* REAL Stage 4 proof (2026-08-16, khtpm-merge-how2.md §5b) - was a
     * hardcoded literal here; now real DATA read from <window label="..."/>
     * in taskbar_settings.chtpm via the SAME generic label= attribute
     * parse_element() already applies to every other tag - zero parser/
     * struct changes needed, this Elem's own g_window->label already
     * holds it once parsed. Fallback covers a .chtpm with no label=. */
    draw_text(font_small, &col_muted, 10, CHROME_H - 9,
              g_window->label[0] ? g_window->label : "taskbar settings");

    const char *title = g_phase == 0 ? "Pick PRIMARY, then Enter"
                       : g_phase == 1 ? "Pick SECONDARY, then Enter"
                       : "Applied - closing...";
    draw_text(font_med, &col_text, 16, CHROME_H + 26, title);

    /* REAL Stage 5 (2026-08-16, khtpm-merge-how2.md §5d) - was a manual
     * per-item draw loop (bg fill, custom badge format, white focus
     * ring); now the shared, generic render_tree() (khtpm_draw_core.c),
     * same real convention every other khtpm app uses - close button's
     * own "x" label and nav badge now render through the SAME generic
     * path too (was a bespoke special case, real simplification, not
     * just a port). Real, deliberate visual changes: focus ring is now
     * the shared orange (was white), every item's own badge is now the
     * standard "[>]N." format (was a bare number for swatches). */
    Elem *page = find_page("main");
    if (page) render_tree(page, 0);

    /* REAL, remaining app-specific overlay (2026-08-16) - the "chosen"
     * bg/fg pick ring is a real, small visual extension the shared
     * draw_elem() doesn't have a generic concept for yet (documented,
     * legitimate exception, same category as chat-hai's panel in
     * Stage 3) - drawn as a small extra pass AFTER the generic tree
     * render, not baked into the shared function. */
    int sw_i = 0;
    for (int i = 0; page && i < page->n_children; i++) {
        Elem *item = page->children[i];
        if (strcmp(item->tag, "item") != 0 || strcmp(item->id, "close") == 0) continue;
        int chosen = (sw_i == g_chosen_bg_idx) || (sw_i == g_chosen_fg_idx);
        if (chosen && item->nav_index != g_focus_nav) {
            XSetForeground(dpy, gc, 0x22c55e);
            XDrawRectangle(dpy, buf, gc, item->x - 2, item->y - 2, (unsigned)item->w + 4, (unsigned)item->h + 4);
        }
        sw_i++;
    }
    int y0 = CHROME_H + 44, x0 = 16;

    if (g_chosen_bg_idx >= 0) {
        char line[64];
        snprintf(line, sizeof(line), "primary: %s", g_palette_name[g_chosen_bg_idx]);
        draw_text(font_small, &col_accent, x0, y0 + 2 * (SWATCH + SWATCH_GAP) + 20, line);
    }
    if (g_chosen_fg_idx >= 0) {
        char line[64];
        snprintf(line, sizeof(line), "secondary: %s", g_palette_name[g_chosen_fg_idx]);
        draw_text(font_small, &col_accent, x0, y0 + 2 * (SWATCH + SWATCH_GAP) + 38, line);
    }

    XSync(dpy, False);
    XImage *frame = XGetImage(dpy, buf, 0, 0, (unsigned)g_win_w, (unsigned)g_win_h, AllPlanes, ZPixmap);
    if (frame) { XPutImage(dpy, win, gc, frame, 0, 0, 0, 0, (unsigned)g_win_w, (unsigned)g_win_h); XDestroyImage(frame); }
    XFlush(dpy);
}

static void dump_frame_png(void) {
    char png[PATH_BUF], receipt[PATH_BUF];
    snprintf(png, sizeof(png), "%s/settings-frame.png", g_audit_dir);
    snprintf(receipt, sizeof(receipt), "%s/settings-frame.png.receipt.txt", g_audit_dir);
    XSync(dpy, False);
    int w = g_win_w, h = g_win_h;
    /* REAL Stage 1 follow-up (2026-08-16, direct correction: "u are
     * using include instead of launching the binary thru fork/exec/sys
     * like tpmos/wraith does. this is the standard for binary calls") -
     * real, standalone op binary (khtpm-merge-how2.md §1b), invoked via
     * system() like fuzz-op/ops/toggle_clock.c's own real precedent for
     * a synchronous, one-shot op - was a locally-duplicated XImage->RGB
     * unpack loop. Captures the real, already-blitted WINDOW directly
     * (own X connection, can't reach into this process's own `buf`
     * Pixmap anyway) rather than the internal back-buffer. */
    char cmd[PATH_BUF * 2];
    snprintf(cmd, sizeof(cmd), "'%s/&.widgits/_shared-lib/ops/+x/dump_frame_png_op.+x' 0x%lx '%s'",
             g_house_root, (unsigned long)win, png);
    int ok = (system(cmd) == 0);
    FILE *rf = fopen(receipt, "w");
    if (rf) {
        fprintf(rf, "ok=%d w=%d h=%d t=%ld nav=%d n_nav=%d phase=%d bg_idx=%d fg_idx=%d\n",
                ok, w, h, (long)time(NULL), g_focus_nav, g_n_nav, g_phase, g_chosen_bg_idx, g_chosen_fg_idx);
        fclose(rf);
    }
}

static void activate_focused(void) {
    if (g_focus_nav < 1 || g_focus_nav > g_n_nav) return;
    Elem *item = g_nav[g_focus_nav - 1];
    /* REAL Stage 5 step 5 - now routes through the same generic
     * dispatch() every action fires through, matching entity-menu's
     * own real "CLOSE" convention instead of a bespoke direct check. */
    if (strcmp(item->id, "close") == 0) { dispatch("CLOSE"); return; }
    int idx = atoi(item->id + 2); /* "sw0".."sw11" */
    if (idx < 0 || idx >= 12) return;
    if (g_phase == 0) {
        g_chosen_bg_idx = idx;
        g_phase = 1;
    } else if (g_phase == 1) {
        g_chosen_fg_idx = idx;
        g_phase = 2;
        apply_theme(g_palette_hex[g_chosen_bg_idx], g_palette_hex[g_chosen_fg_idx]);
        g_running = 0;
    }
}

static void handle_key(KeySym ks, char ch) {
    if (ch == 'p') { dump_frame_png(); return; }
    if (ch >= '0' && ch <= '9') {
        int d = ch - '0';
        int new_val = g_digit_accum * 10 + d;
        if (new_val > 0 && new_val <= g_n_nav) { g_digit_accum = new_val; g_focus_nav = g_digit_accum; }
        else if (d > 0 && d <= g_n_nav) { g_digit_accum = d; g_focus_nav = g_digit_accum; }
        else g_digit_accum = 0;
        return;
    }
    if (ks == XK_Up || ks == XK_Left) { if (g_focus_nav > 1) g_focus_nav--; g_digit_accum = 0; return; }
    if (ks == XK_Down || ks == XK_Right) { if (g_focus_nav < g_n_nav) g_focus_nav++; g_digit_accum = 0; return; }
    if (ks == XK_Return || ks == XK_KP_Enter) { g_digit_accum = 0; activate_focused(); return; }
    if (ks == XK_Escape) { g_running = 0; return; }
}

static long g_relay_cursor = -1;
static void relay_path(char *out, size_t outsz) {
    snprintf(out, outsz, "%s/#.desktop/taskbar_settings_agent_relay.txt", g_house_root);
}
static void dispatch_relay_code(int code) {
    if (code == 13) handle_key(XK_Return, 0);
    else if (code == 27) handle_key(XK_Escape, 0);
    else if (code >= 32 && code <= 126) handle_key(0, (char)code);
}
static int poll_agent_relay(void) {
    char path[PATH_BUF];
    relay_path(path, sizeof(path));
    struct stat stt;
    if (stat(path, &stt) != 0) return 0;
    if (g_relay_cursor < 0) { g_relay_cursor = stt.st_size; return 0; }
    if (stt.st_size < g_relay_cursor) { g_relay_cursor = stt.st_size; return 0; }
    if (stt.st_size == g_relay_cursor) return 0;
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    fseek(f, g_relay_cursor, SEEK_SET);
    char line[32];
    long consumed = g_relay_cursor;
    int n_dispatched = 0;
    while (fgets(line, sizeof(line), f)) {
        char *nl = strchr(line, '\n');
        if (!nl) break;
        *nl = '\0';
        long here = ftell(f);
        int code = atoi(line);
        if (code > 0) { dispatch_relay_code(code); n_dispatched++; }
        consumed = here;
    }
    fclose(f);
    g_relay_cursor = consumed;
    return n_dispatched;
}

int main(int argc, char **argv) {
    /* REAL Stage 5 step 3/4 (2026-08-16, khtpm-merge-how2.md §5d.3) -
     * was <house_root> only with the .chtpm path hardcoded internally;
     * now takes the real, unified <house_root> <chtpm_path> contract
     * (matches db-hq/chat-hai already) - mechanical, zero behavior
     * change (button_taskbar_settings.sh now passes the same path this
     * used to hardcode). css_path derived by extension-swap from
     * chtpm_path, same real convention db-hq's own main() already
     * uses, instead of a second separately-hardcoded path. */
    if (argc < 3) { fprintf(stderr, "usage: khtpm_taskbar_settings_render.+x <house_root> <chtpm_path>\n"); return 1; }
    snprintf(g_house_root, sizeof(g_house_root), "%s", argv[1]);
    snprintf(g_audit_dir, sizeof(g_audit_dir), "%s/#.desktop/taskbar-settings-audit", g_house_root);
    snprintf(g_pid_path, sizeof(g_pid_path), "%s/taskbar-settings.pid", g_audit_dir);
    snprintf(g_chtpm_path, sizeof(g_chtpm_path), "%s", argv[2]);
    snprintf(g_css_path, sizeof(g_css_path), "%s", argv[2]);
    { char *dot = strrchr(g_css_path, '.'); if (dot) snprintf(dot, sizeof(g_css_path) - (size_t)(dot - g_css_path), ".css"); }
    signal(SIGTERM, handle_sigterm);
    signal(SIGINT, handle_sigterm);
    mkdir(g_audit_dir, 0755);
    write_pidfile();

    /* real palette table - same 12 entries/order as the old g_palette[]
     * array, now sourced by id (sw0..sw11) instead of a bare index */
    static const char *hex[12] = { "#000000","#ffffff","#1a1a1a","#e5e5e5","#ef4444","#f97316","#eab308","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899" };
    static const char *name[12] = { "black","white","charcoal","silver","red","orange","yellow","green","cyan","blue","purple","pink" };
    for (int i = 0; i < 12; i++) { g_palette_hex[i] = hex[i]; g_palette_name[i] = name[i]; }

    g_window = parse_chtpm(g_chtpm_path);
    if (!g_window) { fprintf(stderr, "taskbar-settings: cannot parse %s\n", g_chtpm_path); return 1; }
    memset(&g_sheet, 0, sizeof(g_sheet));
    css_load(g_css_path, &g_sheet);

    XSetErrorHandler(nonfatal_x_error);
    dpy = XOpenDisplay(NULL);
    if (!dpy) { fprintf(stderr, "taskbar-settings: cannot open display\n"); return 1; }
    screen = DefaultScreen(dpy); /* REAL Stage 5 - real global now, not local */
    vis = DefaultVisual(dpy, screen);
    int depth = DefaultDepth(dpy, screen);
    cmap = XCreateColormap(dpy, RootWindow(dpy, screen), vis, AllocNone);

    XSetWindowAttributes swa;
    swa.colormap = cmap;
    swa.event_mask = ExposureMask | KeyPressMask | ButtonPressMask | StructureNotifyMask;
    swa.background_pixel = 0x141414;
    swa.border_pixel = 0;
    win = XCreateWindow(dpy, RootWindow(dpy, screen), 200, 200, (unsigned)g_win_w, (unsigned)g_win_h,
                         0, depth, InputOutput, vis, CWColormap | CWEventMask | CWBackPixel | CWBorderPixel, &swa);
    XStoreName(dpy, win, "taskbar-settings");

    /* real WM dance, unchanged from the old version - see this file's
     * own header comment for why (2026-08-13 "opens too high" fix). */
    XSizeHints *size_hints = XAllocSizeHints();
    if (size_hints) {
        size_hints->flags = PPosition | USPosition | PSize;
        size_hints->x = 200; size_hints->y = 200;
        size_hints->width = g_win_w; size_hints->height = g_win_h;
        XSetWMNormalHints(dpy, win, size_hints);
        XFree(size_hints);
    }
    Atom motif_hints = XInternAtom(dpy, "_MOTIF_WM_HINTS", False);
    struct { unsigned long flags, functions, decorations; long input_mode; unsigned long status; } mwm = {2, 0, 0, 0, 0};
    XChangeProperty(dpy, win, motif_hints, motif_hints, 32, PropModeReplace, (unsigned char *)&mwm, 5);
    Atom win_type = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE", False);
    Atom win_type_dialog = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE_DIALOG", False);
    XChangeProperty(dpy, win, win_type, XA_ATOM, 32, PropModeReplace, (unsigned char *)&win_type_dialog, 1);
    wm_delete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(dpy, win, &wm_delete, 1);
    XMapWindow(dpy, win);
    XMoveWindow(dpy, win, 200, 260);
    XFlush(dpy);
    clock_gettime(CLOCK_MONOTONIC, &g_map_time);

    gc = XCreateGC(dpy, win, 0, NULL);
    buf = XCreatePixmap(dpy, win, (unsigned)g_win_w, (unsigned)g_win_h, (unsigned)depth);
    xftdraw_buf = XftDrawCreate(dpy, buf, vis, cmap);

    load_fonts();
    xft_color_out("#ececec", &col_text);
    xft_color_out("#a0a0a0", &col_muted);
    xft_color_out("#22c55e", &col_accent);
    xft_color_out("#ef4444", &col_danger);

    redraw();

    if (argc > 2 && strcmp(argv[2], "--dump-and-exit") == 0) {
        unlink_pidfile();
        dump_frame_png();
        return 0;
    }

    g_running = 1;
    while (g_running && !g_want_exit) {
        struct timeval tv = {0, 150000};
        fd_set fds; FD_ZERO(&fds); int xfd = ConnectionNumber(dpy); FD_SET(xfd, &fds);
        select(xfd + 1, &fds, NULL, NULL, &tv);

        int need_redraw = 0;
        if (poll_agent_relay() > 0) need_redraw = 1;
        while (XPending(dpy)) {
            XEvent ev; XNextEvent(dpy, &ev);
            need_redraw = 1;
            if (ev.type == ClientMessage && (Atom)ev.xclient.data.l[0] == wm_delete) g_running = 0;
            else if (ev.type == KeyPress) {
                char buf_ch[8]; KeySym ks;
                int n = XLookupString(&ev.xkey, buf_ch, sizeof(buf_ch), &ks, NULL);
                handle_key(ks, n > 0 ? buf_ch[0] : 0);
            } else if (ev.type == ButtonPress) {
                struct timespec now;
                clock_gettime(CLOCK_MONOTONIC, &now);
                long ms_since_map = (now.tv_sec - g_map_time.tv_sec) * 1000L
                                   + (now.tv_nsec - g_map_time.tv_nsec) / 1000000L;
                if (ms_since_map < PHANTOM_CLICK_GUARD_MS) continue;
                for (int i = 0; i < g_n_nav; i++) {
                    Elem *it = g_nav[i];
                    if (ev.xbutton.x >= it->x && ev.xbutton.x < it->x + it->w &&
                        ev.xbutton.y >= it->y && ev.xbutton.y < it->y + it->h) {
                        g_focus_nav = it->nav_index;
                        activate_focused();
                        break;
                    }
                }
            }
        }
        if (need_redraw && g_running) redraw();
    }

    unlink_pidfile();
    XftDrawDestroy(xftdraw_buf);
    XFreeGC(dpy, gc);
    XFreePixmap(dpy, buf);
    XDestroyWindow(dpy, win);
    XCloseDisplay(dpy);
    return 0;
}
