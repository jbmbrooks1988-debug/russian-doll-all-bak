#!/bin/sh
# build_taskbar_settings.sh — build the taskbar HQ menu's "Settings" window
# (khtpm_taskbar_settings_render.c), a separate standalone binary/process,
# same shape as build_db_hq.sh - never touches the taskbar's own two
# binaries.
#
# Stage 2c REAL PORT (2026-08-16) onto the shared Elem/CSS render model -
# now a real khtpm_css_parser.c/khtpm_render_core.c consumer, same
# shared-source-copy convention as build_entity_menu.sh.
set -e
cd "$(dirname "$0")"
mkdir -p +x
CC=${CC:-gcc}
CFLAGS="-std=c11 -Wall -O2 $(pkg-config --cflags xft)"
LIBS="-lX11 $(pkg-config --libs xft) -lm"

SHARED="$(cd "$(dirname "$0")/../../../&.widgits/_shared-lib" && pwd)"
cp "$SHARED/khtpm_css_parser.c" khtpm_css_parser.c
cp "$SHARED/khtpm_css_parser.h" khtpm_css_parser.h
cp "$SHARED/khtpm_render_core.c" khtpm_render_core.c
cp "$SHARED/khtpm_draw_core.c" khtpm_draw_core.c
mkdir -p lib
cp "$SHARED/stb_image_write.h" lib/stb_image_write.h

# REAL Stage 1 follow-up (2026-08-16) - dump_frame_png_op.+x is a real,
# standalone, shared op binary (system()-invoked, not text-included -
# see khtpm-merge-how2.md's own "HOUSE STANDARD" section for why), not
# rebuilt from a per-app copy - build it once, centrally, if missing.
OPS_BIN="$SHARED/ops/+x/dump_frame_png_op.+x"
if [ ! -x "$OPS_BIN" ]; then
  (cd "$SHARED/ops" && sh build_dump_frame_png_op.sh)
fi

# REAL Stage 5 starter-app proof (2026-08-16, khtpm-merge-how2.md
# §5d.3 step 1) - apply_theme_op.+x is taskbar-settings' own real,
# app-specific standalone op (was in-process business logic, now a
# separate binary, system()-invoked) - app-local ops/ (not the shared
# _shared-lib/ops/), matching TPMOS's own real per-project ops/*.c vs
# cross-project pieces/chtpm/ops/*.c split.
echo "-- apply_theme_op -> +x/apply_theme_op.+x"
$CC $CFLAGS -o +x/apply_theme_op.+x apply_theme_op.c
echo "OK +x/apply_theme_op.+x"

echo "-- taskbar-settings renderer -> +x/khtpm_taskbar_settings_render.+x"
$CC $CFLAGS -o +x/khtpm_taskbar_settings_render.+x \
  khtpm_taskbar_settings_render.c khtpm_css_parser.c $LIBS

echo "OK +x/khtpm_taskbar_settings_render.+x"
