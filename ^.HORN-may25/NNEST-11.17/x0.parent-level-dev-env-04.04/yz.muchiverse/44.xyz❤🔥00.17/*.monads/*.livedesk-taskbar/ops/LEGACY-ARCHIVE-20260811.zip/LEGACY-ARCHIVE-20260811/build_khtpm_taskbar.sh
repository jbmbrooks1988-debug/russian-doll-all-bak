#!/bin/sh
# build_khtpm_taskbar.sh — build the khtpm_taskbar_manager-based taskbar
# (Linux). Design = khtpm_taskbar_manager.c only; plat_x11.c draws only.
#
# Moved here 2026-08-10 from &.widgits/tile-picker/ops/ (direct report:
# "these taskbars shouldn't be in tile picker widget, that doesn't make
# any sense, it's not a member of that widget" - same correction already
# made once before for the LEGACY tp_taskbar.c on 2026-08-05, just never
# applied to these newer khtpm_taskbar_* files). See
# yz.muchiverse/#.#.✅️.cal-user-sum/khtpm-refactor-plan.md §10.
#
# SAFE BY DESIGN: outputs to tp_taskbar_khtpm_test.+x, a clearly-named
# TEST artifact - never auto-copies over the live, running
# tp_taskbar.+x. The old tile-picker/ops/build_khtpm.sh DID auto-copy
# its taskbar output over the live binary path, which is exactly why
# running it was flagged unsafe ("clobbers the strip taskbar"). This
# script removes that danger structurally instead of just documenting
# it - deploying the khtpm build over the live one, when it's ever
# ready, should be a deliberate, explicit step a human/agent takes on
# purpose, not a side effect of building.
set -e
cd "$(dirname "$0")"
mkdir -p +x
CC=${CC:-gcc}
CFLAGS="-std=c11 -Wall -O2"

echo "-- khtpm taskbar (core + plat_x11) -> +x/tp_taskbar_khtpm_test.+x (TEST, not deployed)"
$CC $CFLAGS -o +x/tp_taskbar_khtpm_test.+x \
  khtpm_taskbar_main.c khtpm_taskbar_manager.c khtpm_taskbar_plat_x11.c \
  -lX11 -lm

echo "OK +x/tp_taskbar_khtpm_test.+x (test binary only - live tp_taskbar.+x untouched)"
