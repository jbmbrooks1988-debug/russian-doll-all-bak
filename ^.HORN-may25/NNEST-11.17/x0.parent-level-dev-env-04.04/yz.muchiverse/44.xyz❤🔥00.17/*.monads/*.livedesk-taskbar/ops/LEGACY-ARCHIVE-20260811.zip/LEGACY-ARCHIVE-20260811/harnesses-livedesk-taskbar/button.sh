#!/bin/bash
# 2026-08-10: default demo switched to the relay-based scenario (see
# README.txt UPDATE note) - no X11 injection, works even with a human
# concurrently using the same display. The old XTest scenario
# (demo_strip_and_popup_nav.sh) was never actually written; xtest-demo is
# kept as a named action for when it exists / is needed for focus-
# handling regression work specifically.
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ACTION="${1:-help}"
case "$ACTION" in
    demo|run)
        bash "$SCRIPT_DIR/scenarios/demo_relay_nav.sh"
        ;;
    xtest-demo)
        bash "$SCRIPT_DIR/scenarios/demo_strip_and_popup_nav.sh"
        ;;
    help|*)
        echo "livedesk-taskbar nav harness:"
        echo "  demo        - relay-based nav proof (default, no X11 injection)"
        echo "  xtest-demo  - old XTest-injector scenario (focus-handling regression only)"
        ;;
esac
