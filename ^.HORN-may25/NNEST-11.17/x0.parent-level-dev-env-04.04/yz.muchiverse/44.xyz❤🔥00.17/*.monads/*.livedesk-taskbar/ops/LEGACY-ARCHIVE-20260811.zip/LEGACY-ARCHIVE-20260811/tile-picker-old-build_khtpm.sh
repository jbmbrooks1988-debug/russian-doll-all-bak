#!/bin/sh
# Build shared KHTPM entity (Linux). Design = khtpm_core only.
#
# TASKBAR BUILD MOVED 2026-08-10 to
# &.widgits/livedesk-taskbar/ops/build_khtpm_taskbar.sh - the
# khtpm_taskbar_* files themselves moved there too (direct report: "these
# taskbars shouldn't be in tile picker widget... it's not a member of
# that widget"). This script now only builds the entity, which genuinely
# does belong here. See khtpm-refactor-plan.md §10.
set -e
cd "$(dirname "$0")"
mkdir -p +x
CC=${CC:-gcc}
CFLAGS="-std=c11 -Wall -O2"

echo "-- entity (core + plat_x11)"
$CC $CFLAGS -o +x/tp_desktop_window.+x \
  khtpm_main.c khtpm_core.c khtpm_plat_x11.c \
  -lX11 -lXext -lGL -lm

echo "build_khtpm ok (entity only - taskbar build moved to livedesk-taskbar/ops/)"
