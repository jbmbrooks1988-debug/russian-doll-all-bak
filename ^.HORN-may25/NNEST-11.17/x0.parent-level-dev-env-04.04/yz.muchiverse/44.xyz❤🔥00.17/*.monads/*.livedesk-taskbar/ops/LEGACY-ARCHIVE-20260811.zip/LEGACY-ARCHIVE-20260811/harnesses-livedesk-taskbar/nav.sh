#!/bin/bash
# nav.sh - agent-relay harness for the livedesk taskbar strip (2026-08-10).
#
# REWRITTEN to use the taskbar's file-based agent relay
# (#.desktop/livedesk_agent_relay.txt) instead of X11 event injection
# (XTest tk_click/tk_key + XSetInputFocus via setfocus). The old approach
# required real global input focus, which conflicts with a human using
# the same display at the same time (their mouse/window clicks steal focus
# mid-sequence, silently misdirecting injected keys). The relay bypasses
# X11 focus entirely: this script just appends decimal ASCII codes, one
# per line, to a plain text file; the taskbar polls it on its own ~300ms
# tick and dispatches through the exact same logic a real keypress would
# (see poll_agent_relay()/agent_relay_dispatch() in tp_taskbar.c).
#
# No xwininfo/xdotool/XTest dependency anymore - this now works even with
# no X tools installed at all, and multiple agents/humans can drive the
# taskbar concurrently without fighting over focus.
#
# Commands:
#   nav.sh nav <n>            type digits <n>, Enter -> global nav jump
#                              (only takes effect when no popup is open -
#                              same digit_buf/Enter mechanism as 'row',
#                              context (armed nav vs open popup vs cli-io)
#                              is resolved server-side by the taskbar)
#   nav.sh row <n>             type digits <n>, Enter -> select+run popup
#                              row (alias of 'nav' - the taskbar itself
#                              decides which one applies from its own
#                              current state, not from which command you
#                              typed)
#   nav.sh key <name>         send one key: Return/Enter, Escape/Esc,
#                              BackSpace, or a single literal character
#   nav.sh esc                send Escape
#   nav.sh type <text>        type each character of <text> in turn (for
#                              cli-io text entry, e.g. a save-as name) -
#                              does NOT send a trailing Enter; call
#                              'nav.sh key Return' after if you want to
#                              commit
#   nav.sh cells               print last strip frame from strip_frame_log.txt
#   nav.sh popups               print last popup frame from popup_frame_log.txt
#   nav.sh wait [sec]           sleep (default 0.6)
#
# Env: HOUSE=<house_root> (defaults to $PWD)

set -u
HOUSE="${HOUSE:-$PWD}"
RELAY="$HOUSE/#.desktop/livedesk_agent_relay.txt"
STRIP_LOG="$HOUSE/#.desktop/tp_taskbar_debug/strip_frame_log.txt"
POPUP_LOG="$HOUSE/#.desktop/tp_taskbar_debug/popup_frame_log.txt"

# One decimal ASCII code per line - exact contract of poll_agent_relay()
# in tp_taskbar.c. The taskbar polls on a ~300ms tick, so a small sleep
# after each send lets it actually get consumed before the next one -
# without it, several codes sent inside one poll tick would be batched,
# which is fine for digits (digit_buf accumulates either way) but would
# race the Enter-triggered state transition for popup opens.
send_code() {
  echo "$1" >> "$RELAY"
  sleep 0.35
}

# Digits accumulate server-side in digit_buf regardless of pacing, so
# these can be sent back-to-back with a shorter gap; only the FINAL
# Enter needs the full settle time.
send_digits() {
  local n="$1" i c
  for ((i = 0; i < ${#n}; i++)); do
    c="${n:$i:1}"
    echo -n "${c}" | od -An -tu1 | tr -d ' ' >> "$RELAY"
    printf '\n' >> "$RELAY"
    sleep 0.1
  done
}

send_char() {
  local code
  code=$(printf '%d' "'$1")
  send_code "$code"
}

cmd_nav_or_row() {
  # Ensure the relay file exists so the taskbar's first poll can baseline
  # its cursor - harmless if it already does.
  touch "$RELAY"
  send_digits "$1"
  send_code 13   # Enter
}

case "${1:-}" in
  nav)
    cmd_nav_or_row "${2:?usage: nav.sh nav <n>}"
    ;;
  row)
    cmd_nav_or_row "${2:?usage: nav.sh row <n>}"
    ;;
  key)
    k="${2:?usage: nav.sh key <Return|Escape|BackSpace|char>}"
    case "$k" in
      Return|Enter) send_code 13 ;;
      Escape|Esc)   send_code 27 ;;
      BackSpace)    send_code 8 ;;
      [0-9])        send_code "$(printf '%d' "'$k")" ;;
      ?)            send_char "$k" ;;
      *)            echo "key: unrecognized '$k' (use Return/Escape/BackSpace or a single char)" >&2; exit 1 ;;
    esac
    ;;
  esc)
    send_code 27
    ;;
  type)
    text="${2:?usage: nav.sh type <text>}"
    for ((i = 0; i < ${#text}; i++)); do
      send_char "${text:$i:1}"
    done
    ;;
  cells)
    tail -n +1 "$STRIP_LOG" 2>/dev/null | tail -14
    ;;
  popups)
    tail -n +1 "$POPUP_LOG" 2>/dev/null | tail -12
    ;;
  wait)
    sleep "${2:-0.6}"
    ;;
  *)
    echo "usage: nav.sh {nav <n>|row <n>|key <name>|esc|type <text>|cells|popups|wait [sec]}" >&2
    exit 1
    ;;
esac
