livedesk-taskbar nav harness
============================
Purpose: prove tp_taskbar.c's real navigation (strip buttons, popup
submenus, cli-io text entry, the unified [>] cursor) works end-to-end
autonomously - no human at the keyboard/mouse.

UPDATE 2026-08-10 - PRIMARY METHOD CHANGED to the file-based agent relay
--------------------------------------------------------------------------
tp_taskbar.c grew its own file-relay polling loop (poll_agent_relay() /
agent_relay_dispatch(), see the big comment above that function in the
source) specifically so agent-driven testing/control no longer needs
XTest injection at all. Direct instruction: built BEFORE any khtpm port
of this program, so a rollback still has working agent access; see
_.0.aigent-testing-k9.txt's 2026-08-10 SCOPE update for the house-wide
rationale and !.HOUSE_STDS.md §F-19's addendum for why this replaced
XTest as the default (XTest requires stealing real global X focus, which
conflicts with a human using the same display at the same time).

nav.sh (this directory) is the new default driver: it just appends
decimal ASCII codes to #.desktop/livedesk_agent_relay.txt - no
xwininfo/xdotool/XTest dependency, works even with zero X tools
installed. Run `bash nav.sh nav <n>` / `row <n>` / `key <name>` / `type
<text>` / `esc` / `cells` / `popups` - see nav.sh's own header comment
for the full command list and the exact relay format contract.

ops/key_injector.c (the OLD XTest-based method) is KEPT, not replaced -
it remains the right tool for regression-testing tp_taskbar.c's own real
keyboard-focus handling (the thing §F-19 originally diagnosed), since
that's testing the XNextEvent path itself, not routing around it. Use it
via `bash button.sh demo` when you specifically need to prove real X11
input still reaches the popups correctly (e.g. after touching
taskbar_soft_focus() or any override-redirect window setup) - use nav.sh
for everything else (agent task automation, save/load/pals testing,
anything that doesn't need to prove the X11 focus path itself).

ORIGINAL (XTest injector) BACKGROUND, still accurate for what it tests
-------------------------------------------------------------------------
Built directly out of the 2026-08-09 popup-keyboard-focus investigation
(!.HOUSE_STDS.md §F-19) - this is the same key_injector used to diagnose
and confirm that bug, kept here as a real, repeatable regression check
instead of a one-off debugging tool.

WHAT IT DOES (button.sh demo)
------------------------------
1. Builds the real taskbar binary + this harness's own key_injector.
2. Kills any stale taskbar, wipes shared/debug state, launches a fresh
   real taskbar instance against the live house.
3. Locates the real strip window on screen (xwininfo), clicks the HQ
   button, presses Down inside the popup, presses Escape - via REAL
   XTest-injected X11 events (XTestFakeKeyEvent/XTestFakeButtonEvent),
   genuinely indistinguishable from physical input to the receiving
   client.
4. Arms strip navigation (right-click) and presses Right twice.
5. Asserts against the taskbar's OWN real per-frame draw logs
   (#.desktop/tp_taskbar_debug/{strip,popup}_frame_log.txt) that focus
   actually moved as expected at each step - not just that the injector
   ran without erroring.
6. Confirms a real RGB frame receipt exists (strip_frame.raw +
   .receipt.txt) - proof a human/agent could visually verify the result
   too, not just infer it from text logs.

WHY THIS EXISTS - the general lesson, not just this one bug
--------------------------------------------------------------
tp_taskbar.c is a raw-Xlib program (reads real X11 events via
XNextEvent(), not a pieces/keyboard/history.txt-polling loop) - the
house's usual k9 file-injection testing method
(_.0.aigent-testing-k9.txt) originally did not apply to it. This harness
was the equivalent black-box interface for that architecture family: an
XTest injector tailing a plain text file, real events at the X server
level. As of 2026-08-10, tp_taskbar.c ALSO grew its own file-relay
polling loop (see the UPDATE note above) - it now qualifies for a
k9-style file-injection method too, just a different relay file/format
than the chtpm_parser_pal family's pieces/keyboard/history.txt.
See _.0.aigent-testing-k9.txt's own SCOPE note (added 2026-08-09, updated
2026-08-10 for the agent relay) for which method applies to which
program family.

RUN
---
  bash nav.sh nav 3              # relay method - agent-facing, default
  bash button.sh demo            # XTest method - focus-handling regression only

Proof (numbered step files, pass/fail summary) lands in
proof/harness-<timestamp>/ - same convention as every other harness in
%.harnesses/.

FILES
-----
  nav.sh                 - relay-based driver (2026-08-10, DEFAULT) - see
                           its own header comment for the full command
                           list and relay format contract
  ops/key_injector.c    - the OLD XTest injector (vendored here, not
                           dependent on any session's ephemeral tmp
                           storage) - kept for focus-handling regression
                           tests only, see UPDATE note above
  scenarios/demo_strip_and_popup_nav.sh  - the XTest-based scenario
  button.sh              - demo | help (XTest method)

RELATED
-------
  *.monads/*.livedesk-taskbar/README.md   - the taskbar widget's own docs
  *.monads/*.livedesk-taskbar/ops/tp_taskbar.c - poll_agent_relay()/
                                            agent_relay_dispatch(), the
                                            relay implementation itself
  #.livedesk/livedesk-editor-design.md §11 - KHTPM refactor notes,
                                            agent relay design context
  _.0.aigent-testing-k9.txt              - house-wide agent-testing
                                            SCOPE note, both methods
  !.HOUSE_STDS.md §F-19                  - the original XTest-focus bug
                                            this harness's XTest method
                                            proves is fixed, plus its
                                            2026-08-10 addendum on why
                                            the relay replaced it as
                                            default
  yz.muchiverse/a8-cc-++fix.md           - fuller 2026-08-09 session log
