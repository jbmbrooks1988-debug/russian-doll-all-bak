// tools/gemini_payload_builder.c - Converts flat context JSON into Gemini REST JSON payload or Ollama /api/chat payload
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char* role;
    char* content;
} Message;

// Write raw string escaping JSON control characters
void fprintf_json_escaped(FILE* f, const char* s) {
    while (*s) {
        if (*s == '"') fputs(""", f);
        else if (*s == '') fputs("", f);
        else if (*s == '
') fputs("
", f);
        else if (*s == '') fputs("", f);
        else if (*s == '	') fputs("	", f);
        else fputc(*s, f);
        s++;
    }
}

// Unescape JSON string helper
char* json_unescape(const char* s) {
    if (!s) return NULL;
    size_t len = strlen(s);
    char* out = malloc(len + 1);
    if (!out) return NULL;
    char* p = out;
    while (*s) {
        if (*s == '' && *(s+1)) {
            s++;
            if (*s == 'n') *p++ = '
';
            else if (*s == 't') *p++ = '	';
            else if (*s == 'r') *p++ = '';
            else if (*s == '"') *p++ = '"';
            else if (*s == '') *p++ = '';
            else *p++ = *s;
        } else {
            *p++ = *s;
        }
        s++;
    }
    *p = '\0';
    return out;
}

// Simple JSON parser for unescaped content to extract function name and args
static char* parse_key_obj(const char* json, const char* key, int is_object) {
    const char* p = json;
    char k_buf[256];
    while ((p = strchr(p, '"')) != NULL) {
        p++;
        size_t i = 0;
        while (*p && *p != '"' && i < sizeof(k_buf) - 1) {
            if (*p == '' && *(p+1)) { p++; k_buf[i++] = *p++; }
            else k_buf[i++] = *p++;
        }
        k_buf[i] = '\0';
        if (*p == '"') p++;
        while (*p == ' ' || *p == '	' || *p == '
' || *p == '') p++;
        if (*p == ':') {
            p++;
            while (*p == ' ' || *p == '	' || *p == '
' || *p == '') p++;
            if (strcmp(k_buf, key) == 0) {
                if (is_object) {
                    if (*p == '{') {
                        int depth = 0;
                        const char* start = p;
                        while (*p) {
                            if (*p == '{') depth++;
                            else if (*p == '}') {
                                depth--;
                                if (depth == 0) { p++; break; }
                            }
                            p++;
                        }
                        size_t len = p - start;
                        char* res = malloc(len + 1);
                        memcpy(res, start, len);
                        res[len] = '\0';
                        return res;
                    }
                } else {
                    if (*p == '"') {
                        p++;
                        const char* start = p;
                        while (*p && *p != '"') {
                            if (*p == '' && *(p+1)) p += 2;
                            else p++;
                        }
                        size_t len = p - start;
                        char* res = malloc(len + 1);
                        memcpy(res, start, len);
                        res[len] = '\0';
                        return res;
                    }
                }
            }
        }
    }
    return NULL;
}

char* read_file(const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = malloc(size + 1);
    if (buf) {
        size_t n = fread(buf, 1, size, f);
        buf[n] = '\0';
    }
    fclose(f);
    return buf;
}

int parse_messages(const char* json, Message* messages, int max_messages) {
    int count = 0;
    const char* p = json;
    
    while (count < max_messages) {
        p = strstr(p, ""role"");
        if (!p) break;
        p = strchr(p, ':');
        if (!p) break;
        p++;
        while (*p == ' ' || *p == '	' || *p == '
' || *p == '') p++;
        if (*p != '"') break;
        p++;
        const char* role_start = p;
        const char* role_end = strchr(p, '"');
        if (!role_end) break;
        size_t role_len = role_end - role_start;
        char* role = malloc(role_len + 1);
        memcpy(role, role_start, role_len);
        role[role_len] = '\0';
        
        p = role_end + 1;
        p = strstr(p, ""content"");
        if (!p) { free(role); break; }
        p = strchr(p, ':');
        if (!p) { free(role); break; }
        p++;
        while (*p == ' ' || *p == '	' || *p == '
' || *p == '') p++;
        if (*p != '"') { free(role); break; }
        p++;
        
        const char* content_start = p;
        const char* q = p;
        while (*q) {
            if (*q == '' && *(q+1)) {
                q += 2;
            } else if (*q == '"') {
                break;
            } else {
                q++;
            }
        }
        if (!*q) { free(role); break; }
        size_t content_len = q - content_start;
        char* content = malloc(content_len + 1);
        memcpy(content, content_start, content_len);
        content[content_len] = '\0';
        
        messages[count].role = role;
        messages[count].content = content;
        count++;
        p = q + 1;
    }
    return count;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input_messages_json> <output_json> [enable_tools_flag] [override_system_instruction] [is_ollama_flag]
", argv[0]);
        return 1;
    }
    
    const char* input_path = argv[1];
    const char* output_path = argv[2];
    int enable_tools = (argc >= 4 && strcmp(argv[3], "0") == 0) ? 0 : 1;
    const char* override_sys = (argc >= 5) ? argv[4] : NULL;
    int is_ollama = (argc >= 6 && strcmp(argv[5], "1") == 0);
    
    char* json_data = read_file(input_path);
    if (!json_data) {
        fprintf(stderr, "Error: Could not read file %s
", input_path);
        return 1;
    }
    
    Message messages[1024];
    int message_count = parse_messages(json_data, messages, 1024);
    free(json_data);
    
    FILE* out = fopen(output_path, "w");
    if (!out) {
        perror("fopen output");
        return 1;
    }
    
    if (is_ollama) {
        fprintf(out, "{"model": "llama3:latest", "messages": [
");
        int first = 1;
        for (int i = 0; i < message_count; i++) {
            if (!first) fprintf(out, ",
");
            fprintf(out, "  {"role": "%s", "content": "", strcmp(messages[i].role, "assistant") == 0 ? "assistant" : (strcmp(messages[i].role, "tool") == 0 ? "user" : messages[i].role));
            fprintf_json_escaped(out, messages[i].content);
            fprintf(out, ""}");
            first = 0;
        }
        fprintf(out, "
]}");
    } else {
        char* system_instruction = (char*)override_sys;
        if (!system_instruction) {
            for (int i = 0; i < message_count; i++) {
                if (strcmp(messages[i].role, "system") == 0) {
                    system_instruction = messages[i].content;
                }
            }
        }
        
        fprintf(out, "{
");
        if (system_instruction) {
            fprintf(out, "  "systemInstruction": {
");
            fprintf(out, "    "parts": [{
");
            if (override_sys) {
                fprintf(out, "      "text": "");
                fprintf_json_escaped(out, system_instruction);
                fprintf(out, ""
");
            } else {
                fprintf(out, "      "text": "%s"
", system_instruction);
            }
            fprintf(out, "    }]
");
            fprintf(out, "  },
");
        }
        
        fprintf(out, "  "contents": [
");
        int first_content = 1;
        char* last_function_name = NULL;
        
        for (int i = 0; i < message_count; i++) {
            if (strcmp(messages[i].role, "system") == 0) continue;
            
            if (!first_content) {
                fprintf(out, ",
");
            }
            first_content = 0;
            
            if (strcmp(messages[i].role, "user") == 0) {
                fprintf(out, "    {
");
                fprintf(out, "      "role": "user",
");
                fprintf(out, "      "parts": [{
");
                fprintf(out, "        "text": "%s"
", messages[i].content);
                fprintf(out, "      }]
");
                fprintf(out, "    }");
            } 
            else if (strcmp(messages[i].role, "assistant") == 0) {
                char* unescaped = json_unescape(messages[i].content);
                char* func_name = NULL;
                char* func_args = NULL;
                
                if (unescaped) {
                    const char* start_p = unescaped;
                    while (*start_p == ' ' || *start_p == '	' || *start_p == '
' || *start_p == '') start_p++;
                    if (*start_p == '{') {
                        func_name = parse_key_obj(unescaped, "name", 0);
                        if (!func_name) func_name = parse_key_obj(unescaped, "tool", 0);
                        func_args = parse_key_obj(unescaped, "args", 1);
                        if (!func_args) func_args = parse_key_obj(unescaped, "arguments", 1);
                    }
                }
                
                if (func_name) {
                    if (last_function_name) free(last_function_name);
                    last_function_name = strdup(func_name);
                    
                    fprintf(out, "    {
");
                    fprintf(out, "      "role": "model",
");
                    fprintf(out, "      "parts": [{
");
                    fprintf(out, "        "functionCall": {
");
                    fprintf(out, "          "name": "%s"", func_name);
                    if (func_args) {
                        fprintf(out, ",
          "args": %s
", func_args);
                    } else {
                        fprintf(out, "
");
                    }
                    fprintf(out, "        }
");
                    fprintf(out, "      }]
");
                    fprintf(out, "    }");
                    free(func_name);
                    if (func_args) free(func_args);
                } else {
                    fprintf(out, "    {
");
                    fprintf(out, "      "role": "model",
");
                    fprintf(out, "      "parts": [{
");
                    fprintf(out, "        "text": "%s"
", messages[i].content);
                    fprintf(out, "      }]
");
                    fprintf(out, "    }");
                }
                if (unescaped) free(unescaped);
            }
            else if (strcmp(messages[i].role, "tool") == 0) {
                char* tool_name = last_function_name ? last_function_name : "unknown_tool";
                fprintf(out, "    {
");
                fprintf(out, "      "role": "user",
");
                fprintf(out, "      "parts": [{
");
                fprintf(out, "        "functionResponse": {
");
                fprintf(out, "          "name": "%s",
", tool_name);
                fprintf(out, "          "response": {
");
                fprintf(out, "            "result": "%s"
", messages[i].content);
                fprintf(out, "          }
");
                fprintf(out, "        }
");
                fprintf(out, "      }]
");
                fprintf(out, "    }");
            }
        }
        fprintf(out, "
  ]");
        
        if (enable_tools) {
            fprintf(out, ",
  "tools": [{
");
            fprintf(out, "    "functionDeclarations": [
");
            
            // Tool 1: exec_cmd
            fprintf(out, "      {
");
            fprintf(out, "        "name": "exec_cmd",
");
            fprintf(out, "        "description": "Run a shell command on the host system",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "cmd": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The shell command line string to execute"
");
            fprintf(out, "            }
");
            fprintf(out, "          },
");
            fprintf(out, "          "required": ["cmd"]
");
            fprintf(out, "        }
");
            fprintf(out, "      },
");
            
            // Tool 2: read_file
            fprintf(out, "      {
");
            fprintf(out, "        "name": "read_file",
");
            fprintf(out, "        "description": "Read the contents of a file from the local filesystem",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "path": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The absolute or relative path to the file to read"
");
            fprintf(out, "            }
");
            fprintf(out, "          },
");
            fprintf(out, "          "required": ["path"]
");
            fprintf(out, "        }
");
            fprintf(out, "      },
");
            
            // Tool 3: write_file
            fprintf(out, "      {
");
            fprintf(out, "        "name": "write_file",
");
            fprintf(out, "        "description": "Create a new file or overwrite an existing file with content",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "path": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The path to write the file to"
");
            fprintf(out, "            },
");
            fprintf(out, "            "content": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The full string content to write to the file"
");
            fprintf(out, "            }
");
            fprintf(out, "          },
");
            fprintf(out, "          "required": ["path", "content"]
");
            fprintf(out, "        }
");
            fprintf(out, "      },
");
            
            // Tool 4: list_dir
            fprintf(out, "      {
");
            fprintf(out, "        "name": "list_dir",
");
            fprintf(out, "        "description": "List all files and subdirectories in a directory",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "path": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The directory path to list (defaults to . if empty)"
");
            fprintf(out, "            }
");
            fprintf(out, "          }
");
            fprintf(out, "        }
");
            fprintf(out, "      },
");
            
            // Tool 5: search_in_files
            fprintf(out, "      {
");
            fprintf(out, "        "name": "search_in_files",
");
            fprintf(out, "        "description": "Search local files recursively for a specific text query/pattern",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "query": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The text query to search for"
");
            fprintf(out, "            }
");
            fprintf(out, "          },
");
            fprintf(out, "          "required": ["query"]
");
            fprintf(out, "        }
");
            fprintf(out, "      },
");
            
            // Tool 6: edit_file
            fprintf(out, "      {
");
            fprintf(out, "        "name": "edit_file",
");
            fprintf(out, "        "description": "Surgically search and replace a block of text in an existing file",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "path": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The file path to edit"
");
            fprintf(out, "            },
");
            fprintf(out, "            "search": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The exact contiguous block of code/text to match"
");
            fprintf(out, "            },
");
            fprintf(out, "            "replace": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The new replacement text block"
");
            fprintf(out, "            }
");
            fprintf(out, "          },
");
            fprintf(out, "          "required": ["path", "search", "replace"]
");
            fprintf(out, "        }
");
            fprintf(out, "      },
");
            
            // Tool 7: web_search
            fprintf(out, "      {
");
            fprintf(out, "        "name": "web_search",
");
            fprintf(out, "        "description": "Search the internet using DuckDuckGo for up-to-date information",
");
            fprintf(out, "        "parameters": {
");
            fprintf(out, "          "type": "object",
");
            fprintf(out, "          "properties": {
");
            fprintf(out, "            "query": {
");
            fprintf(out, "              "type": "string",
");
            fprintf(out, "              "description": "The search query"
");
            fprintf(out, "            }
");
            fprintf(out, "          },
");
            fprintf(out, "          "required": ["query"]
");
            fprintf(out, "        }
");
            fprintf(out, "      }
");
            
            fprintf(out, "    ]
");
            fprintf(out, "  }]
");
        }
        
        fprintf(out, "
}
");
    }
    fclose(out);
    
    if (last_function_name) free(last_function_name);
    for (int i = 0; i < message_count; i++) {
        free(messages[i].role);
        free(messages[i].content);
    }
    
    return 0;
}
