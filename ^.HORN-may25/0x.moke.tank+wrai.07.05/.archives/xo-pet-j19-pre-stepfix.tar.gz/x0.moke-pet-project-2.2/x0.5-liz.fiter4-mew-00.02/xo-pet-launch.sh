#!/bin/bash
# xo-pet-launch.sh - Canonical XO-PET launcher.

set -e

ACTION="${1:-help}"
shift || true

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR/projects/xo-pet-v1"

case "$ACTION" in
    auto)
        cd "$SCRIPT_DIR/.."
        exec ./manager "$@"
        ;;
    controller)
        exec bash "$SCRIPT_DIR/pieces/buttons/shared/run_orchestrator.sh" "$@"
        ;;
    init)
        exec bash "$SCRIPT_DIR/xo-pet-init.sh" "$@"
        ;;
    build|build-ops)
        exec bash "$SCRIPT_DIR/xo-pet-build-ops.sh" "$@"
        ;;
    setup|setup-tank)
        exec bash "$SCRIPT_DIR/xo-pet-setup-tank.sh" "$@"
        ;;
    help|h|-h|--help)
        cat <<'EOF'
XO-PET launcher

Usage:
  ./xo-pet-launch.sh auto
  ./xo-pet-launch.sh controller
  ./xo-pet-launch.sh init
  ./xo-pet-launch.sh build
  ./xo-pet-launch.sh setup [pet_names...]

Compatibility wrappers still exist:
  ../button.sh
  ./button.sh
  ./build_ops.sh
  ./liz-init.sh
  ./setup_tank.sh
  ./xo-pet-run-controller.sh

Modes:
  auto        Run the autonomous moke-pet manager path.
  controller  Run the local CHTPM orchestrator / project loader surface.
EOF
        ;;
    *)
        echo "Unknown action: $ACTION"
        echo "Run './xo-pet-launch.sh help' for usage."
        exit 1
        ;;
esac
