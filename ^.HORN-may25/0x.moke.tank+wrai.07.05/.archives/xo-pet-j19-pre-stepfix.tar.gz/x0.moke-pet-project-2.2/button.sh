#!/bin/bash
# Top-level moke-pet / XO-PET launcher entrypoint.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ACTION="${1:-help}"

case "$ACTION" in
    auto)
        shift || true
        cd "$SCRIPT_DIR"
        exec ./manager "$@"
        ;;
    controller)
        shift || true
        exec bash "$SCRIPT_DIR/x0.5-liz.fiter4-mew-00.02/xo-pet-launch.sh" controller "$@"
        ;;
    help|h|-h|--help)
        cat <<'EOF'
Moke-Pet / XO-PET launcher

Usage:
  sh button.sh auto
  sh button.sh controller
  sh button.sh init
  sh button.sh build
  sh button.sh setup [pet_names...]

Modes:
  auto        Run the autonomous moke-pet epoch manager directly.
  controller  Run the local CHTPM orchestrator / project loader surface.
EOF
        ;;
    *)
        exec bash "$SCRIPT_DIR/x0.5-liz.fiter4-mew-00.02/xo-pet-launch.sh" "$@"
        ;;
esac
